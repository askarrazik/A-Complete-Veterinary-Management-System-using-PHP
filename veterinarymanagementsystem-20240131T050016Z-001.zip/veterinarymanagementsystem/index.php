<?php

if(!empty($_SERVER["HTTPS"]) && ('on'==$_SERVER["HTTPS"])){
    
    
    $url = "https://";
}

else{
    $url = "http://";
}

$hostname = $_SERVER["HTTP_HOST"]; 
$url=$url.$hostname;
?>

<script>window.location="<?php echo $url."/veterinarymanagementsystem/view/login.php" ?>"</script>