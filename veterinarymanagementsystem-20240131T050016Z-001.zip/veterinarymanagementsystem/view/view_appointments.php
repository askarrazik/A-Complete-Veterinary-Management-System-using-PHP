<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/appointment_model.php';
$appObj = new Appointment();

$appointmentResult = $appObj->getAllApp();
?>
<html>
    <head>
        <title>View Appointments</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        <script>
        
            editApp = function(app_id){
                //alert(appId);
                var url = "../controller/appointment_controller.php?status=load_app_modal";
                $.post(url,{app_id:app_id},function(data){
                    $("#loadappdata").html(data);
                });
            }
        
        
        
        </script>    
    </head>
    
    
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">View Appointments</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
                
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="appointment.php">Appointment Management</a></li>
                        <li>View Appointments</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/appointment_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    
                            <?php
                        if(isset($_GET["msg"])){
                            $msg = base64_decode($_GET["msg"]);
                    ?>
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="alert alert-success">
                                <p align="center"> <?php echo ucfirst($msg);?></p>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    ?>
                    
                    <div class="row">
                    
                        <div class="col-md-12">
                            <table class="table table-hover table-bordered" id="apptable">
                                <thead>
                                    <tr style = "background-color: #456bdc; color: #fff">
                                        <th>Customer</th>
                                        <th>Veterinarian</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                        
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    while($app_row = $appointmentResult->fetch_assoc()){
                                        $app_id = base64_encode($app_row["app_id"]);
                                        ?>
                                    <tr>
                                        <td><?php echo ucwords($app_row["cus_fname"]." ".$app_row["cus_lname"]); ?></td>
                                        <td><?php echo ucwords($app_row["vet_fname"]." ".$app_row["vet_lname"]); ?></td>
                                        <td><?php echo ucwords($app_row["date"])?></td>
                                        <td><?php echo ucwords($app_row["time"])?></td>
                                        
                                        <td>
                                             <?php 
                                                if($app_row["app_status"]==1){
                                            ?>
                                                    <label class="label label-primary">Pending</label>
                                            <?php
                                                }
                                                
                                                else if($app_row["app_status"]==2){
                                            ?>
                                                    <label class="label label-success">Done</label>
                                            <?php        
                                                }   
                                            
                                                else{
                                            ?>
                                                    <label class="label label-danger">Cancelled</label>
                                            <?php        
                                                }   
                                            ?>
                                        </td>
                                        
                                        <td>
                                            
                                            <?php
                                            if($app_row["app_status"]==1){
                                                ?>
                                            
                                            <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#editApp" onclick="editApp('<?php echo $app_id;?>')"><span class="glyphicon glyphicon-edit"></span>&nbsp;Edit</a>&nbsp;
                                    <?php
                                            }
                                            else{
                                               ?>
                                            <a href="#" class="btn btn-warning disabled"><span class="glyphicon glyphicon-edit"></span>&nbsp;Edit</a>&nbsp;
                                            <?php
                                            }
                                    
                                            if($app_row["app_status"]==1){
                                            ?>
                                                    <a href="../controller/appointment_controller.php?status=done_appointment&app_id=<?php echo $app_id; ?>" class="btn btn-success"><span class="glyphicon glyphicon-ok-sign"></span>&nbsp;Done</a> 
                                                    <a href="../controller/appointment_controller.php?status=cancel_appointment&app_id=<?php echo $app_id; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-remove-circle"></span>&nbsp;Cancel</a>
                                             <?php   
                                            
                                                }
                                            else{
                                                ?>
                                                    <a href="#" class="btn btn-success disabled"><span class="glyphicon glyphicon-ok-sign "></span>&nbsp;Done</a> 
                                                    <a href="#" class="btn btn-danger disabled"><span class="glyphicon glyphicon-remove-circle"></span>&nbsp;Cancel</a>
                                            
                                                <?php
                                            }    
                                                
                                            ?>        
                                                
                                        </td>
                                        
                                        

                                    </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                    
                        </div>
                    </div>
                    
                </div>
            </div>
            
            
            
        </div>
        
        <div class="modal fade" id="editApp" role="dialog">
            
            <div class="modal-dialog">
                
                <--<!-- Modal Content -->
                <div class ="modal-content">
                    <form action="../controller/appointment_controller.php?status=edit_appointment" method="post">
                        
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><span class="glyphicon glyphicon-pencil"></span>&nbsp;Edit Appointment</h4> 
                    </div>
                        
                    <div class="modal-body">
                        <div id="loadappdata">
                            
                        </div>
                    </div>
                        
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-floppy-save"></span>&nbsp;Save
                        </button>
                        &nbsp;
                        <button type="submit" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                        
                    </form>
                </div>
            </div>
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>


<script src="../JS/datatable/jquery-3.5.1.js"></script>
<script src="../JS/datatable/jquery.dataTables.min.js"></script>
        
        <!-- include bootstrap js-->
<script src="../JS/datatable/dataTables.bootstrap.min.js"></script>
<script>
            
            $(document).ready(function(){
                $("#apptable").DataTable();
            });
</script>

</html>
