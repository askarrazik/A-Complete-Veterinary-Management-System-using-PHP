<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/veterinarian_model.php';
$vetObj = new Veterinarian();

$vet_id = $_GET["vet_id"];
$vet_id = base64_decode($vet_id);

$specificVetResult = $vetObj->getSpecificVet($vet_id);
$vet_row = $specificVetResult->fetch_assoc(); // will be converted to the record into associative array

$vetSpecialtyResult = $vetObj->getVetSpecialty($vet_id);
$vetContactResult = $vetObj->getSpcificVetContact($vet_id);

?>
<html>
    <head>
        <title>View Veterinarian</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    </head>
    
   
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">View Veterinarian</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
                
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="veterinarian.php">Veterinarian Management</a></li>
                        <li><a href="view_vets.php">View Veterinarians</a></li>
                        <li>View Veterinarian</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/veterinarian_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                
                        <div class ="row">
                        
                            <div class ="col-md-4 col-md-offset-8">
                                <a href="edit_vet.php?vet_id=<?php echo base64_encode($vet_id); ?>" class="btn btn-warning">
                                    <span class ="glyphicon glyphicon-pencil"></span>&nbsp;
                                    Click here to edit veterinarian details
                                </a>

                            </div>
                        </div>
                    
                                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control_label">First Name :</label>
                            </div>
                            <div class="col-md-4">
                                <?php echo ucwords($vet_row["vet_fname"]);?>
                            </div>
                            <div class="col-md-2">
                                <label class="control_label">Last Name :</label>
                            </div>
                            <div class="col-md-4">
                                <?php echo ucwords($vet_row["vet_lname"]);?>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control_label">Specialty :</label>
                            </div>
                            
                            <div class="col-md-10">
                                <?php
                                
                                                    while($specialty_row=$vetSpecialtyResult->fetch_assoc()){
                                                        ?>
                                <div class="row">
                                    <div class="col-md-4">
                                        <?php echo $specialty_row["specialty"]?>
                                    </div>
                                
                                    
                               
                                </div>
                             <?php
                                
                                                    }
                                
                                ?>
                            </div>
                            
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">
                                &nbsp;
                            </div>
                        </div>
                        
                        <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Contact Land :</label>
                        </div>
                        <?php 
                                            while($contact_row = $vetContactResult->fetch_assoc()){
                        if($contact_row["contact_type"]==1){
                            ?>
                            <div class="col-md-4">
                            <?php echo $contact_row["contact_no"]; ?>
                            </div>
                        <?php
                            
                        }
                        
                        
                        else{
                            ?>
                            <div class="col-md-2">
                            <label class="control-label">Contact Mobile :</label>
                            </div>
                        
                        <div class="col-md-4">
                            <?php echo $contact_row["contact_no"]; ?>
                        </div>
                        <?php
                        }
                        }
                        ?>
                        
                        
                        
                        
                    </div>
                        
                        <div class="row">
                            <div class="col-md-12">
                                &nbsp;
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control-label">NIC :</label>
                            </div>
                            <div class="col-md-4">
                                <?php echo ucwords($vet_row["vet_nic"]);?>
                            </div>
                            <div class="col-md-2">
                                <label class="control-label">Email :</label>
                            </div>
                            <div class="col-md-4">
                                <?php echo $vet_row["vet_email"];?>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                        
                        
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                    </form>
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

</html>
