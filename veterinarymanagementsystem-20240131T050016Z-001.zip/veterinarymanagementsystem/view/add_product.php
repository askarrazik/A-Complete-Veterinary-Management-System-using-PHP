<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once "../model/category_model.php";
include_once "../model/brand_model.php";
include_once "../model/product_model.php";

$categoryObj = new Category();
$brandObj = new Brand();
$productObj = new Product();

$categoryResult=$categoryObj->getAllCategories();
$brandResult = $brandObj->getAllBrands();
$unitResult = $productObj->getAllUnits(); 
?>
<html>
    <head>
        <title>Add Product</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    </head>
    
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                                <div class="col-md-2">
                    <span>
                        <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                        
                        
                    ?>
                    
                    </span>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Add Product</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="products.php">Products Management</a></li>
                        <li>Add Product</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/product_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    <form action="../controller/product_controller.php?status=add_product" method="post" enctype="multipart/form-data">
                        <?php 
                        if(isset($_GET["msg"])){
                            $msg = base64_decode($_GET["msg"]);
                            ?>
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="alert alert-danger">
                                <?php echo $msg; ?>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                        ?>
                        
                    <div class ="row">
                        <div class ="col-md-12">&nbsp;</div>
                    </div>
                        
                    <div class ="row">
                        <div class="col-md-2">
                            <label class="control-label">Product Name</label>
                        </div>
                        <div class="col-md-4">
                            <input type="text" name="prname" id="prname" class="form-control"/>
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">Barcode Number</label>
                        </div>
                        <div class="col-md-4">
                            <input type="text" name="barcode" id="barcode" class="form-control" required="required"/>
                            <span id="displayvalidate"></span>
                        </div>
                        
                    </div>
                        
                    <div class="row">
                        <div class="col-md-12">
                            &nbsp;
                        </div>
                    </div>
                        
                    <div class ="row">
                        <div class="col-md-3">
                            <button type="button" class="btn btn-success" id="generatebtn">
                                <span class="glyphicon glyphicon-refresh"></span>&nbsp;Generate
                            </button>
                        </div>
                        <div class="col-md-9" id="displaybarcode">
                            
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                        
                                            
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="control-label">Category</label>
                            <select class="form-control" id="cat_id" name="cat_id">
                                <?php 
                                    while($cat_row=$categoryResult->fetch_assoc()){
                                        ?>
                                   
                                <option value="<?php echo $cat_row["cat_id"]; ?>">
                                <?php echo ucwords($cat_row["cat_name"]); ?> 
                                </option>
                                <?php
                            }
                            ?>
                            </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="control-label">Brand</label>
                            <select class="form-control" id="brand_id" name="brand_id">
                                <?php 
                                    while($brand_row=$brandResult->fetch_assoc()){
                                        ?>
                                <option value="<?php echo $brand_row["brand_id"]; ?>">
                                <?php echo ucwords($brand_row["brand_name"]); ?>
                                </option>
                                <?php
                                    }
                                    ?>
                            </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="control-label">Unit</label>
                            <select class="form-control" id="unit_id"name="unit_id">
                                <?php
                                while($unit_row=$unitResult->fetch_assoc()){
                                    ?>
                                <option value="<?php echo $unit_row["unit_id"]; ?>">
                                <?php echo $unit_row["unit_name"]; ?>
                                </option>
                                <?php 
                                }
                                ?>
                            </select>
                            </div>
                        </div>
                    </div>
                        
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                        
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="control-label">Price</label>
                                <div class="input-group">
                                <span class="input-group-addon">Rs</span>
                                <input type="text" class="form-control" name="price" id="price"/>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="control-label">Expire Date</label>
                                <input type="date" class="form-control" name="exp_date" id="exp_date"/>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="control-label">Product Image</label>
                                <input type="file" class="form-control" id="product_image "name="product_image" onchange="readImage(this);"/>
                            </div>
                        </div>
                        
                    </div>
                     
                        
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                        
                                            
                    <div class="row">
                        <div class="col-md-6 col-md-offset-9">
                            <br/>
                            <img id="imgprev"/>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 col-md-offset-2">
                            <input type="submit" class="btn btn-success" value="save"/>&nbsp;
                            <input type="reset" class="btn btn-danger" value="reset"/>
                        </div>
                    </div>        
                    </form>
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../JS/productvalidation.js"></script>


<script>
            function readImage(input){
                //check if i have selected the file
                if(input.files && input.files[0]){
                    
                    var reader = new FileReader();
                    reader.onload=function(e){
                        $("#imgprev")
                                .attr('src' , e.target.result)
                                .width(100)
                                .height(80)
                        
                    };
                    
                    reader.readAsDataURL(input.files[0])
                }
            }
        
        
</script>
</html>
