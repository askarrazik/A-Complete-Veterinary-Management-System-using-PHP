<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include '../model/product_model.php';
include '../model/brand_model.php';
include '../model/category_model.php';

$productObj =  new Product();
$brandObj = new Brand();
$categoryObj = new Category();

$totalProductsCount = $productObj->getAllProductsCount();
$activeProductCount = $productObj->getActiveProductsCount();
$deactiveProductCount = $productObj->getDeactiveProductsCount();
$expiringProductCount = $productObj->getExpiringProductsCount();

$totalBrandCount = $brandObj->getAllBrandCount();

$totalCategoryCount = $categoryObj->getAllCategoryCount();
?>
<html>
    <head>
        <title>Products Management</title>
                <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    </head>
    
   
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Products Management</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
                
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li>Products Management</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/product_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    <div class="col-md-12">
                        <div class="panel panel-success" style="height: 45px; background-color: infobackground">        
                                <h4 align="center"/>Total Available Products</h4>
                        </div>
                 
                    </div>
                    <div class="col-md-4 col-md-offset-4">
                        <div class="panel panel-success" style="height: 45px; background-color: #e6ffe6">        
                                <h4 align="center"/><?php echo $totalProductsCount; ?></h4>
                        </div>
                 
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-3">
                            <div class="panel panel-default" style="height: 150px; background-color: lightgreen">
                                <h4 align="center">Active Products</h4>
                                 
                                        <h1 align="center"><?php echo $activeProductCount; ?></h1>
                                    
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="panel panel-default" style="height: 150px; background-color:#ff6666">
                                <h4 align="center">De-Active Products</h4>
                                 
                                    <h1 align="center"><?php echo $deactiveProductCount; ?></h1>
                                        
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="panel panel-default" style="height: 150px; background-color: lightcoral">
                                <h4 align="center">Products Expiring in next 30 Days</h4>
                                 
                                    <h1 align="center"><?php  echo $expiringProductCount; ?></h1>
                                        
                            </div>
                        </div>
                    </div>
                    <hr/>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="panel panel-default" style="height: 150px; background-color: lightblue">
                                <h4 align="center">Brand Count</h4>
                                 
                                        <h1 align="center"><?php echo $totalBrandCount; ?></h1>
                                    
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="panel panel-default" style="height: 150px; background-color:lightskyblue">
                                <h4 align="center">Category Count</h4>
                                 
                                    <h1 align="center"><?php echo $totalCategoryCount; ?></h1>
                                        
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

</html>
