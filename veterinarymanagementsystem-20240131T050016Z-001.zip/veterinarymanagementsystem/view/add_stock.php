<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

include "../model/product_model.php";
include "../model/stock_model.php";

$productObj = new Product();
$stockObj = new Stock();

$productResult = $productObj->getAllProducts();
//getting all products

$moduleArray = $_SESSION["user_module"];
?>
<html>
    <head>
        <title>Add Stock</title>
                <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    <script>
         
        
        
        addStocks =function(productid){
            alert(productid);
             var url="../controller/product_controller.php?status=add_stock_modal";
       
            $.post(url,{product_id:productid}, function(data){
          
            $("#stockcont").html(data);
            
            
        });
        }
            
        </script>   
    </head>
    
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                                <div class="col-md-2">
                    <span>
                        <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                        
                        
                    ?>
                    
                    </span>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Add Stock</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="stock.php">Stock Management</a></li>
                        <li>Add stock</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/stock_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="alert alert-warning">
                                <h4 align="center"> Select a Product to add stock</h4>
                            </div>
                        </div>        
                        <div class="col-md-12">
                            <table class="table table-striped" id="producttable">
                                <thead>
                                    <tr style = "background-color: #456bdd; color: #fff">

                                        <th>Name</th>
                                        <th>Brand</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>All Stock</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        while($product_row=$productResult->fetch_assoc()){

                                           $product_id = base64_encode($product_row["product_id"]);

                                            $tot_qty = $stockObj->getProductStock($product_row["product_id"]);
                                        ?>
                                    <tr>

                                        <td><?php echo ucwords($product_row["product_name"]); ?></td>
                                        <td><?php echo  ucwords($product_row["brand_name"]); ?></td>
                                        <td><?php echo  ucwords($product_row["cat_name"]); ?></td>
                                        <td><?php echo  "Rs ".$product_row["product_price"]; ?></td>
                                        <td>
                                            <?php if($tot_qty>0){ echo $tot_qty; echo $product_row["unit_name"]; } else {echo "No Stock Available";} ?> 
                                        </td>
                                        <td>
                                            <a href="#" class="btn btn-success" data-toggle="modal" data-target="#ModalStock"
                                            onclick = "addStocks('<?php echo $product_id ?>'); " >
                                            <span class="glyphicon glyphicon-plus"></span>
                                                &nbsp;Add Stock
                                            </a>
                                        </td>
                                        

                                        
                                    </tr>
                                    <?php
                                        }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                </div>
               
            </div>
            
            
            
        </div>
        
        <div class="modal fade" id="ModalStock" role="dialog">
            
            <div class="modal-dialog">
                
                <!-- Modal Content -->
                <div class ="modal-content">
                    <form action="../controller/product_controller.php?status=add_stock" method="post">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><span class="glyphicon glyphicon-plus"></span>&nbsp;Add Stock</h4> 
                    </div>
                        <div class="modal-body" id="stockcont">
                        
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-floppy-save"></span>&nbsp;Save
                        </button>
                        &nbsp;
                        <button type="submit" class="btn btn-default" data-dismiss="modal">&nbsp;Close</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>

<script src="../JS/datatable/jquery.dataTables.min.js"></script>
        

<script src="../JS/datatable/dataTables.bootstrap.min.js"></script>
<script>
            
            $(document).ready(function(){
                $("#producttable").DataTable();
            });
</script>
</html>
