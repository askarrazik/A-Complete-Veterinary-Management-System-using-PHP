<?php 

///include pdf library 

include '../commons/fpdf181/fpdf.php';
include_once '../model/manage_vaccine_model.php';
include_once '../model/vaccine_stock_model.php';

$vacObj = new Vaccine();
$vacStockObj = new VaccineStock();

$vaccineResults = $vacObj->getAllVaccine();

$fpdf= new FPDF();

$fpdf->SetTitle("Vaccine Stock Report"); /// set the Title for the Document

$fpdf->AddPage("P", "A4",0);
$fpdf->Image("../images/dashboard/logo_sample.png",10,20,30,30);
$fpdf->SetFont("Times", "B", 16); //// Setting Fonts
$fpdf->Cell(0,20,"Sky Pet Animal Hospital",0,2,"C");

$fpdf->SetFont("Arial", "B", 10); //// Setting Fonts
$fpdf->Cell(0,12,"Sri Lanka Airforce, Guwanpura, Borella, Colombo - 08, Sri Lanka / 0112 495 800",0,1,"C",false);

$fpdf->SetFont("Times", "B", 16); //// Setting Fonts
$fpdf->Cell(0,20,"Vaccine Stock Report",0,1,"C");




$fpdf->SetLeftMargin(30);


$fpdf->SetFont("Times", "B", 13); //// Setting Fonts

///Table Heading
$fpdf->Cell(20,10,"#" ,1, 0, "C");
$fpdf->Cell(35,10,"Vaccine Item" ,1, 0, "C");
$fpdf->Cell(50,10,"Total Quantity Available" ,1, 0, "C");
$fpdf->Cell(25,10,"Status" ,1, 1, "C");


while($vaccine_row=$vaccineResults->fetch_assoc()){
$vaccine_id =($vaccine_row["vaccine_id"]);
                                    
$tot_qty = $vacStockObj->getVaccineStock($vaccine_id);

$fpdf->SetFont("Times", "", 12);
///Table Body
if($vaccine_row["status"]==1){
    $status= "Active";}
    
    else{
        $status = "Deactivated";
    }
$fpdf->Cell(20,15,$vaccine_row["vaccine_id"] ,1, 0, "L");
$fpdf->Cell(35,15,ucwords($vaccine_row["vaccine_item"]),1, 0, "L");
$fpdf->Cell(50,15,$tot_qty,1, 0, "L");
$fpdf->Cell(25,15,ucwords($status) ,1, 1, "L");


}

$fpdf->SetFont("Arial", "B", 8); //// Setting Fonts
$fpdf->Cell(200,10,"" ,0, 1, "L");

$fpdf->Cell(200,10,"This is a Computer Generated Document and requires no Authorized Signature " ,0, 1, "L");
$date = date("Y-m-d  H:i:s");
$fpdf->Cell(200,10,"Generated on: $date" ,0, 1, "L");

if(!isset($_REQUEST["status"])){
    $fpdf->Output(); // Display the PDF on the Browser
}

else{
    $d1="User_report_".$date;
    $filename=$d1. ".pdf";
    $path="../documents/stock_reports/$filename";
    $fpdf->Output($filename, "D");// download the file
}




?>