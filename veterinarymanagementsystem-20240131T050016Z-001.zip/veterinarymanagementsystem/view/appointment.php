<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/appointment_model.php';
$appObj = new Appointment();

$allAppointmentCount = $appObj->getAllAppointmentCount();
$pendingAppointmentCount = $appObj->getPendingAppointmentCount();
$doneAppointmentCount  = $appObj->getDoneAppointmentCount();
$cancelledAppointmentCount  = $appObj->getCancelledAppointmentCount();

?>
<html>
    <head>
        <title>Appointment Management</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
        
    </head>
    
    
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                <div class="col-md-2">
                    <span>
                        <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                        
                        
                    ?>
                    
                    </span>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Appointment Management</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/appointment_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-success" style="height: 45px; background-color: infobackground">        
                                    <h4 align="center"/>No. of Appointments</h4>
                            </div>

                        </div>

                    </div>
                    <div class="row">
                        <div class="col-md-4 col-md-offset-4">
                            <div class="panel panel-success" style="height: 45px; background-color: #e6ffe6">        
                                    <h4 align="center"/><?php  echo $allAppointmentCount; ?></h4>
                            </div>

                        </div>
                    </div>
                                      
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="panel panel-default" style="height: 150px; background-color: lightskyblue">
                                <h4 align="center">Pending Appointments</h4>
                                 
                                        <h1 align="center"><?php echo $pendingAppointmentCount; ?></h1>
                                    
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="panel panel-default" style="height: 150px; background-color:lightgreen ">
                                <h4 align="center">Done Appointments</h4>
                                 
                                    <h1 align="center"><?php echo $doneAppointmentCount; ?></h1>
                                        
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="panel panel-default" style="height: 150px; background-color:#ff6666 ">
                                <h4 align="center">Cancelled Appointments</h4>
                                 
                                    <h1 align="center"><?php  echo $cancelledAppointmentCount; ?></h1>
                                        
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

</html>
