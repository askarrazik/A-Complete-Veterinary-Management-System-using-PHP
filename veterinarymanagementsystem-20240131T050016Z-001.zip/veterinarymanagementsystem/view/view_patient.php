<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/patient_model.php';
$patientObj = new Patient();

$patient_id = $_GET["patient_id"];
$patient_id = base64_decode($patient_id);

$patientResults = $patientObj->getSpecificPatient($patient_id);
$patient_row = $patientResults->fetch_assoc();
?>
<html>
    <head>
        <title>View Patient</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    </head>
    
  
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">View Patient</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
                
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="patient.php">Patient Module</a></li>
                        <li><a href="view_patients.php">View Patients</a></li>
                        <li>View Patient</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/patient_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    
                    <div class ="row">
                        
                        <div class ="col-md-4 col-md-offset-8">
                            <a href="edit_patient.php?patient_id=<?php echo base64_encode($patient_id); ?>" class="btn btn-warning">
                                <span class ="glyphicon glyphicon-pencil"></span>&nbsp;
                                Click here to edit patient details
                            </a>
                            
                        </div>
                    </div>
                    
                                        
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Name :</label>
                        </div>
                        <div class="col-md-4">
                            <?php echo ucwords($patient_row["patient_name"]); ?>
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">Owner :</label>
                        </div>
                        <div class="col-md-4">
                            <?php echo ucwords($patient_row["cus_fname"]." ".$patient_row["cus_lname"]); ?>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Species :</label>
                        </div>
                        <div class="col-md-4">
                            <?php echo ucwords($patient_row["species"]); ?>
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">Breed :</label>
                        </div>
                        <div class="col-md-4">
                            <?php echo ucwords($patient_row["breed"]); ?>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Gender :</label>
                        </div>
                        <div class="col-md-4">
                            <?php if($patient_row["patient_gender"]==0){
                                echo "Male";
                            }
                                else{
                                    echo "Female";
                                }
                             ?>
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">DOB :</label>
                        </div>
                        <div class="col-md-4">
                            <?php echo ucwords($patient_row["patient_dob"]); ?>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Colour :</label>
                        </div>
                        <div class="col-md-4">
                            <?php echo ucwords($patient_row["patient_colour"]); ?>
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">Weight :</label>
                        </div>
                        <div class="col-md-4">
                            <?php echo ucwords($patient_row["patient_weight"])." Kg"; ?>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Notes :</label>
                        </div>
                        <div class="col-md-4">
                            <?php echo ucwords($patient_row["notes"]); ?>
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">Patient Image :</label>
                        </div>
                        <div class="col-md-4">
                            <?php 
                                $patientImage="";
                                if($patient_row["patient_image"]==""){
                                    $patientImage="patientdefault.jpg";
                                }
                                else{
                                    $patientImage=$patient_row["patient_image"];
                                }
                                ?>
                            <img src="../images/patient_images/<?php echo $patientImage; ?>" width="100" height="120px"/>
                        </div>
                        
                    </div>
                        
                    
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../JS/datatable/jquery-3.5.1.js"></script>
        <script src="../JS/datatable/jquery.dataTables.min.js"></script>
        
        <!-- include bootstrap js-->
        <script src="../JS/datatable/dataTables.bootstrap.min.js"></script>

     
</html>
