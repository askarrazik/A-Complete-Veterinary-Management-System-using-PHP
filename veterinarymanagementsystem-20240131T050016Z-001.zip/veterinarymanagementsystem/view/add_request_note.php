<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/product_model.php';
$productObj = new Product();

$productResult = $productObj->getAllProducts();

$unitResult = $productObj->getAllUnits();
?>
<html>
    <head>
        <title>Add Product Requisition Note</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
        
    </head>
   
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                                <div class="col-md-2">
                    <span>
                        <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                        
                        
                    ?>
                    
                    </span>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Add Request Note</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="purhcase.php">Purchase Management</a></li>
                        <li>Add Requisition Note</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/purchase_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    
                    <form action="../controller/purchase_controller.php?status=add_requisition_note" enctype="multipart/form-data" method ="post">
                        
                        <?php 
                        if(isset($_GET["msg"])){
                            $msg = base64_decode($_GET["msg"]);
                            ?>
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="alert alert-danger">
                                <?php echo $msg; ?>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                        ?>  
                        <div class="row">
                            <input type="hidden" name="requested by" value="<?php echo $_SESSION["user"]["user_id"]; ?>"/>
                            
                            <div class="col-md-2">
                                <label class="control_label">Required Date :</label>
                            </div>
                            <div class="col-md-4">
                                <input type="date" name="required_date" id="required_date" class="form-control" value=""required="required"/>
                            </div>
                            
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                        
                        
                        
                         <div class="row">
                             <div class="col-md-12">&nbsp;</div>
                         </div>
                         
                        <div class="row">
                            <div class="col-md-4"><b><i>Required Items</i></b></div>  
                            <div class="col-md-3"><b><i>Quantity </i></b></div>
                            <div class="col-md-3"><b><i>Unit </i></b></div>
                            <div class="col-md-2"><b><i></i></b></div>
                        </div>    
                      
                        <div class="row">
                             <div class="col-md-12">&nbsp;</div>
                        </div>
                        
                         
                        <div class="row">
                            <div class="col-md-4">
                                <select class="form-control" name="product_id[]"  id="product_id" required="required" >
                                    <option value="">--Select the Product--</option>
                                    <?php
                                    while($product_row=$productResult->fetch_assoc()){
                                    ?>
                                        <option value="<?php echo $product_row["product_id"]; ?>">
                                         <?php echo $product_row["product_name"]; ?>
                                        </option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                             
                            <div class="col-md-3">
                                <input type="text" name="product_qty[]" id="product_qty" required="required"  class="form-control"/>
                            </div>
                            
                            <div class="col-md-3">
                                <select class="form-control" name="unit_id[]"  id="unit_id" required="required" >
                                        <option value="">--Select Unit--</option>
                                        <?php
                                        while ($unit_row=$unitResult->fetch_assoc()){
                                        ?>
                                        <option value="<?php echo $unit_row["unit_id"]; ?>">
                                        <?php echo $unit_row["unit_name"]; ?>
                                        </option>
                                        <?php 
                                        } 
                                        ?>
                                </select>    
                            </div>
                            
                            <div class="col-md-2">
                                <a  href="#" class="add_row btn btn-success" ><span class="glyphicon-plus"></span>
                                    Add More
                                </a>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div> 
                         
                        <div class="row new_row">
                             
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 col-md-offset-2">
                                <input type="submit" class="btn btn-success" value="submit"/>&nbsp;
                                <input type="reset" class="btn btn-danger" value="reset"/>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                    </form>
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

<script src="../JS/purchase_validation.js"></script>
</html>

