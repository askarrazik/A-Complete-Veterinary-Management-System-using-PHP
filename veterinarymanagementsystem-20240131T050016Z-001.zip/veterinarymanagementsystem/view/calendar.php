<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/appointment_model.php';
$appObj = new Appointment();

$appResult = $appObj->getAppCalander();

$assignedDates=array();
$assignedId = array();
      
        while($app_row = $appResult->fetch_assoc()){
            
            array_push($assignedDates, $app_row["date"]);
            
        }
        
        

?>
<html>
    <head>
        <title>Calendar</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    <script>
        viewApp = function(app_date){
                //alert(app_date);
                var url = "../controller/appointment_controller.php?status=load_appdate_modal";
                $.post(url,{app_date:app_date},function(data){
                    $("#loadappdata").html(data);
                });
            }
    </script>
    </head>
    
    
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                <div class="col-md-2">
                    <span>
                        <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                        
                        
                    ?>
                    
                    </span>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Calendar</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="appointment.php">Appointment Management</a></li>
                        <li>Calendar</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/appointment_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    
                    <?php
                        /// get today date
                        $today = date("Y-m-d");
                        
                        echo "</br>";
                        
                        //get the date after a month from today date create
                         $dayaftermonth = date('Y-m-d', strtotime($today. ' +1 months') );
                        
                        // all dates between the two dates
                        
                        $period = new DatePeriod(
                          new DateTime($today),
                          new DateInterval("P1D"),
                          new DateTime($dayaftermonth)      
                        );
                        
                        ?>
                    <div class="row">
                        <?php
                        foreach ($period as $key=>$value){
                            
                            // sunday is the 0th day
                            
                            $dayofWeek = $value->format("w");
                            
                            
                            
                            
                            ?>
                    <div class="col-md-2">
                        <div style="width: 110px; height: 110px; border: 1px solid; float: right;

                             <?php
                             
                             $date = $value->format("Y-m-d");
                             if(in_array($date, $assignedDates)){
                                
                                 
                                
                                 ?>
                             background-color:#f28abc
                             <?php
                             }
                             ?>
                             ">
                         <?php
                          
                               //echo $date = $value->format("Y-m-d");
                                //echo "</br>";

                                ?>
                            <h6 class="h4" align="center">
                                <?php echo $day = $value->format("F"); ?>
                            </h6>

                            <h6 class="h5" align="center">
                                <?php echo $day = $value->format("d"); ?>
                            </h6>

                                
                            <?php
                            
                            if(in_array($date, $assignedDates)){
                             
                                
                                ?>
                            <p align="center">
                            <a href="#" class="btn btn-primary list" data-toggle="modal" data-target="#loadApp" onclick="viewApp('<?php echo $date; ?>')" >
                                <span class="glyphicon glyphicon-calendar"></span>
                            </a> </p>

                            <?php
                            
                             
                            }

                            ?>

                        </div>
                                            
                    </div>
                    
                        
                    <?php
                    
                        }
                    
                    ?>
                    
                    </div>

                </div>
            </div>
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            
            
        </div>
        
        <div class="modal fade" id="loadApp" role="dialog">
            
            <div class="modal-dialog">
                
                <--<!-- Modal Content -->
                <div class ="modal-content">
                    
                        
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><span class="glyphicon glyphicon-calendar"></span>&nbsp;View Appointments By Date</h4> 
                    </div>
                        
                    <div class="modal-body">
                        <div id="loadappdata">
                            
                        </div>
                    </div>
                        
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                        
                    
                </div>
            </div>
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>


</html>
