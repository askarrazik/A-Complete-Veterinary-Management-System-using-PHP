<?php 

///include pdf library 

include '../commons/fpdf181/fpdf.php';
include '../model/customer_model.php';


$customerObj= new Customer();


$customerResults = $customerObj->getAllCustomer();

$fpdf= new FPDF();

$fpdf->SetTitle("All Customer Report"); /// set the Title for the Document

$fpdf->AddPage("P", "A4",0);
$fpdf->Image("../images/dashboard/logo_sample.png",10,20,30,30);
$fpdf->SetFont("Times", "B", 16); //// Setting Fonts
$fpdf->Cell(0,20,"Sky Pet Animal Hospital",0,2,"C");

$fpdf->SetFont("Arial", "B", 10); //// Setting Fonts
$fpdf->Cell(0,12,"Sri Lanka Airforce, Guwanpura, Borella, Colombo - 08, Sri Lanka / 0112 495 800",0,1,"C",false);

$fpdf->SetFont("Times", "B", 16); //// Setting Fonts
$fpdf->Cell(0,20,"All Customer Report",0,1,"C");




$fpdf->SetLeftMargin(15);


$fpdf->SetFont("Times", "B", 11); //// Setting Fonts

///Table Heading
$fpdf->Cell(35,10,"Name" ,1, 0, "C");
$fpdf->Cell(50,10,"Address" ,1, 0, "C");
$fpdf->Cell(25,10,"NIC" ,1, 0, "C");
$fpdf->Cell(25,10,"Contact" ,1, 0, "C");
$fpdf->Cell(40,10,"Email" ,1, 1, "C");

while($customer_row=$customerResults->fetch_assoc()){

$fpdf->SetFont("Times", "", 10);
///Table Body
if($customer_row["cus_gender"]==0){
    $gender= "Mr";}
    
    else{
        $gender = "Ms";
    }
$fpdf->Cell(35,15,ucwords($gender." ".$customer_row["cus_fname"]." ".$customer_row["cus_lname"]) ,1, 0, "L");
$fpdf->Cell(50,15,ucwords($customer_row["door_no"].", ".$customer_row["street"].", ".$customer_row["city"]),1, 0, "L");
$fpdf->Cell(25,15,ucwords($customer_row["cus_nic"]),1, 0, "L");
$fpdf->Cell(25,15,ucwords($customer_row["contact_no"]) ,1, 0, "L");
$fpdf->Cell(40,15,$customer_row["cus_email"] ,1, 1, "L");

}

$fpdf->SetFont("Arial", "B", 8); //// Setting Fonts
$fpdf->Cell(200,10,"" ,0, 1, "L");

$fpdf->Cell(200,10,"This is a Computer Generated Document and requires no Authorized Signature " ,0, 1, "L");
$date = date("Y-m-d  H:i:s");
$fpdf->Cell(200,10,"Generated on: $date" ,0, 1, "L");

if(!isset($_REQUEST["status"])){
    $fpdf->Output(); // Display the PDF on the Browser
}

else{
    $d1="User_report_".$date;
    $filename=$d1. ".pdf";
    $path="../documents/stock_reports/$filename";
    $fpdf->Output($filename, "D");// download the file
}




?>