<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];
include_once '../model/patient_model.php';
$patientObj = new Patient();
?>
<html>
    <head>
        <title>View Patients</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    </head>
    
  
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]. " ".$_SESSION["user"]["user_lname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">View Patients</h4>
                </div>
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-bell" id="glyph"></span>
                    &nbsp;
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
                
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="patient.php">Patient Module</a></li>
                        <li>View Patients</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/patient_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-4 col-md-offset-9">
                            <a href="generate_patient_report.php" class="btn btn-success">
                                    <span class="glyphicon glyphicon-book"></span> &nbsp;
                                    Generate Patient Report
                            </a>
                        </div> 
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>    
                            <?php
                        if(isset($_GET["msg"])){
                            $msg = base64_decode($_GET["msg"]);
                    ?>
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="alert alert-success">
                                <p align="center"> <?php echo ucwords($msg);?></p>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    ?>
                    <div class="row">
                    <?php 
                        $patientResults = $patientObj->getAllPatients();
                        ?>
                        <div class="col-md-12">
                            <table class="table table-striped" id="patienttable">
                                <thead>
                                    <tr style = "background-color: #456bdc; color: #fff">
                                        <th>Name</th>
                                        <th>Owner</th>
                                        <th>Species</th>
                                        <th>Breed</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                        
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    while($patient_row = $patientResults->fetch_assoc()){
                                        $patient_id = base64_encode($patient_row["patient_id"]);
                                        ?>
                                    <tr>
                                        <td><?php echo ucwords($patient_row["patient_name"]); ?></td>
                                        <td><?php echo ucwords($patient_row["cus_fname"]); ?></td>
                                        <td><?php echo ucwords($patient_row["species"])?></td>
                                        <td><?php echo ucwords($patient_row["breed"])?></td>
                                        
                                        <td>
                                             <?php 
                                                if($patient_row["patient_status"]==1){
                                            ?>
                                                    <label class="label label-success">Active</label>
                                            <?php
                                                }
                                                
                                                else{
                                            ?>
                                                    <label class="label label-danger">De-active</label>
                                            <?php        
                                                }   
                                            ?>
                                        </td>
                                        
                                        <td>
                                            
                                            <?php
                                            if($patient_row["patient_status"]==1){
                                                ?>
                                            
                                            <a href="view_patient.php?patient_id=<?php echo $patient_id; ?>" class="btn btn-warning"><span class="glyphicon glyphicon-search"></span>&nbsp;view</a>&nbsp;
                                    <?php
                                            }
                                            else{
                                               ?>
                                            <a href="view_patient.php?patient_id=<?php echo $patient_id; ?>" class="btn btn-warning disabled"><span class="glyphicon glyphicon-search"></span>&nbsp;view</a>&nbsp;
                                            <?php
                                            }
                                    ?>
                                        <?php
                                                if($patient_row["patient_status"]==1){
                                            ?>
                                                    <a href="../controller/patient_controller.php?status=deactivate_patient&patient_id=<?php echo $patient_id; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-remove"></span>&nbsp;Deactivate</a>
                                            <?php
                                                }
                                                
                                                else{
                                            ?>        
                                                    <a href="../controller/patient_controller.php?status=activate_patient&patient_id=<?php echo $patient_id; ?>" class="btn btn-success"><span class="glyphicon glyphicon-ok"></span>&nbsp;Activate</a>
                                            <?php        
                                                }
                                            ?>
                                        </td>
                                        
                                        

                                    </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                    
                        </div>
                    </div>
                    
                        
                    
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../JS/datatable/jquery-3.5.1.js"></script>
        <script src="../JS/datatable/jquery.dataTables.min.js"></script>
        
        <!-- include bootstrap js-->
        <script src="../JS/datatable/dataTables.bootstrap.min.js"></script>
        <script>
            
            $(document).ready(function(){
                $("#patienttable").DataTable();
            });
        </script>
</html>
