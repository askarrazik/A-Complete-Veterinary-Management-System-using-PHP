<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/vaccination_model.php';
$vacObj = new Vaccination();
$vaccinationResult = $vacObj->getGivenVaccination();


?>
<html>
    <head>
        <title>View Given Vaccines</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
    
        
        
    <script>
    
        loadgivenvaccines =function(vaccinationId){
            //alert(vaccinationId);
            
            var url = "../controller/vaccination_treatment_controller.php?status=load_given_vaccine_modal";
                $.post(url,{vaccination_id:vaccinationId},function(data){
                    $("#loadgivenvaccines").html(data);
                });
        }
    
    </script>    
    </head>
    
    
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">View Given Vaccines</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="vaccination_treatment.php">Vaccination & Treatment Management</a></li>
                        <li>View Given Vaccine</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/vaccine_treatment_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    
                    <?php 
                        if(isset($_GET["msg"])){
                            $msg = base64_decode($_GET["msg"]);
                            ?>
                        <div class="row">
                            <div class="col-md-6 col-md-offset-3">
                                <div class="alert alert-success">
                                    <p align="center"><?php echo $msg; ?></p>
                                </div>
                            </div>
                        </div>
                        <?php 
                        }
                        ?>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-striped" id="vaccinestable">
                                <thead>
                                    <tr style ="background-color: #1a1aff; color: #fff;">
                                        <th>Patient</th>
                                        <th>Veterinarian</th>
                                        <th>Given Date</th>
                                        <th>Given Vaccines</th>
                                    </tr>
                                </thead>
                                
                                
                                <tbody>
                                    <?php 
                                
                                while($vaccination_row = $vaccinationResult->fetch_assoc()){
                                    $vaccination_id = $vaccination_row["vaccination_id"];
                                    ?>
                                    <tr>
                                    <td><?php echo ucwords($vaccination_row["patient_name"]);?></td>
                                    <td><?php echo ucwords($vaccination_row["vet_fname"]." ".$vaccination_row["vet_lname"]);?></td>
                                    <td><?php echo ucwords($vaccination_row["date"]);?></td>
                                    <td>
                                        <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#viewGivenVaccines" onclick="loadgivenvaccines('<?php echo $vaccination_id;?>')">
                                                <span class="glyphicon glyphicon-search"></span>
                                                &nbsp;Click to view given vaccines
                                        </a>
                                    </td>
                                    </tr>
                                    <?php
                                }
                                ?>
                                </tbody>
                                
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            
            
        </div>
        
        
        
        <div class="modal fade" id="viewGivenVaccines" role="dialog">
            
            <div class="modal-dialog">
                
                <--<!-- Modal Content -->
                <div class ="modal-content">
                    
                        
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><span class="glyphicon glyphicon-time"></span>&nbsp;View Given Vaccines</h4> 
                    </div>
                        
                    <div class="modal-body">
                        <div id="loadgivenvaccines">
                            
                        </div>
                    </div>
                        
                    <div class="modal-footer">
                        
                        &nbsp;
                        <button type="submit" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                        
                    
                </div>
            </div>
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>

<script src="../JS/datatable/jquery-3.5.1.js"></script>
<script src="../JS/datatable/jquery.dataTables.min.js"></script>
        
        <!-- include bootstrap js-->
<script src="../JS/datatable/dataTables.bootstrap.min.js"></script>
<script>
            
            $(document).ready(function(){
                $("#vaccinestable").DataTable();
            });
</script>

</html>
