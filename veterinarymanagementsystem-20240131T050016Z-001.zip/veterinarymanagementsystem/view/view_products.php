<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

include "../model/product_model.php";
include "../model/stock_model.php";

$productObj = new Product();
$stockObj = new Stock();

$productResult = $productObj->getAllProducts();
//getting all products

$moduleArray = $_SESSION["user_module"];
?>
<html>
    <head>
        <title>View Products</title>
                <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
        
    </head>
    
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">View Products</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="products.php">Products Management</a></li>
                        <li>View Products</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/product_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    
                     <?php
                        if(isset($_GET["msg"])){
                            $msg = base64_decode($_GET["msg"]);
                    ?>
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="alert alert-success">
                                <p align="center"> <?php echo ucwords($msg);?></p>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    ?>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-striped" id="producttable">
                                <thead>
                                    <tr style = "background-color: #456bdd; color: #fff">

                                        <th>Name</th>
                                        <th>Brand</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th> Stock</th>
                                        <th>Status</th>
                                        <th>Action</th>



                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        while($product_row=$productResult->fetch_assoc()){

                                           $product_id = base64_encode($product_row["product_id"]);

                                            $tot_qty = $stockObj->getProductStock($product_row["product_id"]);
                                        ?>
                                    <tr>

                                        <td><?php echo ucwords($product_row["product_name"]); ?></td>
                                        <td><?php echo  ucwords($product_row["brand_name"]); ?></td>
                                        <td><?php echo  ucwords($product_row["cat_name"]); ?></td>
                                        <td><?php echo  "Rs ".$product_row["product_price"]; ?></td>
                                        <td>
                                            <?php if($tot_qty>0){ echo $tot_qty; echo $product_row["unit_name"]; } else {echo "No Stock Available";} ?> 
                                        </td>
                                        <td>
                                            <?php 
                                                        if($product_row["product_status"]==1){
                                                    ?>
                                                            <label class="label label-success">Active</label>
                                                    <?php
                                                        }

                                                        else{
                                                    ?>
                                                            <label class="label label-danger">De-active</label>
                                                    <?php        
                                                        }   
                                                    ?>
                                        </td>

                                        <td>



                                            <?php
                                            if($product_row["product_status"]==1){
                                            ?>   
                                            <a href="../controller/product_controller.php?status=deactivate_product&product_id=<?php echo $product_id; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-remove"></span>&nbsp;deactivate</a>
                                            <?php
                                            }

                                            else{
                                                ?>
                                            <a href="../controller/product_controller.php?status=activate_product&product_id=<?php echo $product_id; ?>" class="btn btn-success"><span class="glyphicon glyphicon-ok"></span>&nbsp;Activate</a>
                                                <?php
                                            }
                                            ?>


                                        </td>

                                    </tr>
                                    <?php
                                        }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                </div>
               
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../JS/datatable/jquery.dataTables.min.js"></script>
        

<script src="../JS/datatable/dataTables.bootstrap.min.js"></script>
<script>
            
            $(document).ready(function(){
                $("#producttable").DataTable();
            });
</script>
</html>
