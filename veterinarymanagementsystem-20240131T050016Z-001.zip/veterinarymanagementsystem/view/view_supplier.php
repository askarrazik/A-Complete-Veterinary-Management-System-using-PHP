<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/supplier_model.php';
$supplierObj = new Supplier();

$sup_id = $_GET["supplier_id"];
$sup_id = base64_decode($sup_id);

$supplierResults = $supplierObj->getSpcificSupplier($sup_id);
$supplier_row = $supplierResults->fetch_assoc();

$supplierContactResults = $supplierObj->getSpcificSupplierContact($sup_id);

?>
<html>
    <head>
        <title>View Supplier</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    </head>
    
  
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">View Supplier</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
                
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="supplier.php">Supplier Module</a></li>
                        <li><a href="view_suppliers.php">View Suppliers</a></li>
                        <li>View Supplier</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/supplier_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    
                    <div class ="row">
                        
                        <div class ="col-md-4 col-md-offset-8">
                            <a href="edit_supplier.php?supplier_id=<?php echo base64_encode($sup_id); ?>" class="btn btn-warning">
                                <span class ="glyphicon glyphicon-pencil"></span>&nbsp;
                                Click here to edit supplier details
                            </a>
                            
                        </div>
                    </div>
                    
                                        
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Organization Name :</label>
                        </div>
                        <div class="col-md-10">
                            <?php echo ucwords($supplier_row["sup_org"]); ?>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Contact Land :</label>
                        </div>
                        <?php 
                                            while($contact_row = $supplierContactResults->fetch_assoc()){
                        if($contact_row["contact_type"]==1){
                            ?>
                            <div class="col-md-4">
                            <?php echo $contact_row["contact_no"]; ?>
                            </div>
                        <?php
                            
                        }
                        
                        
                        else{
                            ?>
                            <div class="col-md-2">
                            <label class="control-label">Contact Mobile :</label>
                            </div>
                        
                        <div class="col-md-4">
                            <?php echo $contact_row["contact_no"]; ?>
                        </div>
                        <?php
                        }
                        }
                        ?>
                        
                        
                        
                        
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Registration Number :</label>
                        </div>
                        <div class="col-md-4">
                            <?php echo strtoupper($supplier_row["sup_brn"]); ?>
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">Email :</label>
                        </div>
                        <div class="col-md-4">
                            <?php echo $supplier_row["sup_email"]; ?>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                            <div class="col-md-2">
                                <label class="control-label">Address :</label>
                            </div>
                            
                            <div class="col-md-10">
                                <?php echo ucwords($supplier_row["door_no"].", ".$supplier_row["street"].", ".$supplier_row["city"]); ?>
                            </div>
                        </div>
                        <br/>
                        
                        
                    
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../JS/datatable/jquery-3.5.1.js"></script>
        <script src="../JS/datatable/jquery.dataTables.min.js"></script>
        
        <!-- include bootstrap js-->
        <script src="../JS/datatable/dataTables.bootstrap.min.js"></script>

</html>
