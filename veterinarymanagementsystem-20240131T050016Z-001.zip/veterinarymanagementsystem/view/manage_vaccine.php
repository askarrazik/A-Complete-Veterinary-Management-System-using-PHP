<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

include_once '../model/manage_vaccine_model.php';
include_once '../model/vaccine_stock_model.php';

$vacObj = new Vaccine();
$vacStockObj = new VaccineStock();

$vaccineResults = $vacObj->getAllVaccine();

$moduleArray = $_SESSION["user_module"];
?>
<html>
    <head>
        <title>Manage Vaccine</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
    </head>
    
    
    
     <script>
        
        
        addStockItem =function(vaccine_id){
            alert(vaccine_id);
            var url="../controller/manage_vaccine_controller.php?status=stock_modal";
       
            $.post(url,{vaccineid:vaccine_id}, function(data){
          
            $("#vaccinecont").html(data);
            
            
        ``  });
        }
        
        
            
        </script>
    
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Manage Vaccine</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
                
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="vaccination_treatment.php">Vaccination & Treatment Management</a></li>
                        <li>Manage Vaccine</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/vaccine_treatment_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                <?php 
                                    if(isset($_GET["sucmsg"])){
                                        $msg = base64_decode($_GET["sucmsg"]);
                                        ?>
                                <div class="row">
                                    <div class="col-md-6 col-md-offset-3">
                                        <div class="alert alert-success">
                                            <p align="center"><?php echo ucwords($msg); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                    }
                                    
                                    if(isset($_GET["errmsg"])){
                                        $msg = base64_decode($_GET["errmsg"]);
                                        ?>
                                <div class="row">
                                    <div class="col-md-6 col-md-offset-3">
                                        <div class="alert alert-danger">
                                            <p align="center"><?php echo ucwords($msg); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                    }
                                    if(isset($_GET["msg"])){
                                        $msg = base64_decode($_GET["msg"]);
                                        ?>
                                <div class="row">
                                    <div class="col-md-6 col-md-offset-3">
                                        <div class="alert alert-warning">
                                            <p align="center"><?php echo ($msg); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                    }
                                    ?>
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Add a New Item</label>
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">Quantity :</label>
                        </div>
                        
                    </div>
                    
                    <div class="row">
                        <form action="../controller/manage_vaccine_controller.php?status=add_vaccine" method="post">
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="vac_item" id="item"/>
                            </div>
                            <div class="col-md-2">
                                <input type="number" class="form-control" name="vac_quantity" id="quantity"/>
                            </div>
                            
                            <div class="col-md-2">
                                <input type="date" class="form-control" name="vac_stock_date" id="quantity"/>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-floppy-save"></span>&nbsp;Save</button>

                            </div>

                        </form>   
                    </div>
                    
                    <hr/>
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    
                    
                    
                    <div class="row">
                        <div class="col-md-4">
                            <a href="generate_vaccine_report.php" class="btn btn-success">
                                    <span class="glyphicon glyphicon-book"></span> &nbsp;
                                    Generate Vaccine Stock Report
                            </a>
                        </div> 
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-striped" id="patienttable">
                                <thead>
                                    <tr style ="background-color: #1a1aff; color: #fff;">
                                        <th>#</th>
                                        <th>Item Name</th>
                                        <th>Quantity</th>
                                        <th>Status</th>
                                        <th>More Action</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                while($vaccine_row=$vaccineResults->fetch_assoc()){
                                    
                                    $vaccine_id =($vaccine_row["vaccine_id"]);
                                    
                                    $tot_qty = $vacStockObj->getVaccineStock($vaccine_id);
                                ?>
                                    <tr>
                                        <td> <?php echo $vaccine_row["vaccine_id"]; ?></td>
                                        <td><?php echo  ucwords($vaccine_row["vaccine_item"]); ?></td>
                                        <td><?php echo $tot_qty ?></td>
                                        
                                        <td><?php 
                                        if($vaccine_row["status"]==1){
                                            ?>
                                            <label class="label label-success">Active</label>
                                            <?php
                                        }
                                        else{
                                            ?>
                                            <label class="label label-danger">Deactive</label>
                                        <?php
                                            }
                                        
                                        ?>
                                        </td>
                                            
                                        
                                        <td>
                                            <a href="#" class="btn btn-default" data-toggle="modal" data-target="#ModalStockItem"
                                            onclick = "addStockItem('<?php echo $vaccine_id ?>'); " ><span class="glyphicon glyphicon-chevron-up"></span>&nbsp;Add More Quantity</a>&nbsp;
                                        
                                            
                                        <?php
                                        if($vaccine_row["status"]==1){
                                            
                                        ?>
                                            <a href="../controller/manage_vaccine_controller.php?status=deactivate_vaccine&vaccine_id=<?php echo $vaccine_id; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-remove"></span>&nbsp;Deactivate</a>
                                        <?php
                                            }
                                        else{
                                            ?>
                                            <a href="../controller/manage_vaccine_controller.php?status=activate_vaccine&vaccine_id=<?php echo $vaccine_id; ?>" class="btn btn-success"><span class="glyphicon glyphicon-ok"></span>&nbsp;Activate</a>
                                        
                                        <?php
                                        }
                                        ?>
                                        </td>
                                        

                                    </tr>
                                  <?php
                                }
                                ?>
                                </tbody>
                            </table>
                    
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    
                    
                    
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            
            
        </div>

        
        
        
        
        
        
        
        
        <div class="modal fade" id="ModalStockItem" role="dialog">
            
            <div class="modal-dialog">
                
                <--<!-- Modal Content -->
                <div class ="modal-content">
                    <form action="../controller/manage_vaccine_controller.php?status=add_stock_item" method="post">
                        
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><span class="glyphicon glyphicon-plus"></span>&nbsp;Add Vaccine Stock</h4> 
                    </div>
                        
                    <div class="modal-body">
                        <div id="vaccinecont">
                            
                        </div>
                    </div>
                        
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-floppy-save"></span>&nbsp;Save
                        </button>
                        &nbsp;
                        <button type="submit" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                        
                    </form>
                </div>
            </div>
            
            
            
            
        </div>
    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>comment -->
<script src="../JS/datatable/jquery-3.5.1.js"></script>
        <script src="../JS/datatable/jquery.dataTables.min.js"></script>
        
        <!-- include bootstrap js-->
        <script src="../JS/datatable/dataTables.bootstrap.min.js"></script>
        <script>
            
            $(document).ready(function(){
                $("#patienttable").DataTable();
            });
        </script>

</html>
