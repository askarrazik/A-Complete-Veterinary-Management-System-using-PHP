<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];
?>
<html>
    <head>
        <title>Dashboard</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
        
    </head>
    
    <style>
        
        body{
             background-image: linear-gradient(to right, rgba(0,0,255,0), rgba(0,121,235,0.2));
        }
        
        .panel {
            transition: transform .3s; /* Animation */
        }
 

        .panel:hover {
          transform: scale(1.1);
          border: 1px solid darkblue;
          
        }
        
    </style>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                                <div class="col-md-2">
                    <span>
                        <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                        
                        
                    ?>
                    
                    </span>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center"><?php echo ucwords($_SESSION["user"]["role_name"]);?> Panel</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li>Dashboard</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
               <?php
               foreach($moduleArray as $mod){
                   ?>
                <a href="<?php echo $mod["module_url"];?>">
                <div class="col-md-3">
                    <div class="panel panel-primary" style="height: 225px">
                        <div class="panel-heading" style="height:75px">
                            <h4 align="center">
                                <?php echo ucwords($mod["module_name"]); ?>
                            </h4>
                        </div>
                        <div class=" panel-body">
                            <p align="center">
                                <img src="../images/dashboard/<?php echo $mod["module_image"]; ?>" width="200px" height="130px"/>
                            </p>
                        </div>
                    </div>
                </div>
                
                
                <?php
                
                }
                ?>
            </div>
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>


</html>
