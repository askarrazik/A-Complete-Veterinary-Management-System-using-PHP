<!doctype html>
<?php

include_once "../commons/session.php";

// getting user module information
$moduleArray = $_SESSION['user_module'];

include "../model/category_model.php";
include "../model/brand_model.php";

$categoryObj = new Category();
$brandObj = new Brand();

$categoryResult = $categoryObj->getAllCategories();
$brandResult = $brandObj->getAllBrands();
        
        


?>
<html>
    <head>
        <!--include bootstrap css -->
        <title>Categories and Brands</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
        <script>
         
        loadCategory = function(catid){
            
             var url="../controller/product_controller.php?status=load_category";
       
            $.post(url,{cat_id:catid}, function(data){
          
            $("#dynamiccat").html(data);
        });
        }
        
        
        loadBrand =function(brandid){
             var url="../controller/product_controller.php?status=load_brand";
       
            $.post(url,{brand_id:brandid}, function(data){
          
            $("#dynamicbrand").html(data);
        });
        }
            
        </script>
        
    </head>

    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                <div class="col-md-2">
                    <span>
                        <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                        
                        
                    ?>
                    
                    </span>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Categories and Brands</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="products.php">Products Management</a></li>
                        <li>Categories and Brands</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/product_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    <?php
                if(isset($_REQUEST["msg"]) || isset($_REQUEST["error"])){
            ?>
            
            
            <div class="row">
                <div class="col-md-4 col-md-offset-4">
                    <?php 
                        if(isset($_REQUEST["msg"])){
                    ?>
                    <div class="alert alert-success">
                        
                           <p align="center"> <?php echo base64_decode($_REQUEST["msg"]); ?></p>
                        
                    </div>
                    <?php
                        }
                        ?>
                    <?php 
                        if(isset($_REQUEST["error"])){
                    ?>
                    <div class="alert alert-danger">
                        
                        <p align="center"> <?php echo base64_decode($_REQUEST["error"]); ?> </p>
                        
                    </div>
                    <?php
                        }
                        ?>
                </div>
            </div>
           
            
            <?php
                }
                ?>
            
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-12">
                                <a href="#" class="btn btn-success" data-toggle="modal" data-target="#myModal">
                                    <span class="glyphicon glyphicon-plus"></span>
                                    &nbsp;Add Categories
                                </a>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                        
                        <h4 align="center">Categories</h4>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th> Category Id</th>
                                    <th> Category Name</th>
                                    <th> &nbsp;</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    while($cat_row=$categoryResult->fetch_assoc()){
                                        $cat_id=$cat_row["cat_id"];
                                ?>
                                <tr>
                                    <td> <?php echo $cat_row["cat_id"]; ?></td>
                                    <td> <?php echo ucwords($cat_row["cat_name"]); ?></td>
                                    <td>
                                        <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#editCat"
                                            onclick = "loadCategory('<?php echo $cat_id ?>'); ">
                                            <span class="glyphicon glyphicon-pencil"></span>
                                                &nbsp;Edit
                                        </a>
                                    </td>
                                </tr>
                                    <?php
                                    }
                                    ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-12">
                                <a href="#" class="btn btn-success" data-toggle="modal" data-target="#ModalBrand">
                                    <span class="glyphicon glyphicon-plus"></span>
                                    &nbsp;Add Brand
                                </a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                        
                        <h4 align="center">Brands</h4>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th> Brand Id</th>
                                    <th> Brand Name</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                <?php
                                    while($brand_row=$brandResult->fetch_assoc()){
                                        $brand_id=$brand_row["brand_id"];
                                ?>
                                    <td> <?php echo $brand_row["brand_id"]; ?></td>
                                    <td> <?php echo ucwords($brand_row["brand_name"]); ?></td>
                                    <td>
                                        <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#ModalBrandEdit"
                                            onclick = "loadBrand('<?php echo $brand_id ?>'); ">
                                            <span class="glyphicon glyphicon-pencil"></span>
                                                &nbsp;Edit
                                        </a>
                                    </td>
                                </tr    >
                                <?php
                                    }
                                    ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
            
            
            
       
        <!-- Category Modal -->
        <div class="modal fade" id="myModal" role="dialog">
            
            <div class="modal-dialog">
                
                <!-- Modal Content -->
                <div class ="modal-content">
                    <form action="../controller/product_controller.php?status=add_category" method="post">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><span class="glyphicon glyphicon-plus"></span>&nbsp;Add Category</h4> 
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-3">
                                <label>Category Name</label>
                                    
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="cat_name"/>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-floppy-save"></span>&nbsp;Save
                        </button>
                        &nbsp;
                        <button type="submit" class="btn btn-default" data-dismiss="modal">&nbsp;Close</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Edit Category Modal -->
        
         <div class="modal fade" id="editCat" role="dialog">
            
            <div class="modal-dialog">
                
                <--<!-- Modal Content -->
                <div class ="modal-content">
                    <form action="../controller/product_controller.php?status=update_category" method="post">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><span class="glyphicon glyphicon-pencil"></span>&nbsp;Edit Category</h4> 
                    </div>
                    <div class="modal-body">
                        <div id="dynamiccat">
                           
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-floppy-save"></span>&nbsp;Save
                        </button>
                        &nbsp;
                        <button type="submit" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Brand Model -->
        <div class="modal fade" id="ModalBrand" role="dialog">
            
            <div class="modal-dialog">
                
                <!-- Modal Content -->
                <div class ="modal-content">
                    <form action="../controller/product_controller.php?status=add_brand" method="post">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><span class="glyphicon glyphicon-plus"></span>&nbsp;Add Brand</h4> 
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-3">
                                <label>Brand Name</label>
                                    
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="brand_name"/>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-floppy-save"></span>&nbsp;Save
                        </button>
                        &nbsp;
                        <button type="submit" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Edit Brand -->
            <div class="modal fade" id="ModalBrandEdit" role="dialog">
            
            <div class="modal-dialog">
                
                <!-- Modal Content -->
                <div class ="modal-content">
                    <form action="../controller/product_controller.php?status=update_brand" method="post">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><span class="glyphicon glyphicon-pencil"></span>&nbsp;Edit Brand</h4> 
                    </div>
                    <div class="modal-body">
                        <div id="dynamicbrand">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-floppy-save"></span>&nbsp;Save
                        </button>
                        &nbsp;
                        <button type="submit" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </body>
<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>

<script src="../JS/datatable/jquery-3.5.1.js"></script>
</html>
