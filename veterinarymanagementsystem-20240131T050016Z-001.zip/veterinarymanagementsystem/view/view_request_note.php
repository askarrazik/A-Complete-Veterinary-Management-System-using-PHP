<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/product_model.php';
include_once '../model/purchase_model.php';

$productObj = new Product();
$purchaseObj = new Purchase();

$productResult = $productObj->getAllProducts();

$unitResult = $productObj->getAllUnits();

$requisitionNoteResult = $purchaseObj->getAllRequisitionNote();


?>
<html>
    <head>
        <title>VIew Product Requisition Notes</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    
     <script>
            loadItems = function(noteId){
                
                var url = "../controller/purchase_controller.php?status=load_note_item_modal";
                $.post(url,{note_id:noteId},function(data){
                    $("#loaditemsdata").html(data);
                });
            }
            
        </script>
    </head>
   
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">View Product Requisition Notes</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
                
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="purhcase.php">Purchase Management</a></li>
                        <li>View Requisition Notes</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/purchase_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                        <?php 
                        if(isset($_GET["msg"])){
                            $msg = base64_decode($_GET["msg"]);
                            ?>
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="alert alert-success">
                                <p align="center"><?php echo $msg; ?> &nbsp;<span class="glyphicon glyphicon-check"></span></p>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                        ?>  
                    
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-striped" id="notetable">
                                <thead>
                                    <tr style ="background-color: #1a1aff; color: #fff;">
                                        <th>Required Date</th>
                                        <th>Requested By</th>
                                        <th>Approved By</th>
                                        <th>Approval Status</th>
                                        <th>View Items</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                                <tbody>
                                    <?php
                                    while($note_row = $requisitionNoteResult->fetch_assoc()){
                                        
                                        $note_id = base64_encode($note_row["note_id"])
                                        ?>
                                    
                                    <td><?php echo $note_row["requisition_date"];?></td>
                                    <td><?php echo ucwords($note_row["user_fname"]." ".$note_row["user_lname"]); ?></td>
                                    
                                        <?php
                                            $approvalResult = $purchaseObj->getNoteApprovedPerson($note_row["note_id"]);
                                            
                                            $approval_row = $approvalResult->fetch_assoc();
                                            if($approval_row["is_approved"]==1){
                                                ?>
                                    <td>  <?php echo ucwords($approval_row["user_fname"]." ".$approval_row["user_lname"]); ?></td>
                                    <?php
                                            }
                                            else{
                                                ?>
                                    <td>--</td>
                                    <?php
                                            }
                                        ?>
                                    
                                    <td>
                                    <?php 
                                                if($note_row["is_approved"]==1){
                                            ?>
                                                    <label class="label label-success">approved</label>
                                            <?php
                                                }
                                                
                                                else{
                                            ?>
                                                    <label class="label label-primary">Pending</label>
                                            <?php        
                                                }   
                                            ?>
                                    </td>
                                    <td>
                                        <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#viewItem" onclick="loadItems('<?php echo $note_id;?>')">
                                                <span class="glyphicon glyphicon-folder-open"></span>
                                                &nbsp;View Items
                                        </a>
                                    </td>
                                    <td>
                                        <?php
                                           if($note_row["is_approved"]==0){
                                            ?>
                                                    <a href="../controller/purchase_controller.php?status=approve_note&note_id=<?php echo $note_id; ?>" class="btn btn-success"><span class="glyphicon glyphicon-check"></span>&nbsp;Approve</a>
                                            <?php
                                                }
                                                
                                                else{
                                            ?>        
                                                    <a href="../controller/purchase_controller.php?status=reject_note&note_id=<?php echo $note_id; ?> " class="btn btn-danger"><span class="glyphicon glyphicon-remove-sign"></span>&nbsp;Not Now</a>
                                            <?php        
                                                }
                                            ?>
                                                    <a href="generate_requisition_note.php?note_id=<?php echo $note_id; ?>" class="btn btn-default">
                                                    <span class="glyphicon glyphicon-print"></span></a>
                                    </td>
                                </tbody>
                                <?php
                                }
                                ?>
                            </table>
                        </div>
                        
                    </div>
                </div>
            </div>
            
            
            
        </div>
    
    <div class="modal fade" id="viewItem" role="dialog">
            
            <div class="modal-dialog">
                
                <--<!-- Modal Content -->
                <div class ="modal-content">
                    
                        
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><span class="glyphicon glyphicon-folder-open"></span>&nbsp; Requested Products</h4> 
                    </div>
                        
                    <div class="modal-body">
                        <div id="loaditemsdata">
                            
                        </div>
                    </div>
                        
                    <div class="modal-footer">
                        
                        &nbsp;
                        <button type="submit" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                        
                    
                </div>
            </div>
        </div>    
    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="../JS/purchase_validation.js"></script>
<script src="../JS/datatable/jquery.dataTables.min.js"></script>
<script src="../JS/datatable/dataTables.bootstrap.min.js"></script>
<script>
            
            $(document).ready(function(){
                $("#notetable").DataTable();
            });
</script>
</html>

