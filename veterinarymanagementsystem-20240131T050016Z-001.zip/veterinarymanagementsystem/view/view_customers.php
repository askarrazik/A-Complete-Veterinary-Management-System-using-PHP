<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];
include_once '../model/customer_model.php';
$customerObj = new Customer();
$customerResults = $customerObj->getAllCustomer();
?>
<html>
    <head>
        <title>View Customers</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    </head>
    

    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">View Customers</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="customer.php">Customer Module</a></li>
                        <li>View Customers</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/customer_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    <div class="row">
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                    </div>
                        
                    <div class="row">
                        <div class="col-md-4 col-md-offset-8">
                            <a href="generate_customer_report.php" class="btn btn-success">
                                    <span class="glyphicon glyphicon-book"></span> &nbsp;
                                    Generate Customer Report
                            </a>
                        </div> 
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                        <?php 
                                    if(isset($_GET["msg"])){
                                        $msg = base64_decode($_GET["msg"]);
                                        ?>
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="alert alert-success">
                                <p align="center"><?php echo ucwords($msg); ?></p>
                            </div>
                        </div>
                    </div>
                                <?php
                                    }
                                    ?>
                        <div class="col-md-12">
                            <table class="table table-striped" id="customertable">
                                <thead>
                                    <tr style ="background-color: #1a1aff; color: #fff;">
                                        <th>Name</th>
                                        <th>Mobile</th>
                                        <th>NIC</th>
                                        <th>Email</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                                <tbody>
                                    <?php
                                    while($customer_row = $customerResults->fetch_assoc()){
                                        
                                        $customer_id = base64_encode($customer_row["cus_id"])
                                        ?>
                                    
                                    <td><?php echo ucwords($customer_row["cus_fname"]." ");echo ucwords($customer_row["cus_lname"]);?></td>
                                    <td><?php echo $customer_row["contact_no"]; ?></td>
                                    <td><?php echo $customer_row["cus_nic"]; ?></td>
                                    <td><?php echo $customer_row["cus_email"]; ?></td>
                                    <td>
                                    <?php 
                                                if($customer_row["cus_status"]==1){
                                            ?>
                                                    <label class="label label-success">Active</label>
                                            <?php
                                                }
                                                
                                                else{
                                            ?>
                                                    <label class="label label-danger">De-active</label>
                                            <?php        
                                                }   
                                            ?>
                                    </td>
                                    <td>
                                        <?php
                                            if($customer_row["cus_status"]==1){
                                                ?>
                                            
                                            <a href="view_customer.php?customer_id=<?php echo $customer_id; ?>" class="btn btn-warning"><span class="glyphicon glyphicon-search"></span>&nbsp;view</a>&nbsp;
                                    <?php
                                            }
                                            else{
                                               ?>
                                            <a href="view_patient.php?customer_id=<?php echo $customer_id; ?>" class="btn btn-warning disabled"><span class="glyphicon glyphicon-search"></span>&nbsp;view</a>&nbsp;
                                            <?php
                                            }
                                    ?>
                                        <?php
                                                if($customer_row["cus_status"]==1){
                                            ?>
                                                    <a href="../controller/customer_controller.php?status=deactivate_customer&customer_id=<?php echo $customer_id; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-remove"></span>&nbsp;Deactivate</a>
                                            <?php
                                                }
                                                
                                                else{
                                            ?>        
                                                    <a href="../controller/customer_controller.php?status=activate_customer&customer_id=<?php echo $customer_id; ?>" class="btn btn-success"><span class="glyphicon glyphicon-ok"></span>&nbsp;Activate</a>
                                            <?php        
                                                }
                                            ?>
                                    </td>
                                </tbody>
                                <?php
                                }
                                ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../JS/datatable/jquery.dataTables.min.js"></script>
<script src="../JS/datatable/dataTables.bootstrap.min.js"></script>
<script>
            
            $(document).ready(function(){
                $("#customertable").DataTable();
            });
</script>

</html>
