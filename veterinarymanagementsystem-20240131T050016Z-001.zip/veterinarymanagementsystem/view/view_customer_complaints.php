<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/customer_model.php';
$customerObj = new Customer();

?>
<html>
    <head>
        <title>Customer Complaints</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    </head>
    
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Customer Complaints</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="customer.php">Customer Module</a></li>
                        <li>Complaints & Suggestions</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/customer_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    <?php 
                                    if(isset($_GET["sucmsg"])){
                                        $msg = base64_decode($_GET["sucmsg"]);
                                        ?>
                                <div class="row">
                                    <div class="col-md-6 col-md-offset-3">
                                        <div class="alert alert-success">
                                            <p align="center"><?php echo ucwords($msg); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                    }
                                    
                                    if(isset($_GET["errmsg"])){
                                        $msg = base64_decode($_GET["errmsg"]);
                                        ?>
                                <div class="row">
                                    <div class="col-md-6 col-md-offset-3">
                                        <div class="alert alert-danger">
                                            <p align="center"><?php echo ucwords($msg); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                    }
                                    ?>
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Add Customer Complaints</label>
                        </div>
                                                
                    </div>
                    <form action="../controller/customer_controller.php?status=add_complaint" method="post">
                    <div class="row">
                        
                            <div class="col-md-6">
                                <textarea class="form-control" id="complaint" name="complaint"></textarea>
                            </div>   
                           
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-floppy-save"></span>&nbsp;Save</button>
                        </div>
                    </div>
                    </form>
                    
                    <hr/>
                    
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-striped" id="patienttable">
                                <thead>
                                    <tr style ="background-color: #ff5500; color: #fff;">
                                        <th>#</th>
                                        <th>Complaints</th>
                                                                               
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $customerComplaintResult = $customerObj->getAllComplaints();
                                    while($complaint_row = $customerComplaintResult->fetch_assoc()){
                                        
                                        $complaint_id = $complaint_row["comp_id"]; 
                                        ?>
                                    <tr>
                                        <td><?php echo $complaint_id; ?></td>
                                        <td><?php echo ucwords($complaint_row["complaint"]);?></td>
                                        
                                    </tr>
                                    <?php
                                    }
                                    ?>
                                  
                                </tbody>
                            </table>
                    
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    
                    
                    
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

</html>
