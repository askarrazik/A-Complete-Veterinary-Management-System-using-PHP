<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/appointment_model.php';
$appObj = new Appointment();

$appointmentTypeResult = $appObj->getAppointmentType();
?>
<html>
    <head>
        <title>Add Appointment</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    </head>
    
  
    
   <script>
        
        
        loadOwner= function(ownerid,owner)
         {
          // alert(ownerid); 
            //alert(owner);
           var ownerid =  ownerid;
           var owner = owner
           $("#owner_name").val(owner);
           $("#owner_id").val(ownerid);
           
           $("#view_owners").hide();
           
          
         }
        
        loadVet= function(vet_id,veterinarian)
         {
           //alert(vet_id); 
            
           var vet_id =  vet_id;
           var veterinarian = veterinarian
           $("#vet_name").val(veterinarian);
           $("#vet_id").val(vet_id);
           
           $("#view_vets").hide();
           
           
         }
    </script>
    
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                                <div class="col-md-2">
                    <span>
                        <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                        
                        
                    ?>
                    
                    </span>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Add Appointment</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="appointment.php">Appointment Management</a></li>
                        <li>Add Appointment</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/appointment_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    
                    <form action="../controller/appointment_controller.php?status=add_appointment" method="post" enctype="multipart/form-data">
                        <?php 
                        if(isset($_GET["msg"])){
                            $msg = base64_decode($_GET["msg"]);
                            ?>
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="alert alert-danger">
                                <p align ="center"><?php echo ucwords($msg);  ?> </p>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                        ?>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Customer Name :</label>
                        </div>
                        
                        <div class="col-md-4">
                            <input type="hidden" id="owner_id" name="cus_id" value=""/>
                            <input type="text" class="form-control" name="cus_name" id="owner_name"/>
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">Appointment Type :</label>
                        </div>
                        
                        <div class="col-md-4">
                            <select class="form-control" name="app_type" id="app_type">
                                <option value="">--Select Here--</option>
                                <?php
                                while($type_row = $appointmentTypeResult->fetch_assoc()){
                                    ?>
                                <option value="<?php echo $type_row["app_type_id"];?>"><?php echo ucwords($type_row["app_type"]);?></option>
                               <?php 
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12" id="view_owners">
                            
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        
                        <div class="col-md-2">
                            <label class="control-label">Date :</label>
                        </div>
                        
                        <div class="col-md-4">
                            <input type="date" class="form-control" name="app_date" id="app_date"/>
                        </div>
                        
                        <div class="col-md-2">
                            <label class="control-label">Time :</label>
                        </div>
                        
                        <div class="col-md-4">
                            <input type="time" class="form-control" name="app_time" id="vet"/>
                        </div>
                        
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        
                        
                        <div class="col-md-2">
                            <label class="control-label">Veterinarian :</label>
                        </div>
                        
                        <div class="col-md-4">
                            <input type="hidden" id="vet_id" name="vet_id" value=""/>
                            <input type="text" class="form-control" name="vet_name" id="vet_name"/>
                        </div>
                    </div>
                        
                    <div class="row">
                        <div class="col-md-12" id="view_vets">
                            
                        </div>
                    </div>    
                    
                    <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                        
                        
                    <div class="row">
                        <div class="col-md-6 col-md-offset-2">
                                <input type="submit" class="btn btn-success" value="save"/>&nbsp;
                                <input type="submit" class="btn btn-danger" value="reset"/>
                            </div>
                        </div>
                    </form>
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                    
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>


<script src="../JS/patient_validation.js"></script>
<script src="../JS/appointment_validation.js"></script>

</html>
