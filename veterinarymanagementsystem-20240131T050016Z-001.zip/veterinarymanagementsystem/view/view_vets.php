<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/veterinarian_model.php';
$vetObj = new Veterinarian();


$vetResults = $vetObj->getAllVets();

?>
<html>
    <head>
        <title>View Veterinarians </title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        <script>
            loadVet = function(vetId){
                
                var url = "../controller/veterinarian_controller.php?status=load_vet_modal";
                $.post(url,{vet_id:vetId},function(data){
                    $("#loadvetdata").html(data);
                });
            }
            
            loadVetSchedules = function(vetId){
                
                var url = "../controller/schedule_controller.php?status=load_vet_schedules_modal";
                $.post(url,{vet_id:vetId},function(data){
                    $("#loadvetschedules").html(data);
                });
            }
            
            editSchedule = function(vetScheduleId){
                
                var url = "../controller/schedule_controller.php?status=load_schedule_modal";
                $.post(url,{vet_schedule_id:vetScheduleId},function(data){
                    $("#editschedule").html(data);
                });
            }
        </script>
        
    </head>
  
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">View Veterinarians</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="veterinarian.php">Veterinarian Management</a></li>
                        <li>View Veterinarians</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/veterinarian_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    
                    <?php
                        if(isset($_GET["msg"])){
                            $msg = base64_decode($_GET["msg"]);
                    ?>
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="alert alert-success">
                                <p align="center"> <?php echo ucwords($msg);?></p>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    ?>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-striped" id="patienttable">
                                <thead>
                                    <tr style ="background-color: #1a1aff; color: #fff;">
                                        
                                        <th>Name</th>
                                        <th>Mobile</th>
                                        <th>Status</th>
                                        <th></th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php 
                                    while($vet_row = $vetResults->fetch_assoc()){
                                        $vet_id = base64_encode($vet_row["vet_id"]);
                                        ?>
                                    
                                    <tr>
                                        
                                        <td><?php echo ucwords($vet_row["vet_fname"]." ".$vet_row["vet_lname"]); ?></td>
                                        <td><?php echo $vet_row["contact_no"]; ?></td>
                                        <td>
                                            <?php 
                                                if($vet_row["status"]==1){
                                                    
                                            ?>
                                                    <label class="label label-success">Active</label>
                                            <?php
                                                }
                                                
                                                else{
                                            ?>
                                                    <label class="label label-danger">Deactive</label>
                                            <?php        
                                                }   
                                            ?>
                                            
                                        </td>
                                            
                                        <td>
                                             <?php
                                                if($vet_row["status"]==1){
                                            ?>
                                            <a href="#" class="btn btn-success" data-toggle="modal" data-target="#addSchedule" onclick="loadVet('<?php echo $vet_id;?>')">
                                                <span class="glyphicon glyphicon-time"></span>
                                                &nbsp;Add Schedule 
                                            </a>
                                            <?php
                                                }
                                                
                                                else{
                                                    ?>
                                            <a href="#" class="btn btn-success disabled" data-toggle="modal" data-target="#addSchedule" onclick="loadVet('<?php echo $vet_id;?>')">
                                                <span class="glyphicon glyphicon-time"></span>
                                                &nbsp;Add Schedule 
                                            </a>        
                                                    <?php
                                                }
                                                ?>
                                            <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#viewSchedule" onclick="loadVetSchedules('<?php echo $vet_id;?>')">
                                                <span class="glyphicon glyphicon-edit"></span>
                                                &nbsp;View Schedules
                                            </a>
                                            
                                            <?php
                                                if($vet_row["status"]==1){
                                            ?>
                                            <a href="view_vet.php?vet_id=<?php echo $vet_id; ?>" class="btn btn-primary"><span class="glyphicon glyphicon-book"></span>&nbsp;View</a>&nbsp;
                                            <?php
                                                }
                                                else{
                                                 ?>
                                            <a href="view_vet.php?vet_id=<?php echo $vet_id; ?>" class="btn btn-primary disabled"><span class="glyphicon glyphicon-book"></span>&nbsp;View</a>&nbsp;
                                            <?php
                                                }
                                            
                                                if($vet_row["status"]==1){
                                            ?>
                                                    <a href="../controller/veterinarian_controller.php?status=deactivate_vet&vet_id=<?php echo $vet_id; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-remove"></span>&nbsp;Deactivate</a>
                                            <?php
                                                }
                                                
                                                else{
                                            ?>        
                                                    <a href="../controller/veterinarian_controller.php?status=activate_vet&vet_id=<?php echo $vet_id; ?>" class="btn btn-success"><span class="glyphicon glyphicon-ok"></span>&nbsp;Activate</a>
                                            <?php        
                                                }
                                            ?>
                                        </td>
                                        

                                    </tr>
                                    <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                </div>
            </div>
            
            
            
        </div>
        
        <div class="modal fade" id="addSchedule" role="dialog">
            
            <div class="modal-dialog">
                
                <--<!-- Modal Content -->
                <div class ="modal-content">
                    <form action="../controller/schedule_controller.php?status=add_schedule" method="post">
                        
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><span class="glyphicon glyphicon-plus"></span>&nbsp;Add Schedule</h4> 
                    </div>
                        
                    <div class="modal-body">
                        <div id="loadvetdata">
                            
                        </div>
                    </div>
                        
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-floppy-save"></span>&nbsp;Save
                        </button>
                        &nbsp;
                        <button type="submit" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                        
                    </form>
                </div>
            </div>
        </div>
        
        <div class="modal fade" id="viewSchedule" role="dialog">
            
            <div class="modal-dialog">
                
                <--<!-- Modal Content -->
                <div class ="modal-content">
                    
                        
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><span class="glyphicon glyphicon-time"></span>&nbsp;View Schedules</h4> 
                    </div>
                        
                    <div class="modal-body">
                        <div id="loadvetschedules">
                            
                        </div>
                    </div>
                        
                    <div class="modal-footer">
                        
                        &nbsp;
                        <button type="submit" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                        
                    
                </div>
            </div>
        </div>
        
        <div class="modal fade" id="editSchedule" role="dialog">
            
            <div class="modal-dialog">
                <form action="../controller/schedule_controller.php?status=edit_schedule" method="post">
                <!-- Modal Content -->
                <div class ="modal-content">
                    
                        
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><span class="glyphicon glyphicon-time"></span>&nbsp;Edit Schedule</h4> 
                    </div>
                        
                    <div class="modal-body">
                        <div id="editschedule">
                            
                        </div>
                    </div>
                        
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-floppy-save"></span>&nbsp;Save
                        </button>
                        &nbsp;
                        <button type="submit" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                        
                
                </div>
                </form>
            </div>
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>

<script src="../JS/datatable/jquery-3.5.1.js"></script>
<script src="../JS/datatable/jquery.dataTables.min.js"></script>
        
        <!-- include bootstrap js-->
<script src="../JS/datatable/dataTables.bootstrap.min.js"></script>
<script>
            
            $(document).ready(function(){
                $("#patienttable").DataTable();
            });
</script>

</html>
