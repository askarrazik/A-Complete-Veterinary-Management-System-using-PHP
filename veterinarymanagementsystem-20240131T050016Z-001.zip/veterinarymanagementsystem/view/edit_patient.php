<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/patient_model.php';
$patientObj = new Patient();

$patient_id = $_GET["patient_id"];
$patient_id = base64_decode($patient_id);

$patientResults = $patientObj->getSpecificPatient($patient_id);
$patient_row = $patientResults->fetch_assoc();

$speciesResult = $patientObj->getPatientSpecies();

?>
<html>
    <head>
        <title>Edit Patient</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    </head>
    
    <script>
        
        loadOwner= function(ownerid,owner)
         {
          // alert(ownerid); 
            //alert(owner);
           var ownerid =  ownerid;
           var owner = owner
           $("#owner_name").val(owner);
           $("#owner_id").val(ownerid);
           
           $("#view_owners").hide();
           
           
           
    
           // $.post(url,{owner_id:ownerid},function(data){
         
      
         
         
             //});
         }
    </script>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Edit Patient</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="patient.php">Patient Module</a></li>
                        <li><a href="view_patients.php">View Patients</a></li>
                        <li>Edit Patient</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/patient_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    
                    <form action="../controller/patient_controller.php?status=update_patient" enctype="multipart/form-data" method ="post">
                     <?php 
                        if(isset($_GET["msg"])){
                            $msg = base64_decode($_GET["msg"]);
                            ?>
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="alert alert-danger">
                                <?php echo $msg; ?>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                        ?>
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                        <input type="hidden" name="patient_id" id="patient_id" value="<?php echo $patient_id; ?>"/>
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Name :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo ucwords($patient_row["patient_name"]); ?>"/>
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">Owner :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="hidden" id="owner_id" name="owner_id" value=""/>
                            <input type="text" class="form-control" id="owner_name" value="<?php echo ucwords($patient_row["cus_fname"]." ".$patient_row["cus_lname"]); ?>"/>
                            
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12" id="view_owners">
                            
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Species :</label>
                        </div>
                        <div class="col-md-4">
                            <select class="form-control" id="species" name="species" required="required">
                                
                                <option value="">--Select Species--</option>
                                <?php
                                    while($species_row=$speciesResult->fetch_assoc()){
                                ?>
                                <option value="<?php echo $species_row["species_id"]; ?>"
                                <?php
                                            if($patient_row["species_id"]==$species_row["species_id"]){
                                            ?>
                                        
                                        selected="selected"
                                        <?php
                                        }
                                        ?>
                                            
                                        
                                        >
                                            <?php  echo $species_row["species"]?>
                                </option>
                                <?php
                                    }
                                    ?>
                            </select>
                                    
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">Breed :</label>
                        </div>
                        <div class="col-md-4">
                            <select class="form-control" id="breed" name="breed">
                                
                                <option value="<?php echo $patient_row["breed_id"]; ?>"><?php echo ucwords($patient_row["breed"])?></option>
                                <option value="">--Change the Species First--</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Gender :</label>
                        </div>
                        <div class="col-md-4">
                            Male &nbsp; <input type="radio" name="gender" value="0" 
                                <?php if($patient_row["patient_gender"]==0){
                                    ?>
                                    checked="checked"
                                <?php }
                                ?>
                                    />
                            Female &nbsp; <input type="radio" name="gender" value="1"
                                    <?php if($patient_row["patient_gender"]==1){
                                    ?>
                                    checked="checked"
                                <?php }
                                ?>             
                                                 />
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">DOB :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="date" class="form-control" name="dob" id="dob" value="<?php echo ucwords($patient_row["patient_dob"]); ?>"/>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Colour :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="text" name="colour" id="colour" class="form-control" value="<?php echo ucwords($patient_row["patient_colour"]); ?>"/>
                            
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">Weight :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="text" class="form-control" name="weight" id="weight" value="<?php echo ucwords($patient_row["patient_weight"]); ?>"/>
                            
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Notes :</label>
                        </div>
                        <div class="col-md-4">
                            <textarea class="form-control" id="notes" name="notes" ><?php echo ucwords($patient_row["notes"]); ?></textarea>
                            
                        </div>
                        
                        <div class="col-md-2">
                            <label class="control-label">Patient Image :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="file" name="patient_img" id="patient_image" class="form-control" onchange="readImage(this);"/>
                            <br/>
                            
                            <?php 
                                $patientImage="";
                                if($patient_row["patient_image"]==""){
                                    $patientImage="patientdefault.jpg";
                                }
                                else{
                                    $patientImage=$patient_row["patient_image"];
                                }
                                ?>
                                <img src="../images/patient_images/<?php echo $patientImage; ?>" width="100" height="120px" id="imgprev"/>
                            <input type="hidden" name="prev_image" value="<?php echo $patientImage; ?>" />
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 col-md-offset-2">
                            <input type="submit" class="btn btn-success" value="save"/>&nbsp;
                            <input type="reset" class="btn btn-danger" value="reset"/>
                        </div>
                    </div>
                    </form>
                        
                    
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../JS/datatable/jquery-3.5.1.js"></script>
        <script src="../JS/datatable/jquery.dataTables.min.js"></script>
        

<script src="../JS/patient_validation.js"></script>

<script>
            function readImage(input){
                //check if i have selected the file
                if(input.files && input.files[0]){
                    
                    var reader = new FileReader();
                    reader.onload=function(e){
                        $("#imgprev")
                                .attr('src' , e.target.result)
                                .width(70)
                                .height(80)
                        
                    };
                    
                    reader.readAsDataURL(input.files[0])
                }
            }
        
        
</script>
        
</html>
