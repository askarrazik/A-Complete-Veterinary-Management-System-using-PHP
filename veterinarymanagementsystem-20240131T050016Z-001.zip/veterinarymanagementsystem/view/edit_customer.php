<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/customer_model.php';
$customerObj = new Customer();

$customer_id = $_GET["customer_id"];
$customer_id = base64_decode($customer_id);

$customerResults = $customerObj->getSpcificCustomer($customer_id);
$customer_row = $customerResults->fetch_assoc();

$customerContactResults = $customerObj->getSpcificCustomerContact($customer_id);

?>
<html>
    <head>
        <title>Edit Customer</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    </head>
    
  
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span>
                        <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                        
                        
                    ?>
                    
                    </span>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Edit Customer</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="customer.php">Customer Module</a></li>
                        <li><a href="view_customers.php">View Customers</a></li>
                        <li>Edit Customer</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/customer_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    
                    <form action="../controller/customer_controller.php?status=edit_customer" enctype="multipart/form-data" method ="post">
                        
                    <?php 
                        if(isset($_GET["msg"])){
                            $msg = base64_decode($_GET["msg"]);
                            ?>
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="alert alert-danger">
                                <?php echo $msg; ?>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                        ?>
                                        
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">First Name :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="hidden" name="cus_id" id="patient_id" value="<?php echo $customer_id; ?>"/>
                            <input type="text" name="fname" id="fname" class="form-control" value="<?php echo ucwords($customer_row["cus_fname"]); ?>"/>
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">Last Name :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="text" name="lname" id="lname" class="form-control" value="<?php echo ucwords($customer_row["cus_lname"]); ?>"/>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Contact Land :</label>
                        </div>
                        <?php 
                                            while($contact_row = $customerContactResults->fetch_assoc()){
                        if($contact_row["contact_type"]==1){
                            ?>
                            <div class="col-md-4">
                                <input type="text" class="form-control" name="cno1" id="cno1" value="<?php echo $contact_row["contact_no"]; ?>"/>
                            </div>
                        <?php
                            
                        }
                        
                        
                        else{
                            ?>
                            <div class="col-md-2">
                            <label class="control-label">Contact Mobile :</label>
                            </div>
                        
                        <div class="col-md-4">
                            <input type="text" class="form-control" name="cno2" id="cno2" value="<?php echo $contact_row["contact_no"]; ?>"/>
                        </div>
                        <?php
                        }
                        }
                        ?>
                        
                        
                        
                        
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Gender :</label>
                        </div>
                        <div class="col-md-4">
                            Male &nbsp; <input type="radio" name="gender" value="0" 
                                <?php if($customer_row["cus_gender"]==0){
                                    ?>
                                    checked="checked"
                                <?php }
                                ?>
                                    />
                            Female &nbsp; <input type="radio" name="gender" value="1"
                                    <?php if($customer_row["cus_gender"]==1){
                                    ?>
                                    checked="checked"
                                <?php }
                                ?>             
                                                 />
                        </div>
                    </div>
                        
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">NIC :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="text" name="nic" class="form-control" id="nic" value="<?php echo ucwords($customer_row["cus_nic"]); ?>"/>
                        </div>
                        <div class="col-md-2">
                            <label class="control-label">Email :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="email" name="email" class="form-control" id="email" value="<?php echo $customer_row["cus_email"]; ?>"/>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                            <div class="col-md-2">
                                <label class="control-label">Address Line 1 :</label>
                            </div>
                            
                            <div class="col-md-3">
                                <input type="text" name="no" class="form-control" id="no" value="<?php echo ucwords($customer_row["door_no"]); ?>"/>
                            </div>
                        </div>
                        <br/>
                        
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control-label">Address Line 2 :</label>
                            </div>
                            
                            <div class="col-md-4">
                                <input type="text" name="street" class="form-control" id="street" value="<?php echo ucwords($customer_row["street"]); ?>"/>
                            </div>
                        </div>
                        
                        <br/>
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control-label">Address Line 3 :</label>
                            </div>
                            
                            <div class="col-md-4">
                                <input type="text" name="city" class="form-control" id="city" value="<?php echo ucwords($customer_row["city"]); ?>"/>
                            </div>
                        </div>
                        
                        
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 col-md-offset-2">
                                <input type="submit" class="btn btn-success" value="save"/>&nbsp;
                                <input type="reset" class="btn btn-danger" value="reset"/>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                    </form>
                        
                        
                    
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../JS/datatable/jquery-3.5.1.js"></script>
        <script src="../JS/datatable/jquery.dataTables.min.js"></script>
        
        <!-- include bootstrap js-->
        <script src="../JS/datatable/dataTables.bootstrap.min.js"></script>

</html>
