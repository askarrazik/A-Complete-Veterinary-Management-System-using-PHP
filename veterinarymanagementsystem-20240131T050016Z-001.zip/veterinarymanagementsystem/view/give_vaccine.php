<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/vaccination_model.php';
$vaccineObj = new Vaccination();
$vaccineResults = $vaccineObj->getAllActiveVaccine();
?>
<html>
    <head>
        <title>Give Vaccine</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
        
    </head>
    
    
      <script>
        
        loadPatient = function(patientid,patient){
           //alert(patientid); 
           //alert(patient);
           var patientid =  patientid;
           var patient = patient
           $("#patient").val(patient);
           $("#patient_id").val(patientid);
           
           $("#view_patients").hide();
        } 
       
        loadVet= function(vet_id,veterinarian){
           //alert(vet_id); 
            
           var vet_id =  vet_id;
           var veterinarian = veterinarian
           $("#vet_name").val(veterinarian);
           $("#vet_id").val(vet_id);
           
           $("#view_vets").hide();
           
           
        }
           
    
           
         
    </script>
    
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Give Vaccine</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
                
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="vaccination_treatment.php">Vaccination & Treatment Management</a></li>
                        <li>Give Vaccine</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/vaccine_treatment_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    <form action="../controller/vaccination_treatment_controller.php?status=give_vaccine" method="post">
                        
                        <?php 
                        if(isset($_GET["msg"])){
                            $msg = base64_decode($_GET["msg"]);
                            ?>
                        <div class="row">
                            <div class="col-md-6 col-md-offset-3">
                                <div class="alert alert-danger">
                                    <p align="center"><?php echo $msg; ?></p>
                                </div>
                            </div>
                        </div>
                        <?php 
                        }
                        ?>
                        
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control_label">Patient :</label>
                            </div>
                            <div class="col-md-4">
                                <input type="hidden" id="patient_id" name="patient_id"/>
                                <input type="text" name="patient" id="patient" class="form-control"/>
                            </div>
                            <div class="col-md-2">
                                <label class="control_label">Veterinarian  :</label>
                            </div>
                            <div class="col-md-4">
                                <input type="hidden" id="vet_id" name="vet_id" value=""/>
                                <input type="text" class="form-control" name="vet_name" id="vet_name"/>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12" id="view_patients">

                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12" id="view_vets">

                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control_label">Vaccines :</label>
                            </div>
                            
                            <div class="col-md-10">
                                <?php
                                                    while ($vaccine_row = $vaccineResults->fetch_assoc()){
                                                        ?>
                                <div class="row">
                                    <div class="col-md-4">
                                        <?php echo ucwords($vaccine_row["vaccine_item"]); ?>
                                    </div>
                                
                                    <div class="col-md-2">
                                        <input type="checkbox" name="vaccine_item[]" value="<?php echo $vaccine_row["vaccine_id"]; ?>"/>
                                    </div>
                               
                                </div>
                             <?php
                                                    }
                                
                                ?>
                            </div>
                            
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">
                                &nbsp;
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control-label">Date :</label>
                            </div>
                            <div class="col-md-4">
                                <input type="date" class="form-control" name="date" id="date"/>
                            </div>
                            
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">
                                &nbsp;
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control-label">Description :</label>
                            </div>
                            <div class="col-md-4">
                                <textarea class="form-control" id="desc" name="desc"></textarea>
                            </div>
                            
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 col-md-offset-2">
                                <input type="submit" class="btn btn-success" value="save"/>&nbsp;
                                <input type="reset" class="btn btn-danger" value="reset"/>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                    </form>
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../JS/patient_validation.js"></script>
<script src="../JS/appointment_validation.js"></script>

</html>
