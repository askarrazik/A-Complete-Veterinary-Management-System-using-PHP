<!doctype html>
<html>
    <head>
        <title>Login</title>
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        
        
    </head>
    
    <style>
        .container {
            border: 3px solid darkblue;
            outline: #b3e6ff solid 500px;
            margin: auto;  
            text-align: center;
            
        }
        
        h1{
    border-radius: 25px;
  border: 2px solid #005580;
   
  
        }
    </style>
    
    <body>
        
        
         <div class="row">
            <div class="col-md-12">&nbsp;</div>
        </div>
        
         <div class="row">
            <div class="col-md-12">&nbsp;</div>
        </div>
        
        <div class="container">
            
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 align="center" style="font-family: fantasy; font-style: inherit;">Sky Pet Animal Hospital</h1>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            &nbsp;
                        </div>
                    </div>
                   <div class="row">
                        <div class="col-md-12">
                            &nbsp;
                        </div>
                    </div>
                   
                    
                    <div class="row">
                        <div class="col-md-12">
                            <img src="../images/login/walk_with_dog.png" alt="alt" class="image" width="550px" height="370" align="center" />
                        </div>
                    </div>    
                </div>                
                
                <div class="col-md-6">
                    
                    
                    <div class="row">
                        <div class="col-md-12">
                            <h3 align="center" style="font-weight: bold">Welcome Back!</h3>
                            <h4 align="center">Login to Continue</h4> 
                        </div>
                    </div>
                   
                    <div class="row">
                        <div class="col-md-12">
                            <img src="../images/login/male_avatar.png" class="img-rounded center-block" height="175px"/>
                        </div>
                    </div>
                   
                    <?php
                    
                    if(isset($_GET["msg"])){
                        ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="alert alert-danger">
                                <?php echo base64_decode($_GET["msg"]); ?>
                            </div>
                        </div>
                    </div>
                    
                    <?php
                    }
                    ?>
                    <form action="../controller/login_controller.php?status=login" method="post">
                        
                    <div class="row">
                        <div class="col-md-12">
                            <div class="input-group">
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-user"></span>
                                </span>
                                <input type="text" class="form-control input-lg" id="username" name="username" placeholder="User Name"/>
                            </div>
                        </div>            
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            &nbsp;
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="input-group">        
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-lock"></span>  
                                </span>
                                <input type="password" class="form-control input-lg"  id="password" name="password" placeholder="Password"/>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            &nbsp;
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <input type="submit" class="btn btn-block btn-lg btn-primary" style=" color:#fff" value="LOGIN"/>
                        </div>
                    </div>
                        
                    </form>
                
                </div>        
                
                
                
            </div>
            
                        
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            
        </div>
        
        

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

</html>
