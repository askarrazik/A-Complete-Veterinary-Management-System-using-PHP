<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

include "../model/product_model.php";
include "../model/stock_model.php";

$productObj = new Product();
$stockObj = new Stock();

$productResult = $productObj->getAllProducts();
//getting all products

$moduleArray = $_SESSION["user_module"];
?>
<html>
    <head>
        <title>View Products</title>
                <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
        
        <!--   Google  Charts  -->
        <!--  Include library-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
    google.charts.load('current', {'packages':['corechart']});
	
    google.charts.setOnLoadCallback(drawStockReport);
    /// Create javascript function for each chart we create
    function drawStockReport(){
        /// the data to be presented in chart form
        var data=google.visualization.arrayToDataTable([
         ["Product Name","Stock"],/// Header Row(Define Axies)
        ///Individual Rows
          <?php
          $colurArray=array("#3f178a","#fc0570","#fccf05");
          $colour=0;
          while($prrow=$productResult->fetch_assoc())
          {
           $productname=$prrow["product_name"];
           $product_id=$prrow["product_id"];        
           $tot_qty=  $stockObj->getProductStock($product_id);
         ?>
          ["<?php echo $productname ?>",<?php echo $tot_qty ?>],
                  
         <?php
            $colour++;
          }
         ?>
         
        ]);
        var options={
         width:600,
         height:400,
         legend:{position:'bottom'},
         title: 'Product Stock in Percentage',
          is3D: true,
     }
        var chart=new google.visualization.PieChart(document.getElementById("stockchart"));
        chart.draw(data,options);
        
   }
    </script>
    
    

        
    </head>
    
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Product Analysis</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
                
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="products.php">Products Management</a></li>
                        <li>Product Analysis</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/product_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-4">
                            <a href="generate_stock_report.php" class="btn btn-success">
                                <span class="glyphicon glyphicon-book"></span> &nbsp;
                                Generate Stock Report
                            </a>
                        </div>    
                        <div class="col-md-4 col-md-offset-4">    
                            <a href="generated_stock_report.php?status=save" class="btn btn-success">
                                <span class="glyphicon glyphicon-floppy-save"></span> &nbsp;
                                Save Stock Report
                            </a>
                        </div> 
                        
                    </div>
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    <div class="row">
                        <div id="stockchart" style="width: 850px; height: 350px;">
                            
                        </div>
                    </div>
                </div>
               
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../JS/datatable/jquery.dataTables.min.js"></script>
        

<script src="../JS/datatable/dataTables.bootstrap.min.js"></script>

</html>
