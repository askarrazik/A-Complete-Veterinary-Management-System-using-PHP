<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/customer_model.php';
$customerObj = new Customer();

$customerCount = $customerObj->getAllCustomerCount();

$activeCustomerResult = $customerObj->getActiveCustomerCount();
$activeCustomerCount = $activeCustomerResult->fetch_assoc();

$deactiveCustomerResult = $customerObj->getDeactiveCustomerCount();
$deactiveCustomerCount = $deactiveCustomerResult->fetch_assoc();

?>
<html>
    <head>
        <title>Customer Management</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    </head>
    
    
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                <div class="col-md-2">
                    <span>
                        <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                        
                        
                    ?>
                    
                    </span>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Customer Management</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/customer_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    <div class="col-md-12">
                        <div class="panel panel-success" style="height: 45px; background-color: infobackground">        
                                <h4 align="center"/>All Registered Customer</h4>
                        </div>
                 
                    </div>
                    <div class="col-md-4 col-md-offset-4">
                        <div class="panel panel-success" style="height: 45px; background-color: #e6ffe6">        
                                <h4 align="center"/><?php echo $customerCount; ?></h4>
                        </div>
                 
                    </div>
                    
                    <div class="col-md-12">&nbsp;</div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="panel panel-default" style="height: 150px; background-color:lightgreen">
                                <h4 align="center">Active Customers</h4>
                                 
                                    <?php
                                    if($activeCustomerCount>0){
                                       ?>
                                        <h1 align="center"><?php echo $activeCustomerCount["activeCustomerCount"];?></h1>
                                        <?php
                                    }
                                        
                                    ?>
                                    
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="panel panel-default" style="height: 150px; background-color:#ff6666 ">
                                <h4 align="center">De-Active Customers</h4>
                                 <?php
                                    if($deactiveCustomerCount>0){
                                       ?>
                                        <h1 align="center"><?php echo $deactiveCustomerCount["deactiveCustomerCount"];?></h1>
                                        <?php
                                    }
                                        
                                    ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

</html>
