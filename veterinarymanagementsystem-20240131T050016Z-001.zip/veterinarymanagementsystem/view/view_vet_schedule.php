<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/schedule_model.php';
$scheduleObj = new Schedule();

$scheduleResult = $scheduleObj->getAllSchedules();
?>
<html>
    <head>
        <title>View Veterinarian Schedule</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel ="stylesheet" type="text/css" href="../CSS/jquery.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    </head>
    
    
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">View Veterinarian Schedule</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="appointment.php">Appointment Management</a></li>
                        <li>Veterinarian Schedule</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/appointment_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-hover table-bordered" id="scheduletable">
                                <thead>
                                    <tr style = "background-color: #456bdc; color: #fff">
                                        
                                        <th>Veterinarian</th>
                                        <th>Date</th>
                                        <th>In-Time</th>
                                        <th>Out-Time</th>
                                        <th>Availability</th>
                                        
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    while($schedule_row = $scheduleResult->fetch_assoc()){
                                        ?>
                                    <tr>
                                        <td><?php echo ucwords($schedule_row["vet_fname"]." ".$schedule_row["vet_lname"]); ?></td>
                                        <td><?php echo $schedule_row["date"]; ?></td>
                                        <td><?php echo $schedule_row["exp_in_time"]; ?></td>
                                        <td><?php echo $schedule_row["exp_out_time"];?></td>
                                        
                                        <td>
                                             <?php 
                                                if($schedule_row["is_available"]==1){
                                            ?>
                                                    <label class="label label-success">Available</label>
                                            <?php
                                                }
                                            
                                                else{
                                            ?>
                                                    <label class="label label-danger">Unavailable</label>
                                            <?php        
                                                }   
                                            ?>
                                        </td>
                                       
                                        
                                        

                                    </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                    
                        </div>
                    </div>
                
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../JS/datatable/jquery.dataTables.min.js"></script>
        
        <!-- include bootstrap js-->
<script src="../JS/datatable/dataTables.bootstrap.min.js"></script>
<script>
            
            $(document).ready(function(){
                $("#scheduletable").DataTable();
            });
</script>

</html>
