<?php 

///include pdf library 

include '../commons/fpdf181/fpdf.php';
include '../model/product_model.php';
include '../model/stock_model.php';

$productObj = new Product();
$stockObj = new Stock();

$productResult = $productObj->getAllProducts();

$fpdf= new FPDF();

$fpdf->SetTitle("Product Stock Report"); /// set the Title for the Document

$fpdf->AddPage("P", "A4",0);
$fpdf->Image("../images/dashboard/logo_sample.png",10,20,30,30);
$fpdf->SetFont("Times", "B", 16); //// Setting Fonts
$fpdf->Cell(0,20,"Sky Pet Animal Hospital",0,2,"C");

$fpdf->SetFont("Arial", "B", 10); //// Setting Fonts
$fpdf->Cell(0,12,"Sri Lanka Airforce, Guwanpura, Borella, Colombo - 08, Sri Lanka / 0112 495 800",0,1,"C",false);

$fpdf->SetFont("Times", "B", 16); //// Setting Fonts
$fpdf->Cell(0,20,"Product Stock Report",0,1,"C");




$fpdf->SetLeftMargin(20);

$fpdf->SetFont("Times", "B", 10); //// Setting Fonts

///Table Heading
$fpdf->Cell(30,10,"Name" ,1, 0, "C");
$fpdf->Cell(30,10,"Brand" ,1, 0, "C");
$fpdf->Cell(30,10,"Category" ,1, 0, "C");
$fpdf->Cell(30,10,"Price" ,1, 0, "C");
$fpdf->Cell(40,10,"Total Stock Available" ,1, 1, "C");

while($productrow=$productResult->fetch_assoc()){

$product_id=$productrow["product_id"];

$tot_qty = $stockObj->getProductStock($product_id);

if($tot_qty>0){
    $tot_qty = $tot_qty." ".$productrow["unit_name"];
}
else{
    $tot_qty = "No Stock Available";
}

$fpdf->SetFont("Times", "", 9);
///Table Body

$fpdf->Cell(30,10,$productrow["product_name"] ,1, 0, "C");
$fpdf->Cell(30,10,$productrow["brand_name"],1, 0, "C");
$fpdf->Cell(30,10,$productrow["cat_name"] ,1, 0, "C");
$fpdf->Cell(30,10,"Rs " .$productrow["product_price"] ,1, 0, "R");
$fpdf->Cell(40,10,$tot_qty ,1, 1, "C");
}

$fpdf->SetFont("Arial", "B", 8); //// Setting Fonts

$fpdf->Cell(200,10,"This is a Computer Generated Document and requires no Authorized Signature" ,0, 1, "L");
$date = date("Y-m-d  H:i:s");
$fpdf->Cell(200,10,"Generated on: $date" ,0, 1, "L");

if(!isset($_REQUEST["status"])){
    $fpdf->Output(); // Display the PDF on the Browser
}

else{
    $d1="User_report_".$date;
    $filename=$d1. ".pdf";
    $path="../documents/stock_reports/$filename";
    $fpdf->Output($filename, "D");// download the file
}




?>