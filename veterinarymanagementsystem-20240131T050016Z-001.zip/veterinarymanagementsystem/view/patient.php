<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];

include_once '../model/patient_model.php';
$patientObj = new Patient();

$speciesResult=$patientObj->getPatientSpecies();
$patientCount = $patientObj->getAllPatientCount();

$activePatientResult = $patientObj->getActivePatientCount();
$activePatientCount = $activePatientResult->fetch_assoc();

$deactivePatientResult = $patientObj->getDeactivePatientCount();
$deactivePatientCount = $deactivePatientResult->fetch_assoc();


?>
<html>
    <head>
        <title>Patient Management</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
    </head>

    
    <script>
    
        function changeFunc() {
            var get_species = document.getElementById("get_species");
            var species_id = get_species.options[get_species.selectedIndex].value;
            //alert(selectedValue);
            
            var url="../controller/patient_controller.php?status=patient_count_by_species";
       
            $.post(url,{species_id:species_id}, function(data){
          
                $("#getcount").html(data);
            });
        }

  

    </script>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                    ?>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Patient Management</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div>
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/patient_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    <div class="col-md-12">
                        <div class="panel panel-success" style="height: 45px; background-color: infobackground">        
                                <h4 align="center"/>All Registered Patient</h4>
                        </div>
                 
                    </div>
                    <div class="col-md-4 col-md-offset-4">
                        <div class="panel panel-success" style="height: 45px; background-color: #e6ffe6">        
                                <h4 align="center"/><?php echo $patientCount; ?></h4>
                        </div>
                 
                    </div>
                    
                    <div class="col-md-12">&nbsp;</div>
                    
                    
                    <div class="row">
                        <div class="col-md-8">
                            <div class="panel panel-success" style="height: 45px; background-color: infobackground">    
                                
                                <h4 align="center"/> View Patient Count by Species</h4>
                        </div>
                        </div>
                    </div>
                    
                    
                    <div class="row">
                        
                        
                        <div class="col-md-4">
                            
                            <select class="form-control" id="get_species" onchange="changeFunc()" name="get_species" required="required">
                                <option>Select Species to view the count</option>
                                <?php
                                
                        while($species_row=$speciesResult->fetch_assoc()){
                            
                            $species_id = $species_row["species_id"];
                            ?>
                                
                                <option value="<?php echo $species_id; ?>"><?php echo ucwords($species_row["species"]); ?></option>
                                <?php
                        }
                        ?>
                            </select>
                        </div>
                        
                        <div class="col-md-4" id="getcount">
                            <input type="text"  value="" class="form-control"readonly><br>
                        </div>
                        
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">&nbsp;</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="panel panel-default" style="height: 150px; background-color:lightgreen">
                                <h4 align="center">Active Patients</h4>
                                 
                                    <?php
                                    if($activePatientCount>0){
                                       ?>
                                        <h1 align="center"><?php echo $activePatientCount["activePatientCount"];?></h1>
                                        <?php
                                    }
                                        
                                    ?>
                                    
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="panel panel-default" style="height: 150px; background-color:#ff6666 ">
                                <h4 align="center">De-Active Patients</h4>
                                 <?php
                                    if($deactivePatientCount>0){
                                       ?>
                                        <h1 align="center"><?php echo $deactivePatientCount["deactivePatientCount"];?></h1>
                                        <?php
                                    }
                                        
                                    ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../JS/patient_validation.js"></script>

</html>
