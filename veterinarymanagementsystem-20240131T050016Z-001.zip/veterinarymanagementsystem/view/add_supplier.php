<!doctype html>

<?php
include_once '../commons/session.php';
///getting user module info by starting session

$moduleArray = $_SESSION["user_module"];
?>
<html>
    <head>
        <title>Add Supplier</title>
        
        <!-- include bootstrap css -->
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css"/>
        
        
    </head>
    
    <script>
        
    
    </script>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">&nbsp;</div>
            </div>
            
            <div class="row">
                
                <div class="col-md-2">
                    <img src="../images/dashboard/logo_sample.png" width="100px" height="100px"/>
                </div>
                
                <div class="col-md-8">
                    <h2 align="center">VETERINARY MANAGEMENT SYSTEM</h2>
                </div>
                
                <div class="col-md-2">
                    &nbsp;
                </div>
                
            </div>
            <hr/>
            
            <div class="row">
                
                <div class="col-md-2">
                    <span>
                        <span class="glyphicon glyphicon-user" id="glyph"></span>
                    &nbsp;
                    <?php
                        // uc = uppercase
                        echo ucwords($_SESSION["user"]["user_fname"]);
                        
                        
                    ?>
                    
                    </span>
                </div>
                
                <div class="col-md-8">
                    <h4 align="center">Add Supplier</h4>
                </div>
                
                <div class="col-md-1">
                    <?php
                    if($_SESSION["user"]["user_role"]== 1 || $_SESSION["user"]["user_role"]==4){
                        include_once '../includes/notification_navigation.php';
                    }
                    ?>
                    
                </div>
                <div class="col-md-1">
                    <button class="btn btn-primary" type="button">Logout</button>
                </div> 
            </div>
            
            <hr/>
            
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="supplier.php">Supplier Module</a></li>
                        <li>Add Supplier</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    &nbsp;
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <?php
                                        include_once '../includes/supplier_include.php';
                    ?>
                </div>
                
                <div class="col-md-9">
                    
                    <form action="../controller/supplier_controller.php?status=add_supplier" enctype="multipart/form-data" method ="post">
                        
                        <?php 
                        if(isset($_GET["msg"])){
                            $msg = base64_decode($_GET["msg"]);
                            ?>
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="alert alert-danger">
                                <?php echo $msg; ?>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                        ?>  
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control_label">Organization Name :</label>
                            </div>
                            <div class="col-md-10">
                                <input type="text" name="orgname" id="orgname" class="form-control" placeholder="ABC Private Limited" />
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control-label">Contact Land :</label>
                            </div>
                            <div class="col-md-4">
                                <input type="text" class="form-control" name="cno1" id="cno1" placeholder="011XXXXXXX" />
                            </div>
                            <div class="col-md-2">
                                <label class="control-label">Contact Mobile :</label>
                            </div>
                            <div class="col-md-4">
                                <input type="text" class="form-control" name="cno2" id="cno2" placeholder="07XXXXXXXX"/>
                            </div>
                        </div>
                        
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                        
                        
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control-label">Registration Number :</label>
                            </div>
                            <div class="col-md-4">
                                <input type="text" name="brn" class="form-control" id="brn" placeholder="BRN123456"/>
                            </div>
                            <div class="col-md-2">
                                <label class="control-label">Email :</label>
                            </div>
                            <div class="col-md-4">
                                <input type="email" name="email" class="form-control" id="email" placeholder="name@mail.com"/>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control-label">Address Line 1 :</label>
                            </div>
                            
                            <div class="col-md-3">
                                <input type="text" name="no" class="form-control" id="no" placeholder="Door Number"/>
                            </div>
                        </div>
                        <br/>
                        
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control-label">Address Line 2 :</label>
                            </div>
                            
                            <div class="col-md-4">
                                <input type="text" name="street" class="form-control" id="street" placeholder="Street"/>
                            </div>
                        </div>
                        
                        <br/>
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control-label">Address Line 3 :</label>
                            </div>
                            
                            <div class="col-md-4">
                                <input type="text" name="city" class="form-control" id="city" placeholder="City"/>
                            </div>
                        </div>
                        
                        
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 col-md-offset-2">
                                <input type="submit" class="btn btn-success" value="save"/>&nbsp;
                                <input type="reset" class="btn btn-danger" value="reset"/>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">&nbsp;</div>
                        </div>
                    </form>
                      
                </div>
            </div>
            
            
            
        </div>

    </body>

<!-- include jquery -->
<script src="../JS/jquery-1.12.4.js"></script>
    
<!-- include bootstrap js-->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>


</html>

