<?php 

///include pdf library 

include '../commons/fpdf181/fpdf.php';
include '../model/patient_model.php';


$patientObj= new Patient();


$patientResults = $patientObj->getAllPatients();

$fpdf= new FPDF();

$fpdf->SetTitle("All Patient Report"); /// set the Title for the Document

$fpdf->AddPage("P", "A4",0);
$fpdf->Image("../images/dashboard/logo_sample.png",10,20,30,30);
$fpdf->SetFont("Times", "B", 16); //// Setting Fonts
$fpdf->Cell(0,20,"Sky Pet Animal Hospital",0,2,"C");

$fpdf->SetFont("Arial", "B", 10); //// Setting Fonts
$fpdf->Cell(0,12,"Sri Lanka Airforce, Guwanpura, Borella, Colombo - 08, Sri Lanka / 0112 495 800",0,1,"C",false);

$fpdf->SetFont("Times", "B", 16); //// Setting Fonts
$fpdf->Cell(0,20,"Patient Report",0,1,"C");




$fpdf->SetLeftMargin(15);


$fpdf->SetFont("Times", "B", 10); //// Setting Fonts

///Table Heading
$fpdf->Cell(30,10,"Name" ,1, 0, "C");
$fpdf->Cell(30,10,"Species" ,1, 0, "C");
$fpdf->Cell(30,10,"Breed" ,1, 0, "C");
$fpdf->Cell(30,10,"DOB" ,1, 0, "C");
$fpdf->Cell(30,10,"Owner" ,1, 0, "C");
$fpdf->Cell(30,10,"Status" ,1, 1, "C");

while($patient_row=$patientResults->fetch_assoc()){


$fpdf->SetFont("Times", "", 9);
///Table Body
if($patient_row["status"]==1){
    $status = "Active";
}

else{
    $status = "Deactive";
}
$fpdf->Cell(30,10,ucwords($patient_row["patient_name"]) ,1, 0, "L");
$fpdf->Cell(30,10,$patient_row["species"],1, 0, "L");
$fpdf->Cell(30,10,$patient_row["breed"] ,1, 0, "L");
$fpdf->Cell(30,10,$patient_row["patient_dob"] ,1, 0, "L");
$fpdf->Cell(30,10,$patient_row["cus_fname"] ,1, 0, "L");
$fpdf->Cell(30,10,$status ,1, 1, "L");
}

$fpdf->SetFont("Arial", "B", 8); //// Setting Fonts
$fpdf->Cell(200,10,"" ,0, 1, "L");

$fpdf->Cell(200,10,"This is a Computer Generated Document and requires no Authorized Signature " ,0, 1, "L");
$date = date("Y-m-d  H:i:s");
$fpdf->Cell(200,10,"Generated on: $date" ,0, 1, "L");

if(!isset($_REQUEST["status"])){
    $fpdf->Output(); // Display the PDF on the Browser
}

else{
    $d1="User_report_".$date;
    $filename=$d1. ".pdf";
    $path="../documents/stock_reports/$filename";
    $fpdf->Output($filename, "D");// download the file
}




?>