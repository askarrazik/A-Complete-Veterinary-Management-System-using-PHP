<?php

class dbConnection{
    
    public $conn;
    private $dbhostname = "localhost";
    private $dbusername = "root";
    private $dbpassword = "";
    private $dbname = "veterinary_mgmt_system";
    
     public function __construct(){
        //create the db connection
    
        $this->conn = new mysqli($this->dbhostname,$this->dbusername,$this->dbpassword,$this->dbname);
    
        //checking if the db connection is successful
        
        if(!$this->conn->connect_error){
            
            $GLOBALS["conn"]=$this->conn;
        }
        
        else{
            
            echo "connection error";
        }
    }
    
}