$(document).ready(function(){
    
    $(document).on('click','.add_row',function(){
        
        $.post("../controller/purchase_controller.php?status=load_row",function(postresult){
            $(".new_row").append(postresult);
        });
        
        
        $(document).on('click','.rem_row',function(){
                $(this).closest('.added_row').remove();
        });
               
    });
            
            
});
