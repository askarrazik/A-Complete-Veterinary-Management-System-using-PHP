$(document).ready(function(){
    
    $("#species").change(function(){
       var species_id=$("#species").val();
       
       var url="../controller/patient_controller.php?status=get_breed";
       
       $.post(url,{species:species_id}, function(data){
          
           $("#breed").html(data);
       });
       
   });
    $("#owner_name").keyup(function(){
       
        $("#view_owners").show();
        
        
        
        var owner = $("#owner_name").val();
        var url = "../controller/patient_controller.php?status=get_owner";
        
        if(owner!=''){
            $.post(url,{customer:owner},function(data){
                $("#view_owners").html(data);
            }); 
        }
    });
    
    $("#patient").keyup(function(){
           
        $("#view_patients").show();
        
        
        
        var patient = $("#patient").val();
        var url = "../controller/patient_controller.php?status=get_patient";
        
        if(patient!=''){
            $.post(url,{patient:patient},function(data){
                $("#view_patients").html(data);
            }); 
        }
    });
    
    
    
    
    
    
 
});
