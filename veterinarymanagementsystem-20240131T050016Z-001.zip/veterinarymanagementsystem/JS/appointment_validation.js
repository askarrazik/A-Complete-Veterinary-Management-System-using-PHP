$(document).ready(function(){
    
   $("#vet_name").keyup(function(){
       
        $("#view_vets").show();
        
        
        
        var vet = $("#vet_name").val();
        var url = "../controller/veterinarian_controller.php?status=get_vet";
        
        if(vet!=''){
            $.post(url,{vet:vet},function(data){
                $("#view_vets").html(data);
            }); 
        }
    })
    
    
    
    
 
});