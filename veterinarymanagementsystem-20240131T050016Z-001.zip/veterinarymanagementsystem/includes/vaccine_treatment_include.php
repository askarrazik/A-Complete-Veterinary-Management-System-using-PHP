<ul class="list-group">
                        
                        <a href="give_vaccine.php" class="list list-group-item  ">
                            <span class="glyphicon glyphicon-plus-sign"></span>
                                &nbsp;
                                Give Vaccine
                        </a>
                                                                        
                        <a href="view_given_vaccines.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-search"></span>
                               &nbsp;
                               View Given Vaccines
                        </a>
                        
                        <br/>
    
                        <a href="give_treatment.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-plus-sign"></span>
                               &nbsp;
                               Give Treatment
                        </a>
                        <a href="view_given_treatments.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-search"></span>
                               &nbsp;
                               View Given Treatments
                        </a>
                        
                        <br/>
                        
                        <a href="manage_vaccine.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-pencil"></span>
                               &nbsp;
                               Manage Vaccine
                        </a>
</ul>