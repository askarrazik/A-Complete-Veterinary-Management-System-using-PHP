<ul class="list-group">
                        <a href="add_product.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-book"></span>
                            &nbsp;
                            Add Product
                        </a>
                        <a href="categories_brands.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-barcode"></span>
                            &nbsp;
                            Categories and Brands
                        </a>
                        <a href="view_products.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-search"></span>
                            &nbsp;
                            View all Products
                        </a>
    
                        <a href="product_analysis.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-tasks"></span>
                            &nbsp;
                            Product Analysis
                        </a>
</ul>