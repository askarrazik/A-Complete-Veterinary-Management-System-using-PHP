<ul class="list-group">
                        
                        <a href="add_patient.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-plus"></span>
                                &nbsp;
                                Register Patient
                        </a>
                                                                        
                        <a href="view_patients.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-search"></span>
                               &nbsp;
                               View Patients
                        </a>
</ul>