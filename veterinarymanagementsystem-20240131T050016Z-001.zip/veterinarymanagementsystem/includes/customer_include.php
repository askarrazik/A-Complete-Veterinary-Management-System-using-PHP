<ul class="list-group">
                        
                        <a href="add_customer.php" class="list list-group-item ">
                            <span class="glyphicon glyphicon-plus"></span>
                                &nbsp;
                                Register Customer
                        </a>
                                                                        
                        <a href="view_customers.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-search"></span>
                               &nbsp;
                               View Customers
                        </a>
    
                        <a href="view_customer_complaints.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-book"></span>
                               &nbsp;
                               View Complaints
                        </a>
</ul>