<ul class="list-group">
                        
                        <a href="add_user.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-plus"></span>
                                &nbsp;
                                Add User
                        </a>
                                                                        
                        <a href="view_users.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-search"></span>
                               &nbsp;
                               View Users
                        </a>
</ul>