<ul class="list-group">
                        
                        <a href="add_supplier.php" class="list list-group-item ">
                            <span class="glyphicon glyphicon-plus"></span>
                                &nbsp;
                                Add Supplier
                        </a>
                                                                        
                        <a href="view_suppliers.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-search"></span>
                               &nbsp;
                               View Suppliers
                        </a>
    
                        
</ul>