<?php
include_once "../commons/session.php";


$moduleArray = $_SESSION["user_module"];

include_once '../model/notification_model.php';
$notificationObj = new Notification();

$notificationCountResult = $notificationObj->getNotificationCount();

?>

<div class="dropdown">
    <a href="#"  id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
   
        <span class="glyphicon glyphicon-bell" id="glyph">
            <?php 
            
                $noti_count_row = $notificationCountResult->fetch_assoc();
                if($noti_count_row["noti_count"]!=0){
                ?>
            
            <span class="badge" id="noti_count" style="border-radius: 50%; position: relative; top: -15px; left: -25px; background-color: red">
            <?php
                echo $noti_count_row["noti_count"];
            ?>
            </span>
            <?php
            }
            ?>
        </span>
    </a>
    <ul class="dropdown-menu" >
        <?php
        
        $notificationResult = $notificationObj->getAllNotification();
        while($noti_row = $notificationResult->fetch_assoc()){
            
            $noti_id = base64_encode($noti_row["noti_id"]);
        ?>
        <li><a href="../controller/purchase_controller.php?status=view_requests&noti_id=<?php echo $noti_id; ?>">
            <?php
            
                if($noti_row["noti_status"]==1){
                    ?>
                <p><b>
                    <?php echo $noti_row["noti_descrip"]; ?>
                </b></p>
                <span><b><?php echo $noti_row["noti_date"]?></b></span>
                <?php
            }
            
            else{
                ?>
                <p>
                    <?php echo $noti_row["noti_descrip"]; ?>
                </p>
                <span><?php echo $noti_row["noti_date"]?></span>
            <?php
                }
            ?>
            </a>
        </li>
        <li role="separator" class="divider"></li>
        <?php
        }
        ?>
        
    </ul>
   
</div>
 