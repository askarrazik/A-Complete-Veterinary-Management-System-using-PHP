<ul class="list-group">
                        
                        <a href="add_request_note.php" class="list list-group-item  ">
                            <span class="glyphicon glyphicon-plus"></span>
                                &nbsp;
                                Add Product Requisition Note
                        </a>
                                                                        
                        <a href="view_request_note.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-folder-open"></span>
                               &nbsp;
                               View Requisition Notes
                        </a>
                        
                        <br/>
    
                        <a href="add_purchase_order.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-shopping-cart"></span>
                               &nbsp;
                               Add Purchase Order
                        </a>
                        <a href="view_purchase_orders.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-folder-open"></span>
                               &nbsp;
                               View Purchase Orders
                        </a>
                        
                        <br/>
                        
                        <a href="handle_grn.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-book"></span>
                               &nbsp;
                               Handle Good Received Notes
                        </a>
                        <a href="handle_invoices.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-book"></span>
                               &nbsp;
                               Handle Supplier Invoices
                        </a>
                        <a href="evaluate_quotation.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-book"></span>
                               &nbsp;
                               Evaluate Supplier Quotation
                        </a>
</ul>