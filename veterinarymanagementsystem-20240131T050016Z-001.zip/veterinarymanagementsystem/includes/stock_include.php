<ul class="list-group">
                        <a href="add_stock.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-book"></span>
                            &nbsp;
                            Add Stock
                        </a>
                        <a href="view_stock.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-search"></span>
                            &nbsp;
                            View Product Stock
                        </a>
                        <a href="return_stock.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-retweet"></span>
                            &nbsp;
                            Return Stock
                        </a>
    
                        <a href="view_return_stock.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-search"></span>
                            &nbsp;
                            View Returned Stock
                        </a>
</ul>