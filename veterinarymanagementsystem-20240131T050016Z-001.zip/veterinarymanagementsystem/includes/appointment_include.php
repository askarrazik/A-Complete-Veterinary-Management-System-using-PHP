<ul class="list-group">
                        
                        <a href="add_appointment.php" class="list list-group-item ">
                            <span class="glyphicon glyphicon-plus"></span>
                                &nbsp;
                                Add Appointment
                        </a>
                                                                        
                        <a href="view_appointments.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-search"></span>
                               &nbsp;
                               View All Appointments
                        </a>
    
                        
                        
                        
    
                        <a href="view_vet_schedule.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-time"></span>
                               &nbsp;
                               View Veterinarian Schedule
                        </a>
                        
                        <a href="calendar.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-calendar"></span>
                               &nbsp;
                               Calender 
                        </a>
</ul>