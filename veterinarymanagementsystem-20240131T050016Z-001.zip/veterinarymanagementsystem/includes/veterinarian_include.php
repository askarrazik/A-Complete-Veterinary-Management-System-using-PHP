<ul class="list-group">
                        
                        <a href="add_vet.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-plus"></span>
                                &nbsp;
                                Add Veterinarian
                        </a>
                                                                        
                        <a href="view_vets.php" class="list list-group-item">
                            <span class="glyphicon glyphicon-search"></span>
                               &nbsp;
                               View Veterinarians
                        </a>
    
                        
    
                        
    
                        
</ul>