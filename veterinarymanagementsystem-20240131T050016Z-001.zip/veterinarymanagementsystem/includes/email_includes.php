<?php

require "../commons/PHPMailer/PHPMailerAutoload.php";

    $mail = new PHPMailer();
     $mail->SMTPOptions = array( 'ssl' => array( 'verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true ) );

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';   /// specify main and backup SMTP servers
    $mail->SMTPAuth = true;         // Enable SMTP authentication
    $mail->Username = 'drgardonfreeman@gmail.com'; // SMTP username
    $mail->Password = 'gardon!23'; //SMTP Password
    $mail->SMTPSecure = 'tls'; /// enable tls encryption, 'ssl' also accepted
    $mail->Port = 587;
