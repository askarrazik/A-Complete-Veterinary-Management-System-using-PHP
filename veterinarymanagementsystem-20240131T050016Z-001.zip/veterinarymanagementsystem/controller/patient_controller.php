

<?php

include_once "../commons/session.php";
if(!isset($_GET["status"])){
    
    ?>
<script>window.location= "../view/login.php" </script>
    <?php
}

else{
    
    include_once "../model/patient_model.php";
    $patientObj = new Patient();

    $status = $_GET["status"];
    
    switch($status){
        
        
        case "get_owner":
            
            $owner = $_POST["customer"];
            
            $ownerResults = $patientObj->getPatientOwner($owner);
            
            if($ownerResults->num_rows>0){
                ?> 
                            <br/>
                            <table class="table table-striped" id="customertable">
                                <thead>
                                    <tr style ="background-color: #1a1aff; color: #fff;">
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>National Identity Number</th>
                                        <th>Email</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                                <tbody>
                                    <?php
                                    
                                    while($customer_row=$ownerResults->fetch_assoc()){
                                        ?>
                                    <td><?php echo ucwords($customer_row["cus_fname"]);?></td>
                                    <td><?php echo ucwords($customer_row["cus_lname"]);?></td>
                                    <td><?php echo $customer_row["cus_nic"];?></td>
                                    <td><?php echo $customer_row["cus_email"];?></td>
                                    <td>
                                        <input type="button" value="Add" class="btn btn-primary glyphicon-plus" 
                                               onclick="loadOwner(<?php echo $customer_row["cus_id"]?> , '<?php echo ucwords($customer_row["cus_fname"])?>');"/>
                                    </td>
                                        
                                </tbody>
                                <?php
                                    }
                                    ?>
                            </table>
<?php
            }
            
            else{
                ?>
<br/>
<div class="col-md-6 col-md-offset-4">
    <div class="alert alert-warning">
    <?php echo "No Results Found Please Add Customer First"; ?> <a href="../view/add_customer.php">Click Here</a>
    </div>
</div>    
<?php
            }
            
        break;
            
        case "get_breed":
            
            $species_id = $_POST["species"];
            $breedResults = $patientObj->getBreedBySpecies($species_id);
            ?>
                            <select class="form-control" id="breed" name="breed">
                                <option value="">Select Now</option>
                                <?php
                                if($breedResults->num_rows>0){
                                while($breed_row=$breedResults->fetch_assoc()){
                                    ?>
                                    <option value="<?php echo $breed_row["breed_id"]; ?>"><?php echo $breed_row["breed"];  ?></option>
                                            <?php
                                }
                                }
                                
                                else{
                                    ?>
                                }
                                    <option value=""><?php echo "No Result Found";  ?></option>
                                <?php
                                    }
                                ?>
                            </select>
            
            <?php
            
        break;
        
        case "add_patient":
            
            $name = $_POST["name"];
            $owner = $_POST["owner_id"];
            $species = $_POST["species"];
            $breed = $_POST["breed"];
            $gender = $_POST["gender"];
            $dob = $_POST["dob"];
            $colour = $_POST["colour"];
            $weight = $_POST["weight"];
            $notes = $_POST["notes"];
            
            try{
                if($name==""){
                   throw new Exception("Name is Empty!!!");
                }
                
                if($owner==""){
                   throw new Exception("Owner Must be selected");
                }
                
                if($species==""){
                   throw new Exception("Please Select Species");
                }
                
                if($breed==""){
                   throw new Exception("Please Select Breed");
                }
                
                if($gender==""){
                   throw new Exception("Select a Gender");
                }
                
                if($dob==""){
                   throw new Exception("Date of Birth Not Be Empty");
                }
                
                if($colour==""){
                   throw new Exception("Colour Can Not Be Empty");
                }
                
                if($weight==""){
                   throw new Exception("Weight Can Not Be Empty");
                }
                
                if($_FILES["patient_img"]["name"]!=""){// already selected a file
                    
                    $imagename=$_FILES["patient_img"]["name"]; // image name
                    
                    // appending current timestamp to make the image unique
                    
                    $imagename = "".time()."_".$imagename;
                    
                    $tmp_path=$_FILES["patient_img"]["tmp_name"]; // tempory location
                    
                    // upload to the given server directory
                    
                    $destination = "../images/patient_images/$imagename";
                    
                    move_uploaded_file($tmp_path, $destination);
                    
                    
                }
                
                else{
                    // no image is selected
                    $imagename="";
                    
                }
                
            $pat_id = $patientObj->addpatient($name, $owner, $species, $breed, $gender, $dob, $colour, $weight,$notes, $imagename);
             
            if($pat_id>0){
                 $msg = "Patient $name Successfully Added";
                 $msg = base64_encode($msg);
                    ?>
                    <script>window.location= "../view/view_patients.php?msg=<?php echo $msg; ?>" </script>
            <?php
             }
            }
            
        catch (Exception $ex){
            $msg =$ex->getMessage();
            $msg = base64_encode($msg);
            ?>
                   <script>window.location= "../view/add_patient.php?msg=<?php echo $msg; ?>" </script>
                   
                 <?php
        }
        
        
        break;
        
        case "deactivate_patient":
            
            $patient_id = base64_decode($_GET["patient_id"]);
            $patientObj->deactivatePatient($patient_id);
            $msg = "Patient Succesfully Deactivated";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/view_patients.php?msg=<?php echo $msg; ?>"</script>
        
        <?php
        
        break;
    
        case "activate_patient":
            
            $patient_id = base64_decode($_GET["patient_id"]);
            $patientObj->activatePatient($patient_id);
            $msg = "Patient Succesfully Activated";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/view_patients.php?msg=<?php echo $msg; ?>"</script>
                   <?php
        
        break;
    
        case "update_patient":
            
            $patient_id = $_POST["patient_id"];
            $name = $_POST["name"];
            $owner = $_POST["owner_id"];
            $species = $_POST["species"];
            $breed = $_POST["breed"];
            $gender = $_POST["gender"];
            $dob = $_POST["dob"];
            $colour = $_POST["colour"];
            $weight = $_POST["weight"];
            $notes = $_POST["notes"];
            
            try{
                if($name==""){
                   throw new Exception("Name is Empty!!!");
                }
                
                if($owner==""){
                   throw new Exception("Owner Must be selected");
                }
                
                if($species==""){
                   throw new Exception("Please Select Species");
                }
                
                if($breed==""){
                   throw new Exception("Please Select Breed");
                }
                
                if($gender==""){
                   throw new Exception("Select a Gender");
                }
                
                if($dob==""){
                   throw new Exception("Date of Birth Not Be Empty");
                }
                
                if($colour==""){
                   throw new Exception("Colour Can Not Be Empty");
                }
                
                if($weight==""){
                   throw new Exception("Weight Can Not Be Empty");
                }
                
                if($_FILES["patient_img"]["name"]!=""){// already selected a file
                    
                    $imagename=$_FILES["patient_img"]["name"]; // image name
                    
                    // appending current timestamp to make the image unique
                    
                    $imagename = "".time()."_".$imagename;
                    
                    $tmp_path=$_FILES["patient_img"]["tmp_name"]; // tempory location
                    
                    // upload to the given server directory
                    
                    $destination = "../images/patient_images/$imagename";
                    
                    move_uploaded_file($tmp_path, $destination);
                    
                    $previousImage = $_POST["prev_image"];
                    
                    unlink("../images/patient_images/$previousImage"); // remove file from server
                    
                    $defaultImage = "../images/patient_images/patientdefault.jpg";
                    
                    if (!file_exists($defaultImage)) {
                        $imagePath = "../images/patientdefault.jpg";
                        $newPath = "../images/patient_images/";
                        $ext = '.jpg';
                        $newName  = $newPath."patientdefault".$ext;

                        copy($imagePath , $newName);
                    }
                    
                    
                }
                
                else{
                    // no image is selected
                    $imagename="";
                    
                }
                
            $pat_id = $patientObj->updatePatient($patient_id, $name, $owner, $species, $breed,$gender , $dob, $colour, $weight, $notes, $imagename);
             
            
                 $msg = "Patient's Details Successfully Changed";
                 $msg = base64_encode($msg);
                    ?>
                    <script>window.location= "../view/view_patients.php?msg=<?php echo $msg; ?>" </script>
            <?php
             
            }
            
        catch (Exception $ex){
            $msg =$ex->getMessage();
            $msg = base64_encode($msg);
            ?>
                   <script>window.location= "../view/add_patient.php?msg=<?php echo $msg; ?>" </script>
                   
                 <?php
        }
        
        
        break;
        
        case "patient_count_by_species":
            
            $species_id = $_POST["species_id"];
            $patientcount = $patientObj->getPatientCount($species_id);
            $count_row = $patientcount->fetch_assoc();
            
            
            ?>
                   
                   <input type="text" class="form-control" value="<?php if($count_row>0){
                       echo $count_row["patient_count"];
                       
                   } 
                   else {
                       echo "0";
                       
                   } ?>"
                   readonly><br>
                       
                   
                   <?php 
            
        break;
        
        
        
        case "get_patient":
            
            $patient_id = $_POST["patient"];
            
            $patientResults = $patientObj->getPatientBySearch($patient_id);
            
            if($patientResults->num_rows>0){
                ?> 
                            <br/>
                            <table class="table table-striped" id="customertable">
                                <thead>
                                    <tr style ="background-color: #1a1aff; color: #fff;">
                                        <th>Name</th>
                                        <th>Species</th>
                                        <th>Breed</th>
                                        <th>Owner</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                                <tbody>
                                    <?php
                                    
                                    while($patient_row=$patientResults->fetch_assoc()){
                                        ?>
                                    <td><?php echo ucwords($patient_row["patient_name"]);?></td>
                                    <td><?php echo ucwords($patient_row["species"]);?></td>
                                    <td><?php echo ucwords($patient_row["breed"]);?></td>
                                    <td><?php echo ucwords($patient_row["cus_fname"]);?></td>
                                    <td>
                                        <input type="button" value="Select" class="btn btn-info" 
                                               onclick="loadPatient(<?php echo $patient_row["patient_id"]?> , '<?php echo ucwords($patient_row["patient_name"])?>');"/>
                                    </td>
                                        
                                </tbody>
                                <?php
                                    }
                                    ?>
                            </table>
<?php
            }
            
            else{
                ?>
<br/>
<div class="col-md-6 col-md-offset-4">
    <div class="alert alert-warning">
        <p align="center"><?php echo "No Results Found" ?></p>
    </div>
</div>    
<?php
            }
         
        
    }
}
?>

