<?php

include_once "../commons/session.php";
if(!isset($_GET["status"])){
    
    ?>
<script>window.location= "../view/login.php" </script>
    <?php
}

else{
    
    include_once "../model/supplier_model.php";
    $supplierObj = new Supplier();

    $status = $_GET["status"];
    
    switch($status){
        
        case "add_supplier":
            
            $org_name=$_POST["orgname"];
            $cno1=$_POST["cno1"];
            $cno2=$_POST["cno2"];
            $brn=$_POST["brn"];
            $email=$_POST["email"];
            $address_no=$_POST["no"];
            $address_street=$_POST["street"];
            $address_city = $_POST["city"];
            
            try{
                if($org_name==""){
                   throw new Exception("Organization Name is Empty!!!");
                }
                
                if($cno1==""){
                   throw new Exception("Contact Land is Empty!!");
                }
                
                if($cno2==""){
                   throw new Exception("Contact Mobile is Empty!!");
                }
                
                                
                if($brn==""){
                   throw new Exception("Business Registration Number is Empty!!");
                }
                
                if($email==""){
                   throw new Exception("Email is Empty!!");
                }
                
                if($address_no==""){
                   throw new Exception("Please enter door number");
                }
                
                if($address_street==""){
                   throw new Exception("Please enter street");
                }
                
                if($address_city==""){
                   throw new Exception("Please enter city");
                }
                
                
                
            $sup_id = $supplierObj->addSupplier($org_name, $brn, $email);
             
            if($sup_id>0){
                
                $supplierObj->addSupplierAddress($sup_id, $address_no, $address_street, $address_city);
                    
                $supplierObj->addSupplierContact($sup_id, $cno1, 1);
                $supplierObj->addSupplierContact($sup_id, $cno2, 2);
                
                $msg = "Supplier $org_name Successfully Added";
                $msg = base64_encode($msg);
                    ?>
                    <script>window.location= "../view/view_suppliers.php?msg=<?php echo $msg; ?>" </script>
            <?php
             }
            }
            
        catch (Exception $ex){
            $msg =$ex->getMessage();
            $msg = base64_encode($msg);
            ?>
                   <script>window.location= "../view/add_supplier.php?msg=<?php echo $msg; ?>" </script>
                   
                 <?php
        }
        
        break;
        
        case "deactivate_supplier":
            
            $sup_id = base64_decode($_GET["supplier_id"]);
            $supplierObj->deactivateSupplier($sup_id);
            $msg = "Supplier Succesfully De-activated";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/view_suppliers.php?msg=<?php echo $msg; ?>"</script>
        
        <?php
        
        break;
    
        case "activate_supplier":
            
            $sup_id = base64_decode($_GET["supplier_id"]);
            $supplierObj->activateSupplier($sup_id);
            $msg = "Supplier Succesfully Activated";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/view_suppliers.php?msg=<?php echo $msg; ?>"</script>
                   <?php
        
        break;
    
    
        case "edit_supplier":
            
            $sup_id = $_POST["sup_id"];
            $org_name=$_POST["orgname"];
            $cno1=$_POST["cno1"];
            $cno2=$_POST["cno2"];
            $brn=$_POST["brn"];
            $email=$_POST["email"];
            $address_no=$_POST["no"];
            $address_street=$_POST["street"];
            $address_city = $_POST["city"];
            
            try{
                if($org_name==""){
                   throw new Exception("Organization Name is Empty!!!");
                }
                
                if($cno1==""){
                   throw new Exception("Contact Land is Empty!!");
                }
                
                if($cno2==""){
                   throw new Exception("Contact Mobile is Empty!!");
                }
                
                                
                if($brn==""){
                   throw new Exception("Business Registration Number is Empty!!");
                }
                
                if($email==""){
                   throw new Exception("Email is Empty!!");
                }
                
                if($address_no==""){
                   throw new Exception("Please enter door number");
                }
                
                if($address_street==""){
                   throw new Exception("Please enter street");
                }
                
                if($address_city==""){
                   throw new Exception("Please enter city");
                }
                
                
                
            $supplierObj->updateSupplier($org_name, $brn, $email, $sup_id);
            
            $supplierObj->updateSupplierAddress($address_no, $address_street, $address_city, $sup_id);
            
            $supplierObj->updateSupplierContact($sup_id, $cno1,1);
            $supplierObj->updateSupplierContact($sup_id, $cno2,2);
                
                $msg = "Supplier $org_name Successfully Added";
                $msg = base64_encode($msg);
                    ?>
                    <script>window.location= "../view/view_suppliers.php?msg=<?php echo $msg; ?>" </script>
            <?php
            
            }
            
        catch (Exception $ex){
            $msg =$ex->getMessage();
            $msg = base64_encode($msg);
            ?>
                   <script>window.location= "../view/edit_supplier.php?msg=<?php echo $msg; ?>" </script>
                   
                 <?php
        }
        
        break;
        
            
            
    }
}
?>


