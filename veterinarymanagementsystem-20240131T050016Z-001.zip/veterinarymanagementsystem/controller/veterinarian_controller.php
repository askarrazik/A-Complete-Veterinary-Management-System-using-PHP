<?php

include_once "../commons/session.php";
if(!isset($_GET["status"])){
    
    ?>
<script>window.location= "../view/login.php" </script>
    <?php
}

else{
    
    include_once "../model/veterinarian_model.php";
    $vetObj = new Veterinarian();
    

    $status = $_GET["status"];
    
    switch($status){
        
        case "add_vet":
            
            $fname = $_POST["fname"];
            $lname = $_POST["lname"];
            $specialty = $_POST["vet_specialty"];
            $cno1 = $_POST["cno1"];
            $cno2 = $_POST["cno2"];
            $nic = $_POST["nic"];
            $email = $_POST["email"];
            
            try{
                if($fname==""){
                   throw new Exception("First Name is Empty!!!");
                }
                
                if($lname==""){
                   throw new Exception("Last Name is Empty");
                }
                
                if(sizeof($specialty)==0){
                    throw new Exception("A Specialty Must Be Selected");
                }
                
                if($cno1==""){
                   throw new Exception("Contact Land is Empty");
                }
                
                if($cno2==""){
                   throw new Exception("Contact Mobile is Empty");
                }
                
                if($nic==""){
                   throw new Exception("NIC Can Not Be Empty");
                }
                
                if($email==""){
                   throw new Exception("Email Can Not Be Empty");
                }
                
                
                
                
                
             $vet_id = $vetObj->addVet($fname, $lname, $nic, $email);
             
             if ($vet_id>0){
                 
                $vetObj->addVetContact($vet_id, $cno1, 1);
                $vetObj->addVetContact($vet_id, $cno2, 2);
                
                foreach($specialty as $s){
                    $vetObj->addVetSpecialty($vet_id, $s);
                }
                
                 $msg = "Veterinarian $fname Successfully Added";
                 $msg = base64_encode($msg);
                    ?>
                    <script>window.location= "../view/view_vets.php?msg=<?php echo $msg; ?>" </script>
             <?php
             }
            }
            
        catch (Exception $ex){
            $msg =$ex->getMessage();
            $msg = base64_encode($msg);
            ?>
                   <script>window.location= "../view/add_vet.php?msg=<?php echo $msg; ?>" </script>
                   
                 <?php
        }
        
        
        break;
        
        case "deactivate_vet":
            
            $vet_id = base64_decode($_GET["vet_id"]);
            $vetObj->deactivateVet($vet_id);
            $msg = "Veterinarian Succesfully Deactivated";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/view_vets.php?msg=<?php echo $msg; ?>"</script>
        
        <?php
        
        break;
    
        case "activate_vet":
            
            $vet_id = base64_decode($_GET["vet_id"]);
            $vetObj->activateVet($vet_id);
            $msg = "Veterinarian Succesfully Activated";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/view_vets.php?msg=<?php echo $msg; ?>"</script>
                   <?php
        
        break;
    
        case "load_vet_modal":
            
            $vet_id = base64_decode($_POST["vet_id"]);
            $vetResult = $vetObj->getSpecificVet($vet_id);
            $vet_row = $vetResult->fetch_assoc();
            ?>
                   <div class="row">
                       <input type="hidden" name="vet_id" value="<?php echo $vet_row["vet_id"]; ?>"/>
                        <div class="col-md-4">
                            <label class="control-label">Adding Schedule for : <h3><?php echo ucwords($vet_row["vet_fname"]." ".$vet_row["vet_lname"])?></h3> </label>
                        </div>
                        <div class="col-md-4">
                            <label class="control-label"></label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            &nbsp;
                        </div>
                    </div>
                    <div class="row">    
                        <div class="col-md-4">
                            <label class="control-label">Date :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="date" class="form-control" id="date" name="date" required="required"/>
                        </div>
                    </div>
                        
                    <div class="row">
                        <div class="col-md-12">
                            &nbsp;
                        </div>
                    </div>
                    <div class="row">    
                        <div class="col-md-4">
                            <label class="control-label">Expected In Time :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="time" class="form-control" name="in_time" id="in_time" required="required"/>
                        </div>
                            
                    </div>
                        
                    <div class="row">
                        <div class="col-md-12">
                            &nbsp;
                        </div>
                    </div>
                    <div class="row">    
                        <div class="col-md-4">
                            <label class="control-label">Expected Out Time :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="time" class="form-control" name="out_time" id="out_time" required="required"/>
                        </div>
                            
                    </div>
                        
                    <div class="row">
                        <div class="col-md-12">
                            &nbsp;
                        </div>
                    </div>
                        
                    <div class="row">    
                        <div class="col-md-4">
                            <label class="control-label">Is Avaialabe :</label>
                        </div>
                        <div class="col-md-4">
                            <select class="form-control" name="available" id="availbale" required="required">
                                <option value="1">Yes</option>
                                <option value="0">No</option>
                                    
                            </select>
                        </div>
                            
                    </div>
                        
                        <?php
            
            
            
        break;
    
       case "get_vet":
            
            $vet = $_POST["vet"];
            
            $vetResults = $vetObj->getVetBySearch($vet);
            
            if($vetResults->num_rows>0){
                ?> 
                            <br/>
                            <table class="table table-striped" id="customertable">
                                <thead>
                                    <tr style ="background-color: #1a1a1a; color: #fff;">
                                        <th>Name</th>
                                        <th>National Identity Number</th>
                                        <th>Email</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                                <tbody>
                                    <?php
                                    
                                    while($vet_row=$vetResults->fetch_assoc()){
                                        ?>
                                    <td><?php echo ucwords($vet_row["vet_fname"]." ".$vet_row["vet_lname"]);?></td>
                                    <td><?php echo ucwords($vet_row["vet_nic"]);?></td>
                                    <td><?php echo ucwords($vet_row["vet_email"]);?></td>
                                    
                                    <td>
                                        <input type="button" value="Add" class="btn btn-info " 
                                               onclick="loadVet(<?php echo $vet_row["vet_id"]?> , '<?php echo ucwords($vet_row["vet_fname"]." ".$vet_row["vet_lname"])?>');"/>
                                    </td>
                                        
                                </tbody>
                                <?php
                                    }
                                    ?>
                            </table>
<?php
            }
            
            else{
                ?>
            <br/>
            <div class="col-md-6 col-md-offset-4">
                <div class="alert alert-warning">
                    <p align="center">
                <?php echo "No Results Found" ?>
                    </p>
                </div>
            </div>    
            <?php
                    } 
            break;
            
            
        case "edit_vet":
            
            $vet_id = $_POST["vet_id"];
            $fname = $_POST["fname"];
            $lname = $_POST["lname"];
            $specialty = $_POST["vet_specialty"];
            $cno1 = $_POST["cno1"];
            $cno2 = $_POST["cno2"];
            $nic = $_POST["nic"];
            $email = $_POST["email"];
            
            try{
                if($fname==""){
                   throw new Exception("First Name is Empty!!!");
                }
                
                if($lname==""){
                   throw new Exception("Last Name is Empty");
                }
                
                if(sizeof($specialty)==0){
                    throw new Exception("A Specialty Must Be Selected");
                }
                
                if($cno1==""){
                   throw new Exception("Contact Land is Empty");
                }
                
                if($cno2==""){
                   throw new Exception("Contact Mobile is Empty");
                }
                
                if($nic==""){
                   throw new Exception("NIC Can Not Be Empty");
                }
                
                if($email==""){
                   throw new Exception("Email Can Not Be Empty");
                }
                
                
                
                
                $vetObj->updateVet($fname, $lname, $nic, $email, $vet_id);
                $vetObj->updateVetContact($vet_id, $cno1,1);
                $vetObj->updateVetContact($vet_id, $cno2,2);
                
                $vetObj->removeVetSpecialties($vet_id);
                
                foreach($specialty as $s){
                        
                        $vetObj->addVetSpecialty($vet_id, $s);
                        
                    }
                
                
                
                $msg= "Veterinarian $fname is Successfully Updated";
                $msg = base64_encode($msg);
                    
                    ?>
                    <script>window.location= "../view/view_vets.php?msg=<?php echo $msg; ?>" </script>
            <?php
            }
            
            
            catch (Exception $ex){
            $msg =$ex->getMessage();
            $msg = base64_encode($msg);
            ?>
                   <script>window.location= "../view/add_vet.php?msg=<?php echo $msg; ?>" </script>
                   
                 <?php
        }
        
        
        break;
            
    }
}
?>

