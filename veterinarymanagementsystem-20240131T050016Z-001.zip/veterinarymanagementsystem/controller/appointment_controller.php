<?php

include_once "../commons/session.php";
if(!isset($_GET["status"])){
    
    ?>
<script>window.location= "../view/login.php" </script>
    <?php
}

else{
    
    //include_once "../model/customer_model.php";
    //$customerObj = new Customer();
    include_once "../model/appointment_model.php";
    $appObj = new Appointment();

    $status = $_GET["status"];
    
    switch($status){
        
        case "add_appointment":
            
            
                
                $customer=$_POST["cus_id"];
                $type=$_POST["app_type"];
                $date=$_POST["app_date"];
                $time=$_POST["app_time"];
                $veterinarian=$_POST["vet_id"];
                
                
                try{
                    
                    if($customer==""){
                        throw new Exception("Please select customer");
                    }
                
                    if($type==""){
                        throw new Exception("Please select Appointment type");
                    }
                
                    if($date==""){
                        throw new Exception("Please enter date");
                    }
                    
                    if($time==""){
                        throw new Exception("Please enter time");
                    }
                    
                    if($veterinarian==""){
                        throw new Exception("Please select veterinarian");
                    }
                    
                    
                    
                
                    $app_id = $appObj->addAppointment($customer, $type, $date, $time, $veterinarian);

                    if($app_id>0){

                        $appResults = $appObj->getSpecificApp($app_id);
                        $app_row = $appResults->fetch_assoc();

                        $customer_email = $app_row["cus_email"];
                        $customer_name = $app_row["cus_fname"];
                        $vet_name = $app_row["vet_fname"]." ".$app_row["vet_lname"];
                        $date = $app_row["date"];
                        $time = $app_row["time"];

                        include "../includes/email_includes.php";
                        $receiver = "$customer_email";
                        $username = "$customer_email";

                        $mail->setFrom('mail@et.lk' ,'Sky Pet Animal Hospital');
                        $mail->addReplyTo('mail@et.lk' ,'Sky Pet Animal Hospital');
                        $mail->addAddress($username); // add a recipient
                        $mail->addAddress($username); // add a recipient

                        //$mail->addCC();
                        //$mail->addBCC();

                        //$mail->AddAttachment();

                        $mail->Subject = 'Appointment Details';

                        $mail->isHTML(true); ////set email format to HTML
                        $body="<h5>Dear Mr/ Ms $customer_name </h5>";
                        $body.="<img src='https://w1.pngwing.com/pngs/214/227/png-transparent-graphy-logo-veterinarian-veterinary-medicine-pet-black-and-white-symbol-thumbnail.png' width='200px' height='80px'/>";

                        $body.="<p>Please find your appointment details as mentioned below.<br> Veterinarian: $vet_name <br> Date: $date <br> Time: $time</p>";
                        $mail->Body = $body;
                        
                        if($mail->send()){
                            $msg = "Appointment added and mail successfully sent";
                            $msg = base64_encode($msg);
                        ?>
                            <script>window.location= "../view/view_appointments.php?msg=<?php echo $msg; ?>" </script>
                        <?php
                        }

                        else{
                             throw new Exception("Mail is not sent");
                        }
                    }
                }
                
                catch (Exception $ex) {
                    $msg =$ex->getMessage();
                    $msg = base64_encode($msg);
                ?>
                   <script>window.location= "../view/add_appointment.php?msg=<?php echo $msg; ?>" </script>
                   
                 <?php
                }
                
            break;
            
        case "done_appointment":
            
            $app_id = base64_decode($_GET["app_id"]);
            $appObj->DoneApp($app_id);
            $msg = "Appointment is ended";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/view_appointments.php?msg=<?php echo $msg; ?>"</script>
        
        <?php
        
        break;
    
        case "cancel_appointment":
            
            $app_id = base64_decode($_GET["app_id"]);
            $appObj->CancelApp($app_id);
            $msg = "Appointment is cancelled";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/view_appointments.php?msg=<?php echo $msg; ?>"</script>
        
        <?php
        
        break;
    
        case "load_app_modal":
            
            $app_id = base64_decode($_POST["app_id"]);
   
            $specificAppResult = $appObj->getSpecificApp($app_id);
            $app_row = $specificAppResult->fetch_assoc();
            
            ?>
                   <div class="row">    
                        <div class="col-md-4">
                            <label class="control-label">Date :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="hidden" name="app_id" value="<?php echo $app_row["app_id"]?>"/>
                            <input type="date" class="form-control" id="date" name="date" value="<?php echo $app_row["date"]; ?>" required="required"/>
                        </div>
                    </div>
                        
                    <div class="row">
                        <div class="col-md-12">
                            &nbsp;
                        </div>
                    </div>
                    <div class="row">    
                        <div class="col-md-4">
                            <label class="control-label">Time :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="time" class="form-control" name="time" id="time" value="<?php echo $app_row["time"]; ?>" required="required"/>
                        </div>
                            
                    </div>
                   <?php
                   
        break;
    
        case "edit_appointment":
            
            $app_id = $_POST["app_id"];
            $date = $_POST["date"];
            $time = $_POST["time"];
            
            $appObj->editApp($app_id, $date, $time);
            
            $msg= "date and time Successfully Updated";
            $msg = base64_encode($msg);
                
                ?>
                    <script>window.location= "../view/view_appointments.php?msg=<?php echo $msg; ?>" </script>
            <?php
        
        break;
    
    
        case "load_appdate_modal":
            
            $date = $_POST["app_date"];
            
            $appResults = $appObj->getAppByDate($date);
            
                    while($app_row=$appResults->fetch_assoc()){
            ?>
                    <div class="row">
                        <div class="col-md-12 col-md-offset-5">
                            <label class="control-label "><?php echo $app_row["date"]; ?> </label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Customer:</label>
                        </div>
                        <div class="col-md-4">
                            <?php echo ucwords($app_row["cus_fname"]." ".$app_row["cus_lname"]); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Veterinarian:</label>
                        </div>
                        <div class="col-md-4">
                            <?php echo ucwords($app_row["vet_fname"]." ".$app_row["vet_lname"]); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-label">Time:</label>
                        </div>
                        <div class="col-md-4">
                            <?php echo $app_row["time"]; ?>
                        </div>
                    </div>
                    <hr/>
            <?php
                    }
    }
}
?>


