<?php

include_once "../commons/session.php";
if(!isset($_GET["status"])){
    
    ?>
<script>window.location= "../view/login.php" </script>
    <?php
}

else{
    
    include_once "../model/customer_model.php";
    $customerObj = new Customer();

    $status = $_GET["status"];
    
    switch($status){
        
        case "add_customer":
            
            $fname=$_POST["fname"];
            $lname=$_POST["lname"];
            $cno1=$_POST["cno1"];
            $cno2=$_POST["cno2"];
            $gender=$_POST["gender"];
            $nic=$_POST["nic"];
            $email=$_POST["email"];
            $address_no=$_POST["no"];
            $address_street=$_POST["street"];
            $address_city = $_POST["city"];
            
            try{
                if($fname==""){
                   throw new Exception("First Name is Empty!!!");
                }
                
                if($lname==""){
                   throw new Exception("Last Name is Empty!!!");
                }
                
                if($cno1==""){
                   throw new Exception("Contact Land is Empty!!");
                }
                
                if($cno2==""){
                   throw new Exception("Contact Mobile is Empty!!");
                }
                
                                
                if($nic==""){
                   throw new Exception("NIC is Empty!!");
                }
                
                if($email==""){
                   throw new Exception("Email is Empty!!");
                }
                
                if($address_no==""){
                   throw new Exception("Please enter door number");
                }
                
                if($address_street==""){
                   throw new Exception("Please enter street");
                }
                
                if($address_city==""){
                   throw new Exception("Please enter city");
                }
                
                
                
            $cus_id = $customerObj->addCustomer($fname, $lname,$gender, $nic, $email);
             
            if($cus_id>0){
                
                $customerObj->addCustomerAddress($cus_id, $address_no, $address_street, $address_city);
                    
                $customerObj->addCustomerContact($cus_id, $cno1,1);
                $customerObj->addCustomerContact($cus_id, $cno2,2);
                $msg = "Customer $fname Successfully Added";
                $msg = base64_encode($msg);
                    ?>
                    <script>window.location= "../view/view_customers.php?msg=<?php echo $msg; ?>" </script>
            <?php
             }
            }
            
        catch (Exception $ex){
            $msg =$ex->getMessage();
            $msg = base64_encode($msg);
            ?>
                   <script>window.location= "../view/add_customer.php?msg=<?php echo $msg; ?>" </script>
                   
                 <?php
        }
        
        break;
        
        case "deactivate_customer":
            
            $customer_id = base64_decode($_GET["customer_id"]);
            $customerObj->deactivateCustomer($customer_id);
            $msg = "Customer Succesfully De-activated";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/view_customers.php?msg=<?php echo $msg; ?>"</script>
        
        <?php
        
        break;
    
        case "activate_customer":
            
            $customer_id = base64_decode($_GET["customer_id"]);
            $customerObj->activateCustomer($customer_id);
            $msg = "Customer Succesfully Activated";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/view_customers.php?msg=<?php echo $msg; ?>"</script>
                   <?php
        
        break;
    
    
        case "edit_customer":
            $customer_id = $_POST["cus_id"];
            $fname=$_POST["fname"];
            $lname=$_POST["lname"];
            $cno1=$_POST["cno1"];
            $cno2=$_POST["cno2"];
            $gender=$_POST["gender"];
            $nic=$_POST["nic"];
            $email=$_POST["email"];
            $address_no=$_POST["no"];
            $address_street=$_POST["street"];
            $address_city = $_POST["city"];
            
            try{
                if($fname==""){
                   throw new Exception("First Name is Empty!!!");
                }
                
                if($lname==""){
                   throw new Exception("Last Name is Empty!!!");
                }
                
                if($cno1==""){
                   throw new Exception("Contact Land is Empty!!");
                }
                
                if($cno2==""){
                   throw new Exception("Contact Mobile is Empty!!");
                }
                
                                
                if($nic==""){
                   throw new Exception("NIC is Empty!!");
                }
                
                if($email==""){
                   throw new Exception("Email is Empty!!");
                }
                
                if($address_no==""){
                   throw new Exception("Please enter door number");
                }
                
                if($address_street==""){
                   throw new Exception("Please enter street");
                }
                
                if($address_city==""){
                   throw new Exception("Please enter city");
                }
                
                
                
            $customerObj->updateCustomer($fname, $lname, $gender, $nic, $email, $customer_id);
            
            $customerObj->updateCustomerAddress($address_no, $address_street, $address_city, $customer_id);
            
            $customerObj->updateCustomerContact($customer_id, $cno1,1);
            $customerObj->updateCustomerContact($customer_id, $cno2,2);
            
                $msg = "Customer Successfully Updated";
                $msg = base64_encode($msg);
                    ?>
                    <script>window.location= "../view/view_customers.php?msg=<?php echo $msg; ?>" </script>
            <?php
             
            }
            
        catch (Exception $ex){
            $msg =$ex->getMessage();
            $msg = base64_encode($msg);
            ?>
                   <script>window.location= "../view/edit_customer.php?msg=<?php echo $msg; ?>" </script>
                   
                 <?php
        }
        
        break;
        
        case "add_complaint":
            
            $complaint = $_POST["complaint"];
            
            try{
                if($complaint==""){
                   throw new Exception("Please insert the record");
                }
                
                $customerObj->addCustomerComplaint($complaint);
                $msg = "Complaint Added";
                $msg = base64_encode($msg);
                    ?>
                    <script>window.location= "../view/view_customer_complaints.php?sucmsg=<?php echo $msg; ?>" </script>
            <?php
             
            }
            
        catch (Exception $ex){
            $msg =$ex->getMessage();
            $msg = base64_encode($msg);
            ?>
                   <script>window.location= "../view/view_customer_complaints.php?errmsg=<?php echo $msg; ?>" </script>
                   
                 <?php
        }
            
            
    }
}
?>


