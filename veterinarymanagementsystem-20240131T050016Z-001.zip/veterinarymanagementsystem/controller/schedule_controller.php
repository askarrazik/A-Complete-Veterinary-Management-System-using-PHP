<?php

include_once "../commons/session.php";
if(!isset($_GET["status"])){
    
    ?>
<script>window.location= "../view/login.php" </script>
    <?php
}

else{
    
    include_once "../model/schedule_model.php";
    $scheduleObj = new Schedule();

    $status = $_GET["status"];
    
    switch($status){
        
 
        case "add_schedule":
            
            $date = $_POST["date"];
            $in_time = $_POST["in_time"];
            $out_time = $_POST["out_time"];
            $availability = $_POST["available"];
            $vet_id = $_POST["vet_id"];
            
            $vet_sch_id = $scheduleObj->addSchedule($date, $in_time, $out_time, $availability, $vet_id);
            
            if($vet_sch_id>0){
            $msg = "Schedule Succesfully Added";
            $msg =  base64_encode($msg);
            ?>
                   <script>window.location="../view/view_vets.php?msg=<?php echo $msg; ?>"</script>
                   <?php
            }
        break;
        
        
        case "load_vet_schedules_modal":
            $vet_id = base64_decode($_POST["vet_id"]);
            $scheduleResult = $scheduleObj->getSpecificVetSchedule($vet_id);
            
            
            if($scheduleResult->num_rows>0){
                   
                $displayVetName = $scheduleObj->getSpecificVetSchedule($vet_id);
                $vetName = $displayVetName->fetch_assoc();
                ?>
                    <div class="row">
                        <div class="col-md-12">
                            <h3 align="center">Schedules of&nbsp;<?php echo $vetName["vet_fname"]." ".$vetName["vet_lname"];?></h3>
                            
                        </div>
                        
                    </div>
                   <div class="row">&nbsp;</div>
                   <?php
                while($schedule_row = $scheduleResult->fetch_assoc()){
                    
                    if($schedule_row["is_available"]==1){
                        ?>      
                   <div class="bg-success">
                       <?php
                    }
                    
                    else{
                        ?>
                       <div class="bg-warning">
                           <?php
                    }
                    ?>
                    <div class="row">
                        <div class="col-md-4 col-md-offset-9">
                            <a href="#" class="btn btn-warning" data-toggle="modal" onclick="editSchedule('<?php echo $schedule_row["vet_schedule_id"];?>')" data-target="#editSchedule"">
                                <span class ="glyphicon glyphicon-pencil"></span>&nbsp;
                                Edit
                            </a>
                        </div>
                    </div>       
                   <div class="row">
                       <div class="col-md-4">
                           <label class="control-label">Date :</label>
                       </div>
                       <div class="col-md-4">
                           <label class="control-label"><?php echo $schedule_row["date"]; ?></label> 
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-md-4">
                           <label class="control-label">Expected In Time :</label>
                       </div>
                       <div class="col-md-4">
                           <label class="control-label"><?php echo $schedule_row["exp_in_time"]; ?></label> 
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-md-4">
                           <label class="control-label">Expected Out Time :</label>
                       </div>
                       <div class="col-md-4">
                           <label class="control-label"><?php echo $schedule_row["exp_out_time"]; ?></label> 
                       </div>
                   </div>
                   </div>
                   </div>
                   
                   <hr>
                   <?php
            }
            }
            else{
                   ?>
                   <div class="row">
                       <div class="col-md-6 col-md-offset-3">
                           <div class="alert alert-warning">
                               <p align="center"><?php echo "No Schedules Found"; ?></p>
                           </div>
                           
                       </div>
                       
                   </div>
        <?php
            }
        break;
        
        case "load_schedule_modal":
            $vet_sch_id = ($_POST["vet_schedule_id"]);
            $scheduleResult = $scheduleObj->getSpecificSchedule($vet_sch_id);
            
            $schedule_row = $scheduleResult->fetch_assoc();
            ?>
                   <div class="row">    
                        <div class="col-md-4">
                            <label class="control-label">Date :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="hidden" name="vet_schedule_id" value="<?php echo $schedule_row["vet_schedule_id"]?>"/>
                            <input type="date" class="form-control" id="date" name="date" value="<?php echo $schedule_row["date"]; ?>" required="required"/>
                        </div>
                    </div>
                        
                    <div class="row">
                        <div class="col-md-12">
                            &nbsp;
                        </div>
                    </div>
                    <div class="row">    
                        <div class="col-md-4">
                            <label class="control-label">Expected In Time :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="time" class="form-control" name="in_time" id="in_time" value="<?php echo $schedule_row["exp_in_time"]; ?>" required="required"/>
                        </div>
                            
                    </div>
                        
                    <div class="row">
                        <div class="col-md-12">
                            &nbsp;
                        </div>
                    </div>
                    <div class="row">    
                        <div class="col-md-4">
                            <label class="control-label">Expected Out Time :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="time" class="form-control" name="out_time" id="out_time" value="<?php echo $schedule_row["exp_out_time"]; ?>" required="required" />
                        </div>
                            
                    </div>
                        
                    <div class="row">
                        <div class="col-md-12">
                            &nbsp;
                        </div>
                    </div>
                        
                    <div class="row">    
                        <div class="col-md-4">
                            <label class="control-label">Is Available :</label>
                        </div>
                        <div class="col-md-4">
                            <select class="form-control" name="available" id="availbale" required="required">
                                
                                <option value="1" 
                                    <?php
                                
                                if($schedule_row["is_available"]==1){
                                ?>
                                        selected="selected"
                                        
                                        <?php
                                }
                                ?>
                                        >Yes</option>
                                
                                
                                
                                
                                
                                
                                
                                <option value="0"
                                        <?php
                                        if($schedule_row["is_available"]==0){
                                            ?>
                                        selected="selected"
                                        <?php
                                        }
                                        ?>
                                        >No</option>
                                
                            </select>
                        </div>
                            
                    </div>
                        
                        <?php
            
            
            
            
        break;
        
        case "edit_schedule":
            
            $schedule_id = $_POST["vet_schedule_id"];
            $date = $_POST["date"];
            $in_time = $_POST["in_time"];
            $out_time = $_POST["out_time"];
            $availability = $_POST["available"];
            
            try {
                
                if($date==""){
                    throw new Exception("Please update the date correctly!");
                }
                
                if($in_time==""){
                    throw new Exception("Please update the in time correctly!");
                }
                
                if($out_time==""){
                    throw new Exception("Please update the out time correctly!");
                }
                $scheduleObj->updateSchedule($schedule_id, $date, $in_time, $out_time, $availability);
                $msg= "Schedule is Successfully Updated";
                $msg = base64_encode($msg);
                
                ?>
                    <script>window.location= "../view/view_vets.php?msg=<?php echo $msg; ?>" </script>
            <?php
            } 
            
            catch (Exception $ex) {
                
                $msg =$ex->getMessage();
                $msg = base64_encode($msg);
                
                ?>
                   <script>window.location= "../view/view_vets.php?msg=<?php echo $msg; ?>" </script>
                   
                 <?php
               
            }
            
            break;
    }
}
?>

