<?php

include_once "../commons/session.php";
if(!isset($_GET["status"])){
    
    ?>
<script>window.location= "../view/login.php" </script>
    <?php
}

else{
    
    include_once '../model/category_model.php';
    include_once '../model/brand_model.php';
    include_once '../model/product_model.php';
    include_once '../model/stock_model.php';
    //include_once '../model/notification_model.php';
    
    $categoryObj = new Category();
    $brandObj= new Brand();
    $productObj = new Product();
    $stockObj = new Stock();
    //$NotificationObj = new Notification();

    $status = $_GET["status"];
    
    switch($status){
        
        case  "add_category":
            
            try{
                $cat_name=$_POST["cat_name"];
                if($cat_name==""){
                    throw new Exception("Category Name Cannot be Empty!!");
                }
                $cat_id=$categoryObj->addCategory($cat_name);
                if($cat_id>0){
                    
                    $msg = "Category $cat_name Added Successfully";
                    $msg = base64_encode($msg);
                    
                    ?>

                    <script>window.location= "../view/categories_brands.php?msg=<?php echo $msg; ?>" </script>
                    <?php
                  
                }
            }
            
            catch (Exception $ex){
                
                $msg =$ex->getMessage();
                
                $msg = base64_encode($msg);
                
                ?>
                   <script>window.location= "../view/categories_brands.php?error=<?php echo $msg; ?>" </script>
                   
                 <?php
            }
             
            break;
            
        case "add_brand":
             
            try{
             
                $brand_name=$_POST["brand_name"];
                
                if($brand_name==""){
                    throw new Exception("Brand Name Cannot be Empty!");
                }
                
                                
                $brand_id=$brandObj->addBrand($brand_name);
                
                if($brand_id>0){
                    
                    $msg="Brand $brand_name Added Successfully";
                    $msg= base64_encode($msg);
                    ?>
                   <script>window.location= "../view/categories_brands.php?msg=<?php echo $msg; ?>" </script>
                   <?php
                }
                
                else{
                    echo "<script>alert('Brand Name Already Exist!')</script>";
                    ?>
                    <script>window.location= "../view/categories_brands.php" </script>
                    <?php
                }
                
                
             
            }
             
            catch (Exception $ex){
                 
                $msg =$ex->getMessage();
                
                $msg = base64_encode($msg);
                
                ?>
                   <script>window.location= "../view/categories_brands.php?error=<?php echo $msg; ?>" </script>
                   
                 <?php
            }
             
            break;
            
                 
        case "load_category":
             
            $cat_id=$_POST["cat_id"];
             
            $categoryResult=$categoryObj->getSpecificCategory($cat_id);
             
            $cat_row = $categoryResult->fetch_assoc();
             
            ?>
               <input type="hidden" name="cat_id" value="<?php echo $cat_id; ?>" />
               
               
               <div class="row">
                    <div class="col-md-3">
                        <label>Category Name</label>
                                    
                    </div>
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="cat_name" value="<?php echo $cat_row['cat_name']; ?>"/>
                    </div>
                </div>
                <?php
             
            break;
         
        case "update_category":
             
            $cat_name=$_POST["cat_name"];
            $cat_id=$_POST["cat_id"];
             
            $categoryObj->updateCategory($cat_id, $cat_name);
             
            $msg= "Category Updated Successfully";
            $msg= base64_encode($msg);
             
            ?>
               <script>window.location= "../view/categories_brands.php?msg=<?php echo $msg; ?>" </script>
            <?php
             
             
            break;
         
        case "load_brand":
            $brand_id=$_POST["brand_id"];
             
            $brandResult= $brandObj->getSpecificBrand($brand_id);
             
            $brand_row = $brandResult->fetch_assoc();
            ?>
               
               
               <div class="row">
                   
                   <input type="hidden" name="brand_id" value="<?php echo $brand_id; ?>" />
                    <div class="col-md-3">
                        <label>Brand Name</label>
                                    
                    </div>
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="brand_name" value="<?php echo $brand_row['brand_name']; ?>"/>
                    </div>
                </div>
               
               <?php
               
               break;
           
        case "update_brand":
             
            $brand_id=$_POST["brand_id"];
            $brand_name=$_POST["brand_name"];
             
            $brandObj->updateBrand($brand_id, $brand_name);
            
            $msg= "Brand Successfully Updated";
            $msg = base64_encode($msg);
             
            ?>
               <script>window.location= "../view/categories_brands.php?msg=<?php echo $msg; ?>" </script>
            <?php
             
            break;
         
        case "generate_barcode":
             $barcode = $_POST["barcode"];
             $barcode = urlencode($barcode);
             ?>
               <img alt="Barcode Generator TEC-IT"
                    src="https://barcode.tec-it.com/barcode.ashx?data=<?php echo $barcode; ?>&code=Code128&multiplebarcodes=false&translate-esc=true&unit=Fit&dpi=96&imagetype=Gif&rotation=0&color=%23000000&bgcolor=%23ffffff&codepage=Default&qunit=Mm&quiet=0&hidehrt=False&dmsize=Default%27"/>
               <?php
               
               break;
           
        case "validate_barcode":
            $barcode = $_POST["barcode"];
             
            $valid = $productObj->validateExistingBarcode($barcode);
             
            if($valid){
                 ?>
               <label class="label label-success">Barcode is Valid</label>
               <?php
            }
            else{
                 ?>
               <label class="label label-danger">Barcode is invalid</label>
               <?php
            }
            break;
             
        case "add_product":
             
            $prname=$_POST["prname"];
            $barcode=$_POST["barcode"];
            $cat_id=$_POST["cat_id"];
            $brand_id=$_POST["brand_id"];
            $unit_id=$_POST["unit_id"];
            $price=$_POST["price"];
            $exp_date = $_POST["exp_date"];
            $product_image;
             
            try{
                if($_FILES["product_image"]["name"]!=""){
                $imagename="".time()."_".$_FILES["product_image"]["name"];
                
                $temp = $_FILES["product_image"]["tmp_name"];
                
                move_uploaded_file($temp,"../images/product_images/$imagename");
                }
                
                else{
                    $imagename="";
                }
                
                //insert script to add the product
                
                $product_id=$productObj->addProduct($prname, $barcode, $cat_id, $brand_id, $unit_id, $price,$exp_date, $imagename);
                
                if($product_id>0){
                    $msg = "Product Successfully Added";
                    $msg = base64_encode($msg);
                    ?>
                    <script>window.location= "../view/view_products.php?msg=<?php echo $msg; ?>" </script>
            <?php
                }
            }
             
            catch (Exception $ex){
                $msg =$ex->getMessage();
                
                $msg = base64_encode($msg);
                
                 
            }
             
             
        break;
            
            case "deactivate_product":
            
            $product_id = base64_decode($_GET["product_id"]);
            $productObj->deactivateProduct($product_id);
            $msg = "Product Succesfully Deactivated";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/view_products.php?msg=<?php echo $msg; ?>"</script>
        
        <?php
        
        break;
    
        case "activate_product":
            
            $product_id = base64_decode($_GET["product_id"]);
            $productObj->activateProduct($product_id);
            $msg = "Product Succesfully Activated";
            $msg = base64_encode($msg);
            ?>
                  <script>window.location="../view/view_products.php?msg=<?php echo $msg; ?>"</script>
                   <?php
        
        break;
    
        case "add_stock_modal":
             
                $product_id = base64_decode($_POST["product_id"]);

                $productResult = $productObj->getSpecificProduct($product_id);
                $product_row=$productResult->fetch_assoc();
                ?>
                       <input type="hidden" name="product_id" value="<?php echo $product_row["product_id"]?>" method="post"/>
                       <div class="row">
                           <div class="col-md-3">
                               <label>Product Name :</label>
                           </div>
                           
                           <div class="col-md-3">
                               <?php echo ucfirst($product_row["product_name"]); ?>
                           </div>
                           
                           
                       </div>
                       <div class="row">
                           <div class="col-md-12">
                               &nbsp;
                           </div>
                       </div>

                       <div class="row">
                           <div class="col-md-3">
                               <label>Date :</label>
                           </div>
                           <div class="col-md-3">
                               <input type="date" class="form-control" name="stock_date" max="<?php echo date["Y-m-d"] ?>" />
                           </div>
                       </div>

                       <div class="row">
                           <div class="col-md-12">
                               &nbsp;
                           </div>
                       </div>

                       <div class="row">
                           <div class="col-md-3">
                               <label>Quantity :</label>
                           </div>
                           <div class="col-md-3">
                               <div class="input-group">
                                <input type="text" class="form-control" name="stock_qty" required="required"/>
                               <span class="input-group-addon">
                                   <?php echo $product_row["unit_name"]; ?>
                               </span>
                               </div>
                           </div>
                       </div>
                    <?php
        break;
        
        case "add_stock":
             
            $product_id=$_POST["product_id"];
            $stock_date=$_POST["stock_date"];
            $stock_qty=$_POST["stock_qty"];
            
            $stockObj->addStock($product_id, $stock_qty, $stock_date);
            
            $msg = "stock Added Activated";
            $msg = base64_encode($msg);
            
            ?>
                <script>window.location="../view/view_stock.php?msg=<?php echo $msg; ?>"</script>
            <?php
             
        break;
    
        case "load_stock_modal":
             
                $stock_id = base64_decode($_POST["stock_id"]);

                $stockResult = $stockObj->getSpecificStock($stock_id);
                $stock_row=$stockResult->fetch_assoc();
                ?>
                       <input type="hidden" name="stock_id" value="<?php echo $stock_row["stock_id"]?>" />
                       <div class="row">
                           <div class="col-md-3">
                               <label>Product Name :</label>
                           </div>
                           
                           <div class="col-md-3">
                               <?php echo ucfirst($stock_row["product_name"]); ?>
                           </div>
                           
                           
                       </div>
                       
                       <div class="row">
                           <div class="col-md-12">
                               &nbsp;
                           </div>
                       </div>
                       
                       <div class="row">
                           <div class="col-md-3">
                               <label>Brand :</label>
                           </div>
                           
                           <div class="col-md-3">
                               <?php echo ucfirst($stock_row["brand_name"]); ?>
                           </div>
                           
                       </div>
                       <div class="row">
                           <div class="col-md-12">
                               &nbsp;
                           </div>
                       </div>

                       <div class="row">
                           <div class="col-md-3">
                               <label>Date :</label>
                           </div>
                           <div class="col-md-3">
                               <input type="date" class="form-control" name="stock_date" value="<?php echo $stock_row["stock_date"] ?>" />
                           </div>
                       </div>

                       <div class="row">
                           <div class="col-md-12">
                               &nbsp;
                           </div>
                       </div>

                       <div class="row">
                           <div class="col-md-3">
                               <label>Quantity :</label>
                           </div>
                           <div class="col-md-3">
                               <div class="input-group">
                                   <input type="text" class="form-control" name="stock_qty" value="<?php echo $stock_row["quantity"] ?>" required="required"/>
                               <span class="input-group-addon">
                                   <?php echo $stock_row["unit_name"]; ?>
                               </span>
                               </div>
                           </div>
                       </div>
                    <?php
        break;
    
    
        case "edit_stock":
             
            $stock_id=$_POST["stock_id"];
            $stock_date=$_POST["stock_date"];
            $stock_qty=$_POST["stock_qty"];
            
            $stockObj->updateStock($stock_id,$stock_date,$stock_qty);
            
            $msg = "stock Successfully Updated";
            $msg = base64_encode($msg);
            
            ?>
                <script>window.location="../view/view_stock.php?msg=<?php echo $msg; ?>"</script>
            <?php
             
        break;
    
        case "return_stock_modal":
             
                $stock_id = base64_decode($_POST["stock_id"]);

                $stockResult = $stockObj->getSpecificStock($stock_id);
                $stock_row=$stockResult->fetch_assoc();
                ?>
                       <input type="hidden" name="stock_id" value="<?php echo $stock_row["stock_id"]?>" />
                       <div class="row">
                           <div class="col-md-4">
                               <label>Product Name :</label>
                           </div>
                           
                           <div class="col-md-4">
                               <?php echo ucfirst($stock_row["product_name"]); ?>
                           </div>
                           
                           
                       </div>
                       
                       <div class="row">
                           <div class="col-md-12">
                               &nbsp;
                           </div>
                       </div>
                       
                       <div class="row">
                           <div class="col-md-4">
                               <label>Brand :</label>
                           </div>
                           
                           <div class="col-md-4">
                               <?php echo ucfirst($stock_row["brand_name"]); ?>
                           </div>
                           
                       </div>
                       <div class="row">
                           <div class="col-md-12">
                               &nbsp;
                           </div>
                       </div>

                       <div class="row">
                           <div class="col-md-4">
                               <label>Returned Date :</label>
                           </div>
                           <div class="col-md-4">
                               <input type="date" class="form-control" name="return_stock_date" required="required"/>
                           </div>
                       </div>

                       <div class="row">
                           <div class="col-md-12">
                               &nbsp;
                           </div>
                       </div>

                       <div class="row">
                           <div class="col-md-4">
                               <label>Returned Quantity :</label>
                           </div>
                           <div class="col-md-4">
                               <div class="input-group">
                                   <input type="text" class="form-control" name="return_stock_qty" required="required"/>
                               <span class="input-group-addon">
                                   <?php echo $stock_row["unit_name"]; ?>
                               </span>
                               </div>
                           </div>
                       </div>
                    <?php
        break;
    
    
        case "add_returned_stock":
             
            $stock_id = $_POST["stock_id"];
            $stock_return_date = $_POST["return_stock_date"];
            $quantity = $_POST["return_stock_qty"];
            
            $stockObj->addReturnedStock($stock_id, $stock_return_date, $quantity);
            $stockObj->deductStock($stock_id, $quantity);
            
            $msg = "Returned Stock added successfully";
            $msg = base64_encode($msg);
            
            ?>
                <script>window.location="../view/view_stock.php?msg=<?php echo $msg; ?>"</script>
            <?php
             
        break;
             
            
    }
}
?>


