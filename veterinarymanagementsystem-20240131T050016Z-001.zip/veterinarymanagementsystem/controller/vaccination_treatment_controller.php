<?php

include_once "../commons/session.php";
if(!isset($_GET["status"])){
    
    ?>
<script>window.location= "../view/login.php" </script>
    <?php
}

else{
    
    include_once "../model/vaccination_model.php";
    $vacObj = new Vaccination();
    
    include_once '../model/treatment_model.php';
    $treatObj = new Treatment();
    
    $status = $_GET["status"];
    
    switch($status){
        
        case "give_vaccine":
            
            $patient = $_POST["patient_id"];
            $vet = $_POST["vet_id"];
            $vaccine = $_POST["vaccine_item"];
            $date = $_POST["date"];
            $desc = $_POST["desc"];
            
        try{
                if($patient==""){
                   throw new Exception("Patient must be selected!!!");
                }
                
                if($vet==""){
                   throw new Exception("Select a Veterinarian");
                }
                
                if(sizeof($vaccine)==0){
                    throw new Exception("A Vaccine Type Must Be Selected");
                }
                
                if($date==""){
                   throw new Exception("Date is Empty");
                }
                
                
                $vaccination_id = $vacObj->addVaccination($patient, $vet, $date, $desc);

                if ($vaccination_id>0){


                    foreach($vaccine as $v){
                        $vacObj->addPatientVaccination($vaccination_id, $v);
                    }

                     $msg = "Details Successfully Added";
                     $msg = base64_encode($msg);
                        ?>
                        <script>window.location= "../view/view_given_vaccines.php?msg=<?php echo $msg; ?>" </script>
                <?php
                }
            }
            
        catch (Exception $ex){
            $msg =$ex->getMessage();
            $msg = base64_encode($msg);
            ?>
                   <script>window.location= "../view/give_vaccine.php?msg=<?php echo $msg; ?>" </script>
                   
                 <?php
        }
        
        
        break;
        
        case "load_given_vaccine_modal":
            
            $vaccination_id = $_POST["vaccination_id"];
            
            $vaccinationResult = $vacObj->getSpecificGivenVaccination($vaccination_id);
            ?>
                   <div class="row">
                        <div class="col-md-12">
                            <?php
                            while($vaccination_row = $vaccinationResult->fetch_assoc()){
                                ?>
                            
                            <h5 align="center"><?php echo $vaccination_row["vaccine_item"]; ?></h5>
                            <?php
                            }
                            ?>
                        </div>
                        
                    </div>
            
        <?php  
        break;
        
        case "give_treatment":
            
            $patient = $_POST["patient_id"];
            $vet = $_POST["vet_id"];
            $treatment = $_POST["treatment_type"];
            $date = $_POST["date"];
            $desc = $_POST["desc"];
            
        try{
                if($patient==""){
                   throw new Exception("Patient must be selected!!!");
                }
                
                if($vet==""){
                   throw new Exception("Select a Veterinarian");
                }
                
                if(sizeof($treatment)==0){
                    throw new Exception("A Treatment Type Must Be Selected");
                }
                
                if($date==""){
                   throw new Exception("Date is Empty");
                }
                
                
                $treatment_id = $treatObj->addTreatment($patient, $vet, $date, $desc);

                if ($treatment_id>0){


                    foreach($treatment as $t){
                        $treatObj->addPatientTreatment($treatment_id, $t);
                    }

                     $msg = "Details Successfully Added";
                     $msg = base64_encode($msg);
                        ?>
                        <script>window.location= "../view/view_given_treatments.php?msg=<?php echo $msg; ?>" </script>
                <?php
                }
            }
            
        catch (Exception $ex){
            $msg =$ex->getMessage();
            $msg = base64_encode($msg);
            ?>
                   <script>window.location= "../view/give_treatment.php?msg=<?php echo $msg; ?>" </script>
                   
                 <?php
        }
        
        
        break;
        
        
        case "load_given_treatment_modal":
        
            $treatment_id = $_POST["treatment_id"];
            
            $treatmentResult = $treatObj->getSpecificGivenTreatment($treatment_id);
            ?>
                   <div class="row">
                        <div class="col-md-12">
                            <?php
                            while($treatment_row = $treatmentResult->fetch_assoc()){
                                ?>
                            
                            <h5 align="center"><?php echo ucwords($treatment_row["treatment_name"]); ?></h5>
                            <?php
                            }
                            ?>
                        </div>
                        
                    </div>
            
        <?php  
        break;
    }
}
?>

