

<?php

include_once "../commons/session.php";


$moduleArray = $_SESSION["user_module"];
if(!isset($_GET["status"])){
    
    ?>
<script>window.location= "../view/login.php" </script>
    <?php
}

else{
    
    
    $status = $_GET["status"];
    
    include_once '../model/product_model.php';
    include_once '../model/purchase_model.php';
    include_once '../model/notification_model.php';
    
    $productObj = new Product();
    $purchaseObj = new Purchase();
    $notificationObj = new Notification();
    
    $productResult = $productObj->getAllProducts();
    $unitResult = $productObj->getAllUnits();
    switch($status){
        
        case "load_row":
        
        ?> 
            <div class="added_row">
                <div class="col-md-4">
                    <select class="form-control" name="product_id[]"  id="product_id" required="required" >
                        <option value="">---</option>
                        <?php
                        while($product_row=$productResult->fetch_assoc()){
                        ?>
                        <option value="<?php echo $product_row["product_id"]; ?>">
                        <?php echo $product_row["product_name"]; ?>
                        </option>
                        <?php 
                            }
                        ?>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <input type="text" name="product_qty[]" id="product_qty" required="required"  class="form-control"/>
                </div>
                <div class="col-md-3">
                    <select class="form-control" name="unit_id[]"  id="unit_id" required="required" >
                        <option value="">---</option>
                        <?php
                        while($unit_row=$unitResult->fetch_assoc()){
                        ?>
                        <option value="<?php echo $unit_row["unit_id"]; ?>">
                        <?php echo $unit_row["unit_name"]; ?>
                        </option>
                        <?php 
                            } 
                        ?>
                    </select>
                </div>
                      
                <div class="col-md-2">
                    <a  href="#" class="rem_row btn btn-danger" >
                    <span class="glyphicon glyphicon-remove"></span>
                    Remove        
                    </a>
                </div>
                
                <div class="row">
                    <div class="col-md-12">&nbsp;</div>
                </div>
            </div>
        <?php
        
        break;
        
        
        case "add_requisition_note":
        
        $requested_by = $_POST["requested_by"];
        $required_date = $_POST["required_date"];
        $product_id = $_POST["product_id"];
        $product_qty = $_POST["product_qty"];
        $unit_id = $_POST["unit_id"];
        
        try{
            $note_id = $purchaseObj->addRequisitionNote($required_date,$requested_by) ;
        
        if($note_id>0){
            
            foreach($product_id as $index=>$name){
                
                $pro_id = $product_id[$index];
                $pro_qty = $product_qty[$index];
                $uni_id = $unit_id[$index];
                
                
                $purchaseObj->addProductRequisitionNote($note_id, $pro_id, $pro_qty, $uni_id);
                
                
                
                $msg="Request Submitted";
                $msg= base64_encode($msg);
                
               
            }
            
            ///Sending Notificaation for Approval
                date_default_timezone_set("Asia/Calcutta");
                $noti_date = date('Y-m-d H:i:s');
                $noti_desc = "New Request for Purchase the required Items";
                
                $notificationObj->addNotitfication($noti_date,$noti_desc);
                ?>
              <script>window.location="../view/view_request_note.php?msg=<?php echo $msg;?>" </script>
              <?php
        }
    }
        catch (Exception $ex)
         {
             $error=$ex->getMessage();
             $error= base64_encode($error);
             ?>
              <script>window.location="../view/add_request_note.php?msg=<?php echo $msg;?>" </script>
             <?php

         }        
 
      
        break;
        
        case "load_note_item_modal":
            
            $note_id = base64_decode($_POST["note_id"]);
            
            $itemResults = $purchaseObj->getRequestedItems($note_id);
            
            if($itemResults->num_rows>0){
                while($item_row = $itemResults->fetch_assoc()){

                    ?>
                <div class="row">
                        <div class="col-md-4">
                          <label class="control-label">Product</label>
                        </div>
                        <div class="col-md-4">
                          <?php echo $item_row["product_name"]; ?>
                        </div>
                </div>

                <div class="row">
                        <div class="col-md-4">
                          <label class="control-label">Required Quantity</label>
                        </div>
                        <div class="col-md-4">
                          <?php echo $item_row["quantity"]." ".$item_row["unit_name"]; ?>
                        </div>
                </div>
                <hr/>
            <?php
                }
            }
            
            break;
            
        case "approve_note":
            
            $note_id = base64_decode($_GET["note_id"]);
            
            $approved_by = $_SESSION["user"]["user_id"];
            
            $purchaseObj->approveNote($note_id, $approved_by);
            
            $msg = "Requisition Note Approved";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/view_request_note.php?msg=<?php echo $msg; ?>"</script>
        
        <?php
        
        break;
    
        case "reject_note":
            
            $note_id = base64_decode($_GET["note_id"]);
            
            $purchaseObj->rejectNote($note_id);
            
            $msg = "Requisition Note Rejected";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/view_request_note.php?msg=<?php echo $msg; ?>"</script>
        
        <?php
        
        break;
    
    
        case "view_requests":
            
            $noti_id = base64_decode($_GET["noti_id"]);
            
            $notificationObj->deactiveNotificationStatus($noti_id);
            
            ?>
                   <script>window.location="../view/view_request_note.php"</script>
        <?php
        
        break;
    }
}
?>

