<?php

include_once "../commons/session.php";
if(!isset($_GET["status"])){
    
    ?>
<script>window.location= "../view/login.php" </script>
    <?php
}

else{
    
    include_once "../model/manage_vaccine_model.php";
    include_once "../model/vaccine_stock_model.php";
    $vacObj = new Vaccine();
    $vacStockObj = new VaccineStock();

    $status = $_GET["status"];
    
    switch($status){
        
        case "add_vaccine":
            
            $item = $_POST["vac_item"];
            $quantity = $_POST["vac_quantity"];
            $date = $_POST["vac_stock_date"];
            
            try {
                
                if($item==""){
                    throw new Exception("Please Enter a Item");
                }
                
                if($quantity==""){
                    throw new Exception("Please specify the Quantity");
                }
                
                $vac_id = $vacObj->addVaccine($item);
                if($vac_id>0){
                    $vacStockObj->addVacStock($vac_id, $quantity, $date);

                    $msg = "Item Added Succesfully";
                    $msg = base64_encode($msg);

                ?>
                        <script>window.location= "../view/manage_vaccine.php?sucmsg=<?php echo $msg; ?>" </script>
                        
                    <?php
                }
                
                else{
                    echo "Item not added successfully";
                }
            }
            catch (Exception $ex) {
                $msg =$ex->getMessage();
                
                $msg = base64_encode($msg);
                
                ?>
                   <script>window.location= "../view/manage_vaccine.php?errmsg=<?php echo $msg; ?>" </script>
                   
                 <?php
                
                
            }
            
            
            break;
            
        case "deactivate_vaccine":
            
            $vaccine_id = $_GET["vaccine_id"];
            $vacObj->deactivateVaccine($vaccine_id);
            $msg = "Veccine Item Succesfully Deactivated";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/manage_vaccine.php?msg=<?php echo $msg; ?>"</script>
        
        <?php
        
        break;
    
        case "activate_vaccine":
            
            $vaccine_id = $_GET["vaccine_id"];
            $vacObj->activateVaccine($vaccine_id);
            $msg = "Vaccine Item Succesfully Activated";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/manage_vaccine.php?msg=<?php echo $msg; ?>"</script>
                   <?php
        
        break;
    
        
    
        case "stock_modal":
            
            $vaccine_id = $_POST["vaccineid"];
            $vaccineResults = $vacObj->getSpecificVaccine($vaccine_id);
            
            $vaccine_row = $vaccineResults->fetch_assoc();
            
            ?>
                    <div class="row">
                        <input type="hidden" name="vaccine_id" value="<?php echo $vaccine_id; ?>"/>
                        <div class="col-md-6">
                            <label class="control-label">Adding Stock for <?php echo $vaccine_row["vaccine_item"]; ?> :</label>
                        </div>
                        <div class="col-md-4">
                            <input type="number" class="form-control" id="item_name" name="quantity" required="required"/>
                        </div>
                    </div>
                    <div class="row">
                       <div class="col-md-12">&nbsp;</div>
                    </div>
                    <div class="row">
                       <div class="col-md-6">
                            <label class="control-label">Date :</label>
                       </div>
                       <div class="col-md-4">
                            <input type="date" class="form-control" id="date" name="date" required="required"/>
                        </div>
                    
                    </div>
                   <?php
                   
        break;
    
        case "add_stock_item":
            
            $vaccine_id = $_POST["vaccine_id"];
            $quantity = $_POST["quantity"];
            $date = $_POST["date"];
            $vacStockObj->addVacStock($vaccine_id, $quantity, $stock_date);
            
            $msg = "Stock Added Successfully";
            $msg = base64_encode($msg);
            ?>
                   <script>window.location="../view/manage_vaccine.php?msg=<?php echo $msg; ?>"</script>
                   <?php       
        break;
    }
}
?>


