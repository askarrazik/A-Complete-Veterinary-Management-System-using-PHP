

<?php

include_once "../commons/session.php";


$moduleArray = $_SESSION["user_module"];
if(!isset($_GET["status"])){
    
    ?>
<script>window.location= "../view/login.php" </script>
    <?php
}

else{
    
    
    $status = $_GET["status"];
    
    include_once '../model/purchase_order_model.php';
    
    $purchaseOrderObj = new Order(); 
    
    switch($status){
        
              
        case "add_purchase_order":
            
        $po_num = $_POST["po_no"];
        $sup_id = $_POST["sup_id"];
        $issued_date = date('y-m-d');    
        $required_date = $_POST["required_date"];
        $product_id = $_POST["product_id"];
        $product_qty = $_POST["product_qty"];
        $unit_id = $_POST["unit_id"];
        
        try{
            $po_id = $purchaseOrderObj->addPurchaseOrder($po_num,$sup_id, $issued_date, $required_date);
        
        if($po_id>0){
            
            foreach($product_id as $index=>$name){
                
                $pro_id = $product_id[$index];
                $pro_qty = $product_qty[$index];
                $uni_id = $unit_id[$index];
                
                
                $purchaseOrderObj->addProductItems($po_id, $pro_id, $pro_qty, $uni_id);
                
                
                $msg="Purchase Order Created Successfully";
                $msg= base64_encode($msg);
                
            }
            
                ?>
                <script>window.location="../view/view_purchase_orders.php?msg=<?php echo $msg;?>" </script>
              <?php
        }
    }
        catch (Exception $ex)
         {
             $error=$ex->getMessage();
             $error= base64_encode($error);
             ?>
              <script>window.location="../view/add_request_note.php?msg=<?php echo $msg;?>" </script>
             <?php

         }        
 
      
        break;
        
        case "load_order_item_modal":
            
            $po_id = base64_decode($_POST["po_id"]);
            
            $orderItemResult  = $purchaseOrderObj->getSpecificOrderedItems($po_id);
            
            if($orderItemResult->num_rows>0){
                while($item_row = $orderItemResult->fetch_assoc()){

                    ?>
                <div class="row">
                        <div class="col-md-4">
                          <label class="control-label">Product</label>
                        </div>
                        <div class="col-md-4">
                          <?php echo $item_row["product_name"]; ?>
                        </div>
                </div>

                <div class="row">
                        <div class="col-md-4">
                          <label class="control-label">Required Quantity</label>
                        </div>
                        <div class="col-md-4">
                          <?php echo $item_row["po_quantity"]." ".$item_row["unit_name"]; ?>
                        </div>
                </div>
                <hr/>
            <?php
                }
            }
            
            break;
            
            
        case "receive__ordered_items":
            
            $po_id = base64_decode($_GET["po_id"]);
            
            $purchaseOrderObj->receivePurchaseOrder($po_id);
            
            $msg="Purchase Order is receivd..!";
            $msg= base64_encode($msg);
            ?>
            <script>window.location= "../view/view_purchase_orders.php?msg=<?php echo $msg; ?>" </script>
        <?php
            
        break;
            
        case "undo_order_status":
            
            $po_id = base64_decode($_GET["po_id"]);
            
            $purchaseOrderObj->undoOrderStatus($po_id);
            
            $msg="Done";
            $msg= base64_encode($msg);
            ?>
            <script>window.location= "../view/view_purchase_orders.php?msg=<?php echo $msg; ?>" </script>
        <?php
            
        break;
        
    }
}
?>

