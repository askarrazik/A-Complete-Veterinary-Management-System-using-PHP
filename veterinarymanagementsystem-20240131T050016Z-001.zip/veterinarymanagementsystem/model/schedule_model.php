<?php
include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();
class Schedule{
        
        public function addSchedule($date,$in_time,$out_time,$availability,$vet_id){
            
            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO vet_schedule(date,exp_in_time,exp_out_time,is_available,vet_id)"
                    . "VALUES('$date','$in_time','$out_time','$availability','$vet_id')";
            $result=$conn->query($sql) or die($conn->error);
            $vet_sch_id=$conn->insert_id;
            return $vet_sch_id;


        }
        
        public function getSpecificVetSchedule($vet_id){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM veterinarian v, vet_schedule vc WHERE v.vet_id=vc.vet_id AND vc.vet_id='$vet_id' ORDER BY date desc ";
            $result=$conn->query($sql) or die($conn->error);
            return $result;


        }
        
        public function getSpecificSchedule($schedule_id){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM vet_schedule WHERE vet_schedule_id='$schedule_id'";
            $result=$conn->query($sql) or die($conn->error);
            return $result;


        }
        
        public function updateSchedule($schedule_id,$date,$in_time,$out_time,$availability){
            
            $conn=$GLOBALS["conn"];
            $sql="UPDATE vet_schedule SET date='$date',exp_in_time='$in_time',exp_out_time='$out_time',is_available='$availability'"
                    . " WHERE vet_schedule_id='$schedule_id'";
            $result=$conn->query($sql) or die($conn->error);
            


        }
        
        public function getAllSchedules(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM vet_schedule vs, veterinarian v WHERE vs.vet_id=v.vet_id AND date>=current_date";
            $result=$conn->query($sql) or die($conn->error);
            return $result;


        }
        
        
}       

  