<?php
include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();
class User{
        
        public function getUserModules($user_id){
         $conn=$GLOBALS["conn"];
         $sql="SELECT * FROM user u, module_role mr, module m "
                 . "WHERE u.user_role=mr.role_id AND "
                 . "mr.module_id=m.module_id AND "
                 . "u.user_id='$user_id'";
         $result=$conn->query($sql);
         return $result;
         
        }
        
        public function getUserById($user_id) {
        $conn=$GLOBALS["conn"];
         $sql="SELECT * FROM user u,role r WHERE u.user_role=r.role_id AND u.user_id='$user_id'";
         $result=$conn->query($sql);
         return $result;
        }
        
        
        
     
        
}       

  