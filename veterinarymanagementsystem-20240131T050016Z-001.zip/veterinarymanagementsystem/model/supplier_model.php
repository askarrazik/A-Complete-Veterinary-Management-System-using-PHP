<?php
include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();
class Supplier{
        
        public function addSupplier($org_name,$brn,$email){
            
            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO supplier(sup_org,sup_brn,sup_email)"
                    . "VALUES('$org_name','$brn','$email')";
            $result=$conn->query($sql) or die($conn->error);
            $sup_id=$conn->insert_id;
            return $sup_id;

        }
        
        public function addSupplierContact($sup_id,$contact,$contact_type){
         $conn=$GLOBALS["conn"];
         $sql="INSERT INTO supplier_contact(sup_id,contact_no,contact_type)VALUES('$sup_id','$contact','$contact_type')";
         $result=$conn->query($sql);
         return $result;
         
        }
        
        public function addSupplierAddress($sup_id,$no,$sreet,$city){
         $conn=$GLOBALS["conn"];
         $sql="INSERT INTO supplier_address(sup_id,door_no,street,city)VALUES('$sup_id','$no','$sreet','$city')";
         $result=$conn->query($sql);
         return $result;
         
        }
        
        public function getAllSupplier(){
         $conn=$GLOBALS["conn"];
         $sql="SELECT * FROM supplier s, supplier_contact sc, supplier_address sa WHERE s.sup_id=sc.sup_id AND s.sup_id=sa.sup_id AND sc.contact_type=2";
         $result=$conn->query($sql);
         return $result;
         
        }
        
        public function getSpcificSupplier($sup_id){
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM supplier s, supplier_address sa WHERE s.sup_id=sa.sup_id AND s.sup_id='$sup_id'";
            $result=$conn->query($sql);
            return $result;

        }
        
        public function getSpcificSupplierContact($sup_id){
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM supplier_contact WHERE sup_id='$sup_id'";
            $result=$conn->query($sql);
            return $result;

        }
        
        public function deactivateSupplier($sup_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE supplier SET sup_status=0 WHERE sup_id='$sup_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function activateSupplier($sup_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE supplier SET sup_status=1 WHERE sup_id='$sup_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function updateSupplier($org_name,$brn,$email,$sup_id){
            
            $conn= $GLOBALS["conn"];  
            $sql="UPDATE supplier SET "
                . "sup_org='$org_name',"
                . "sup_brn='$brn',"
                . "sup_email='$email'"
                . "WHERE sup_id='$sup_id' ";
            
            $result=$conn->query($sql) or die($conn->error);
                                            
        }
        
        public function updateSupplierContact($sup_id,$contact_no,$contact_type){
            
            $conn= $GLOBALS["conn"];  
            $sql="UPDATE supplier_contact SET contact_no='$contact_no' WHERE sup_id='$sup_id' AND contact_type='$contact_type'";
            $result=$conn->query($sql) or die($conn->error);
                                            
            
        }
        
        public function updateSupplierAddress($address_no,$address_street,$address_city,$sup_id){
            
            $conn= $GLOBALS["conn"];  
            $sql="UPDATE supplier_address SET door_no='$address_no', street='$address_street',city='$address_city' WHERE sup_id='$sup_id'";
            $result=$conn->query($sql) or die($conn->error);
                                            
            
            
        }
        
               
        public function getAllSupplierCount(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(sup_id) as sup_count FROM supplier";
            $result=$conn->query($sql);

            $supplierrow = $result->fetch_assoc();

            $count = $supplierrow["sup_count"];

            return $count;
        }
        
        public function getActiveSupplierCount(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(sup_id) as activeSupplierCount FROM supplier WHERE sup_status=1";
            $result=$conn->query($sql);

            $supplierrow = $result->fetch_assoc();

            $count = $supplierrow["activeSupplierCount"];

            return $count;
        }
        
        public function getdeactiveSupplierCount(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(sup_id) as deactiveSupplierCount FROM supplier WHERE sup_status=0";
            $result=$conn->query($sql);

            $supplierrow = $result->fetch_assoc();

            $count = $supplierrow["deactiveSupplierCount"];

            return $count;
        }
        
}       

  