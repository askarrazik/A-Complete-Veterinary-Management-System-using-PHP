<?php

include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();

class VaccineStock{
   public function addVacStock($vac_id, $quantity, $stock_date){
       
        $conn=$GLOBALS["conn"];
        $sql="INSERT INTO vaccine_stock(vac_id,vac_quantity,vac_stock_date) VALUES('$vac_id','$quantity', '$stock_date')";
        $result=$conn->query($sql);
        return $result;
        $vac_stock_id=$conn->insert_id;
        return $app_id;

   }
   
   public function getVaccineStock($vaccine_id){
       
        $conn=$GLOBALS["conn"];
        $sql="SELECT SUM(vac_quantity) as tot_qty,vac_stock_date FROM vaccine_stock WHERE vac_id='$vaccine_id' GROUP BY vac_id";
        $result=$conn->query($sql);
        
        $stockrow = $result->fetch_assoc();
        
        $qty = $stockrow["tot_qty"];
        
        return $qty;
   }
}

