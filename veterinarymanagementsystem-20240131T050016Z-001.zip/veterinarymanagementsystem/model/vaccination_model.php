<?php
include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();

class Vaccination{
    
    public function getAllActiveVaccine(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM vaccine WHERE status=1";
            $result=$conn->query($sql);
            return $result;

    }
    
    public function addVaccination($patient_id,$vet_id,$date,$desc){
            
            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO vaccination(patient_id,vet_id,date,description)VALUES('$patient_id','$vet_id','$date','$desc')";
            $result=$conn->query($sql) or die($conn->error);
            $vaccination_id=$conn->insert_id;
            return $vaccination_id;

    }
    
    public function addPatientVaccination($vaccination_id,$vaccine_type_id){
        $conn = $GLOBALS["conn"];
        $sql = "INSERT INTO patient_vaccination(vaccination_id,vaccine_type_id)VALUES('$vaccination_id','$vaccine_type_id')";
        $result=$conn->query($sql);
        return $result;
    }
    
    public function getGivenVaccination(){
        $conn = $GLOBALS["conn"];
        $sql = "SELECT * FROM vaccination v, patient p, veterinarian vt WHERE v.patient_id=p.patient_id AND v.vet_id = vt.vet_id";
        $result=$conn->query($sql);
        return $result;
    }
    
    public function getSpecificGivenVaccination($vaccination_id){
        $conn = $GLOBALS["conn"];
        $sql = "SELECT * FROM patient_vaccination pv, vaccine v WHERE pv.vaccine_type_id=v.vaccine_id AND pv.vaccination_id = '$vaccination_id'";
        $result=$conn->query($sql);
        return $result;
    }
    
    public function getVaccinationCount(){
        
        $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(vaccination_id) as vaccination_count FROM patient_vaccination";
            $result=$conn->query($sql);

            $vaccinationrow = $result->fetch_assoc();

            $count = $vaccinationrow["vaccination_count"];

            return $count;
    }
    
    
        
        
        
        
}       

  