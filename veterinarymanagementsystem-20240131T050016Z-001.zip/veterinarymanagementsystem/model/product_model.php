<?php

include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();

class Product{
    
        public function getAllUnits(){

            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM unit";
            $result=$conn->query($sql);
            return $result;

        }

        public function validateExistingBarcode($barcode){

            $conn=$GLOBALS["conn"];
            $sql="SELECT 1 FROM product WHERE barcode_number='$barcode'";
            $result=$conn->query($sql);

            if($result->num_rows>0){//when barcode is already there
                return false;
            }

            else{
                // when barcode is not available
                return true;
            }        
        }

        public function addProduct($prname, $barcode, $cat_id, $brand_id, $unit_id, $price, $exp_date, $product_image){

            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO product(product_name, unit_id, cat_id, brand_id, product_price, barcode_number,exp_date,product_image)"
                    . "VALUES('$prname','$unit_id','$cat_id','$brand_id','$price','$barcode','$exp_date', '$product_image')";
            $result=$conn->query($sql) or die($conn->error);
            return $result;
            return $conn->insert_id;

        }

        public function getAllProducts(){

            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM product p, category c, brand b, unit u WHERE p.cat_id=c.cat_id AND p.brand_id=b.brand_id AND p.unit_id=u.unit_id";
            $result=$conn->query($sql) or die($conn->error);
            return $result;

          }



        public function getSpecificProduct($product_id){

            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM product p, category c, brand b, unit u WHERE p.cat_id=c.cat_id"
                    ." AND p.brand_id=b.brand_id AND p.unit_id=u.unit_id AND p.product_id='$product_id'";
            $result=$conn->query($sql) or die($conn->error);
            return $result;
        }
    
        public function deactivateProduct($product_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE product SET product_status=0 WHERE product_id='$product_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function activateProduct($product_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE product SET product_status=1 WHERE product_id='$product_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        
        public function getAllProductsCount(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(product_id) as product_count FROM product";
            $result=$conn->query($sql);

            $productrow = $result->fetch_assoc();

            $count = $productrow["product_count"];

            return $count;
        }
        
        public function getActiveProductsCount(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(product_id) as active_product_count FROM product WHERE product_status=1";
            $result=$conn->query($sql);

            $activeproductrow = $result->fetch_assoc();

            $count = $activeproductrow["active_product_count"];

            return $count;
        }
        
        public function getDeactiveProductsCount(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(product_id) as deactive_product_count FROM product WHERE product_status=0";
            $result=$conn->query($sql);

            $deactiveproductrow = $result->fetch_assoc();

            $count = $deactiveproductrow["deactive_product_count"];

            return $count;
        }
        
         public function getExpiringProductsCount(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(product_id) as expiring_product_count FROM product WHERE exp_date >= CURRENT_DATE AND"
                    . " exp_date <= DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY)";
            $result=$conn->query($sql);

            $expireproductrow = $result->fetch_assoc();

            $count = $expireproductrow["expiring_product_count"];

            return $count;
        }
    
}

