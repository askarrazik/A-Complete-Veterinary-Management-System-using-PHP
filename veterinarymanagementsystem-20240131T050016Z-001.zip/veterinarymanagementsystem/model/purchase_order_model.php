<?php
include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();

    class Order{

        public function addPurchaseOrder($po_no,$sup_id,$issued_date,$required_date){

            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO purchase_order(po_no,supplier_id,issued_date,required_date) VALUES('$po_no','$sup_id','$issued_date','$required_date')";
            $result=$conn->query($sql) or die($conn->error);
            $po_id= $conn->insert_id;
            return $po_id;
        }

        public function addProductItems($po_id,$product_id,$product_qty,$unit_id){

            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO product_purchase_order(po_id,product_id,po_quantity,unit_id) VALUES('$po_id','$product_id','$product_qty','$unit_id')";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function getAllPurchaseOrders(){

            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM purchase_order po, supplier s WHERE po.supplier_id=s.sup_id";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function getSpecificPurchaseOrder($po_id){

            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM purchase_order po, supplier s WHERE po.supplier_id=s.sup_id AND po.po_id =$po_id";
            $result=$conn->query($sql);
            return $result;
        }
        

        public function getSpecificOrderedItems($po_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "SELECT * FROM product_purchase_order po, product p, unit u WHERE po.po_id = '$po_id' "
                    . "AND p.product_id = po.product_id AND po.unit_id=u.unit_id";
            $result = $conn->query($sql);
            return $result;
        }
        
        
        public function receivePurchaseOrder($po_id){
            
            $conn= $GLOBALS["conn"];
            $sql="UPDATE purchase_order SET po_status=2 WHERE po_id='$po_id'";
            $result=$conn->query($sql) or die($conn->error);  
            return $result; 
        }
        
        public function undoOrderStatus($po_id){
            
            $conn= $GLOBALS["conn"];
            $sql="UPDATE purchase_order SET po_status=1 WHERE po_id='$po_id'";
            $result=$conn->query($sql) or die($conn->error);  
            return $result; 
        }
        
        


    }