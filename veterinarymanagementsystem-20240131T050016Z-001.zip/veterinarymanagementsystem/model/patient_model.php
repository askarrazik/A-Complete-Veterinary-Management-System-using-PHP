<?php
include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();
class Patient{
    
        public function getPatientOwner($customer_id){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM customer WHERE cus_fname LIKE '$customer_id%'";
            $result=$conn->query($sql);
            return $result;

        }
        
        public function getPatientSpecies(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM species";
            $result=$conn->query($sql);
            return $result;

        }
        
        public function getBreedBySpecies($species_id){
         $conn=$GLOBALS["conn"];
         $sql="SELECT * FROM breed WHERE species_id ='$species_id'";
         $result=$conn->query($sql);
         return $result;
         
        }
        
        public function addpatient($name,$owner,$species,$breed,$gender,$dob,$colour,$weight,$notes,$patient_image){
            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO patient(patient_name,owner,species_id,breed_id,patient_gender,patient_dob,patient_colour,patient_weight,notes,patient_image)"
                    . "VALUES ('$name','$owner','$species','$breed','$gender','$dob','$colour','$weight','$notes','$patient_image')";
            $result=$conn->query($sql) or die($conn->error);
            $pat_id=$conn->insert_id;
            return $pat_id;
         
        }
        
        public function getAllPatients(){
            $conn = $GLOBALS["conn"];
            $sql = "SELECT * FROM patient p, species s, breed b, customer c WHERE p.species_id=s.species_id AND p.breed_id=b.breed_id AND p.owner=c.cus_id";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function getSpecificPatient($patient_id){
            $conn = $GLOBALS["conn"];
            $sql = "SELECT * FROM patient p, species s, breed b, customer c WHERE p.species_id=s.species_id AND "
                    . "p.breed_id=b.breed_id AND p.owner=c.cus_id AND patient_id='$patient_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function deactivatePatient($patient_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE patient SET patient_status=0 WHERE patient_id='$patient_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function activatePatient($patient_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE patient SET patient_status=1 WHERE patient_id='$patient_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function updatePatient($patient_id,$patient_name,$owner_id,$species_id,$breed_id,$patient_gender,$patient_dob,$colour,$weight,$notes,$patient_image){
            
        $conn= $GLOBALS["conn"];
        if($patient_image!=""){
            
            $sql="UPDATE patient SET "
                 . "patient_name='$patient_name',"
                 . "owner='$owner_id',"
                 . "species_id='$species_id',"
                 . "breed_id='$breed_id',"
                 . "patient_gender='$patient_gender',"
                 . "patient_dob='$patient_dob',"
                 . "patient_colour='$colour',"
                 . "patient_weight='$weight',"
                 . "notes='$notes',"
                 . "patient_image='$patient_image'"
                 . "WHERE patient_id='$patient_id' ";
                                            
        }
        
        else{
            
            $sql="UPDATE patient SET "
                 . "patient_name='$patient_name',"
                 . "owner='$owner_id',"
                 . "species_id='$species_id',"
                 . "breed_id='$breed_id',"
                 . "patient_gender='$patient_gender',"
                 . "patient_dob='$patient_dob',"
                 . "patient_colour='$colour',"
                 . "patient_weight='$weight',"
                 . "notes='$notes',"
                 . "patient_image='$patient_image'"
                 . "WHERE patient_id='$patient_id' ";
        }
            $result=$conn->query($sql) or die($conn->error);
        }
        
        
        public function getPatientCount($species_id){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(patient_id) as patient_count FROM patient WHERE species_id='$species_id'";
            $result=$conn->query($sql) or die($conn->error);
            return $result;
        }
        
        public function getAllPatientCount(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(patient_id) as patient_count FROM patient";
            $result=$conn->query($sql);

            $patientrow = $result->fetch_assoc();

            $count = $patientrow["patient_count"];

            return $count;
        }
        
        public function getActivePatientCount(){
            $conn= $GLOBALS["conn"];
            $sql="SELECT COUNT(patient_id) as activePatientCount FROM patient WHERE patient_status='1'";
            $result=$conn->query($sql) or die($conn->error);
        
            return $result;
        }
        
        public function getDeactivePatientCount(){
            $conn= $GLOBALS["conn"];
            $sql="SELECT COUNT(patient_id) as deactivePatientCount FROM patient WHERE patient_status='0'";
            $result=$conn->query($sql) or die($conn->error);
        
            return $result;
        }
        
        public function getPatientBySearch($patient_id){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM patient p, species s, breed b, customer c "
                    . "WHERE p.species_id=s.species_id AND p.breed_id=b.breed_id AND p.owner=c.cus_id AND patient_name LIKE '$patient_id%'";
            $result=$conn->query($sql);
            return $result;

        }
     
        
}       

  