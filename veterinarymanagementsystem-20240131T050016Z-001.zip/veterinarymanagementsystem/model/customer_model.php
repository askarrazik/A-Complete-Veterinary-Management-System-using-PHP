<?php
include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();
class Customer{
        
        public function addCustomer($cus_fname,$cus_lname,$gender,$nic,$email){
            
            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO customer(cus_fname,cus_lname,cus_gender,cus_nic,cus_email)"
                    . "VALUES('$cus_fname','$cus_lname','$gender','$nic','$email')";
            $result=$conn->query($sql) or die($conn->error);
            $cus_id=$conn->insert_id;
            return $cus_id;

        }
        
        public function addCustomerContact($cus_id,$contact,$contact_type){
         $conn=$GLOBALS["conn"];
         $sql="INSERT INTO cus_contact(cus_id,contact_no,contact_type)VALUES('$cus_id','$contact','$contact_type')";
         $result=$conn->query($sql);
         return $result;
         
        }
        
        public function addCustomerAddress($cus_id,$no,$sreet,$city){
         $conn=$GLOBALS["conn"];
         $sql="INSERT INTO cus_address(cus_id,door_no,street,city)VALUES('$cus_id','$no','$sreet','$city')";
         $result=$conn->query($sql);
         return $result;
         
        }
        
        public function getAllCustomer(){
         $conn=$GLOBALS["conn"];
         $sql="SELECT * FROM customer c, cus_contact cc, cus_address ca WHERE c.cus_id=cc.cus_id AND c.cus_id=ca.cus_id AND cc.contact_type=2";
         $result=$conn->query($sql);
         return $result;
         
        }
        
        public function getSpcificCustomer($customer_id){
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM customer c, cus_address ca WHERE c.cus_id=ca.cus_id AND c.cus_id='$customer_id'";
            $result=$conn->query($sql);
            return $result;

        }
        
        public function getSpcificCustomerContact($customer_id){
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM cus_contact WHERE cus_id='$customer_id'";
            $result=$conn->query($sql);
            return $result;

        }
        
        public function deactivateCustomer($customer_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE customer SET cus_status=0 WHERE cus_id='$customer_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function activateCustomer($customer_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE customer SET cus_status=1 WHERE cus_id='$customer_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function updateCustomer($cus_fname,$cus_lname,$gender,$nic,$email,$customer_id){
            
            $conn= $GLOBALS["conn"];  
            $sql="UPDATE customer SET "
                . "cus_fname='$cus_fname',"
                . "cus_lname='$cus_lname',"
                . "cus_gender='$gender',"
                . "cus_nic='$nic',"
                . "cus_email='$email'"
                . "WHERE cus_id='$customer_id' ";
            
            $result=$conn->query($sql) or die($conn->error);
                                            
        }
        
        public function updateCustomerContact($customer_id,$contact_no,$contact_type){
            
            $conn= $GLOBALS["conn"];  
            $sql="UPDATE cus_contact SET contact_no='$contact_no' WHERE cus_id='$customer_id' AND contact_type='$contact_type'";
            $result=$conn->query($sql) or die($conn->error);
                                            
            
        }
        
        public function updateCustomerAddress($address_no,$address_street,$address_city,$customer_id){
            
            $conn= $GLOBALS["conn"];  
            $sql="UPDATE cus_address SET door_no='$address_no', street='$address_street',city='$address_city' WHERE cus_id='$customer_id'";
            $result=$conn->query($sql) or die($conn->error);
                                            
            
            
        }
        
        public function addCustomerComplaint($complaint){
            
            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO customer_complaint(complaint)"
                    . "VALUES('$complaint')";
            $result=$conn->query($sql) or die($conn->error);
            $comp_id=$conn->insert_id;
            return $comp_id;

        }
        
        public function getAllComplaints(){
            
            $conn= $GLOBALS["conn"];  
            $sql="SELECT * FROM customer_complaint";
            $result=$conn->query($sql) or die($conn->error);
            return $result;                                
            
            
        }
        
        public function getAllCustomerCount(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(cus_id) as cus_count FROM customer";
            $result=$conn->query($sql);

            $customerrow = $result->fetch_assoc();

            $count = $customerrow["cus_count"];

            return $count;
        }
        
        public function getActiveCustomerCount(){
            $conn= $GLOBALS["conn"];
            $sql="SELECT COUNT(cus_id) as activeCustomerCount FROM customer WHERE cus_status='1'";
            $result=$conn->query($sql) or die($conn->error);
        
            return $result;
        }
        
        public function getDeactiveCustomerCount(){
            $conn= $GLOBALS["conn"];
            $sql="SELECT COUNT(cus_id) as deactiveCustomerCount FROM customer WHERE cus_status='0'";
            $result=$conn->query($sql) or die($conn->error);
        
            return $result;
        }
        
        
        
     
        
}       

  