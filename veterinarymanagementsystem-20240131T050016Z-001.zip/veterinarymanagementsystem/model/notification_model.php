<?php

include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();

class Notification{
    
    public function addNotitfication($noti_date,$description){
        
            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO notification(noti_date,noti_descrip) VALUES('$noti_date','$description')";
            $result=$conn->query($sql);
            return $notification_id=$conn->insert_id;
    }
    
    
    public function getNotificationCount(){
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(noti_id) as noti_count FROM notification WHERE noti_status =1";
            $result=$conn->query($sql);
            return $result;    
    }
    
    public function getAllNotification(){
        
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM notification ORDER BY noti_id DESC LIMIT 10";
            $result=$conn->query($sql);
            return $result;
        
    }
    
    public function deactiveNotificationStatus($noti_id){
        
            $conn=$GLOBALS["conn"];
            $sql="UPDATE notification SET noti_status = 0 WHERE noti_id = '$noti_id'";
            $result=$conn->query($sql);
            return $result;    
    }
    
    
    
    
}

