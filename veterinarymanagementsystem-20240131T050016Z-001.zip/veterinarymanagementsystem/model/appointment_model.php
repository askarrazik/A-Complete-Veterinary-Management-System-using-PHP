<?php
include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();
class Appointment{
    
    
        public function getAppointmentType(){
            
            $conn=$GLOBALS["conn"];
            $sql = "SELECT * FROM appointment_type";
            $result=$conn->query($sql) or die($conn->error);
            return $result;

        }
        
        public function addAppointment($customer,$type,$date,$time,$vet){
            
            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO appointment(customer,app_type,date,time,veterinarian)"
                    . "VALUES('$customer','$type','$date','$time','$vet')";
            $result=$conn->query($sql) or die($conn->error);
            $app_id=$conn->insert_id;
            return $app_id;

        }
        
        public function getSpecificApp($app_id){
            
            $conn=$GLOBALS["conn"];
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM appointment a, customer c, veterinarian v WHERE a.app_id='$app_id' AND a.customer=c.cus_id AND a.veterinarian=v.vet_id";
            $result=$conn->query($sql);
            return $result;

        }
        
        
        public function getAllApp(){
            
            $conn=$GLOBALS["conn"];
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM appointment a, customer c, veterinarian v WHERE a.customer=c.cus_id AND a.veterinarian=v.vet_id";
            $result=$conn->query($sql);
            return $result;

        }
        /////updating status 2 for done appointments
        public function DoneApp($app_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE appointment SET app_status=2 WHERE app_id='$app_id'";
            $result=$conn->query($sql);
            return $result;
        }
        /////updating status 0 for cancelled appointments
        public function CancelApp($app_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE appointment SET app_status=0 WHERE app_id='$app_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function editApp($app_id,$date,$time){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE appointment SET date='$date',time='$time' WHERE app_id='$app_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function getAppCalander(){
        
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM appointment";
            $result=$conn->query($sql) or die($conn->error);
            return $result;

        }
        
        
        public function getAppByDate($date){
        
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM appointment a, veterinarian v, customer c WHERE a.veterinarian=v.vet_id AND date = '$date' AND a.customer=c.cus_id";
            $result=$conn->query($sql) or die($conn->error);
            return $result;

        }
        
        public function getAllAppointmentCount(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(app_id) as app_count FROM appointment";
            $result=$conn->query($sql);

            $approw = $result->fetch_assoc();

            $count = $approw["app_count"];

            return $count;
        }
        
        public function getPendingAppointmentCount(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(app_id) as pending_app_count FROM appointment WHERE app_status = 1";
            $result=$conn->query($sql);

            $approw = $result->fetch_assoc();

            $count = $approw["pending_app_count"];

            return $count;
        }
        
        public function getDoneAppointmentCount(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(app_id) as done_app_count FROM appointment WHERE app_status = 2";
            $result=$conn->query($sql);

            $approw = $result->fetch_assoc();

            $count = $approw["done_app_count"];

            return $count;
        }
        
        public function getCancelledAppointmentCount(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(app_id) as cancelled_app_count FROM appointment WHERE app_status = 0";
            $result=$conn->query($sql);

            $approw = $result->fetch_assoc();

            $count = $approw["cancelled_app_count"];

            return $count;
        }
    
    
    
        
        
        
        
     
        
}       

  