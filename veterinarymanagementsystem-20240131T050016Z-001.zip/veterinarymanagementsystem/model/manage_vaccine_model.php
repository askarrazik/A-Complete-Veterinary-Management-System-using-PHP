<?php
include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();
class Vaccine{
        
        public function addVaccine($item){
            
            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO vaccine(vaccine_item)VALUES('$item')";
            $result=$conn->query($sql) or die($conn->error);
            $app_id=$conn->insert_id;
            return $app_id;

        }   
        
        public function getSpecificVaccine($vac_id){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM vaccine WHERE vaccine_id=$vac_id";
            $result=$conn->query($sql);
            return $result;

        }

        public function getAllVaccine(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM vaccine";
            $result=$conn->query($sql);
            return $result;

        }
        
        public function deactivateVaccine($vaccine_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE vaccine SET status=0 WHERE vaccine_id='$vaccine_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function activateVaccine($vaccine_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE vaccine SET status=1 WHERE vaccine_id='$vaccine_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function editVaccineItem($vaccine_id,$vaccine_item){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE vaccine SET vaccine_item='$vaccine_item' WHERE vaccine_id='$vaccine_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function getVaccineCount(){
        
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(vaccine_id) as vaccines_count FROM vaccine";
            $result=$conn->query($sql);

            $vaccinerow = $result->fetch_assoc();

            $count = $vaccinerow["vaccines_count"];

            return $count;
        }
        
        public function getActiveVaccineCount(){
        
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(vaccine_id) as active_vaccines_count FROM vaccine WHERE status=1";
            $result=$conn->query($sql);

            $activevaccinerow = $result->fetch_assoc();

            $count = $activevaccinerow["active_vaccines_count"];

            return $count;
        }
        
        public function getDeactiveVaccineCount(){
        
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(vaccine_id) as deactive_vaccines_count FROM vaccine WHERE status=0";
            $result=$conn->query($sql);

            $deactivevaccinerow = $result->fetch_assoc();

            $count = $deactivevaccinerow["deactive_vaccines_count"];

            return $count;
        }
        
        
        
        
     
        
}       

  