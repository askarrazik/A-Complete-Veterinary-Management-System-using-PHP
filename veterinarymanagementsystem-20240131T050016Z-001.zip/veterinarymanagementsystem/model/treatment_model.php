<?php
include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();

class Treatment{
    
    public function getAllActiveTreatment(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM treatment_type WHERE treatment_status=1";
            $result=$conn->query($sql);
            return $result;

    }
    
    public function addTreatment($patient_id,$vet_id,$date,$desc){
            
            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO treatment(patient_id,vet_id,date,description)VALUES('$patient_id','$vet_id','$date','$desc')";
            $result=$conn->query($sql) or die($conn->error);
            $treatment_id=$conn->insert_id;
            return $treatment_id;

    }
    
    public function addPatientTreatment($treatment_id,$treatment_type_id){
        $conn = $GLOBALS["conn"];
        $sql = "INSERT INTO patient_treatment(treatment_id,treatment_type_id)VALUES('$treatment_id','$treatment_type_id')";
        $result=$conn->query($sql);
        return $result;
    }
    
    public function getGivenTreatment(){
        $conn = $GLOBALS["conn"];
        $sql = "SELECT * FROM treatment t, patient p, veterinarian v WHERE t.patient_id=p.patient_id AND t.vet_id = v.vet_id";
        $result=$conn->query($sql);
        return $result;
    }
    
    public function getSpecificGivenTreatment($treatment_id){
        $conn = $GLOBALS["conn"];
        $sql = "SELECT * FROM patient_treatment pt, treatment_type t WHERE pt.treatment_type_id=t.treatment_type_id AND pt.treatment_id = '$treatment_id'";
        $result=$conn->query($sql);
        return $result;
    }
    
    
    public function getTreatmentCount(){
        
        $conn=$GLOBALS["conn"];
        $sql="SELECT COUNT(treatment_id) as treatment_count FROM patient_treatment";
        $result=$conn->query($sql);

        $treatmentrow = $result->fetch_assoc();

        $count = $treatmentrow["treatment_count"];

        return $count;
    }
    
    
        
        
        
        
}       

  