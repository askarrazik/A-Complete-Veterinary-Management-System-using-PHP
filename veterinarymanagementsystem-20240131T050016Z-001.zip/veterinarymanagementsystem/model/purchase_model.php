<?php
include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();

    class Purchase{

        public function addRequisitionNote($required_date,$requested_by){

            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO requisition_note(requisition_date,requested_by) VALUES('$required_date','$requested_by')";
            $result=$conn->query($sql) or die($conn->error);
            $note_id= $conn->insert_id;
            return $note_id;
        }

        public function addProductRequisitionNote($note_id,$product_id,$product_qty,$unit_id){

            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO product_requisition_note(note_id,product_id,quantity,unit_id) VALUES('$note_id','$product_id','$product_qty','$unit_id')";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function getAllRequisitionNote(){

            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM requisition_note rn, user us WHERE rn.requested_by = us.user_id";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function getSpecificRequisitionNote($note_id){

            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM requisition_note rn, user us WHERE rn.requested_by = us.user_id AND rn.note_id = '$note_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function getNoteApprovedPerson($note_id){

            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM requisition_note rn, user us WHERE rn.approved_by = us.user_id AND rn.note_id='$note_id'";
            $result=$conn->query($sql);
            return $result;
        }


        public function getRequestedItems($note_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "SELECT * FROM product_requisition_note pr, product p, unit u WHERE note_id = '$note_id' "
                    . "AND p.product_id = pr.product_id AND pr.unit_id=u.unit_id";
            $result = $conn->query($sql);
            return $result;
        }
        
        public function approveNote($note_id,$approved_by){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE requisition_note SET is_approved = 1, approved_by = '$approved_by' WHERE note_id = '$note_id'";
            $result = $conn->query($sql);
            return $result;
        }
        
        public function rejectNote($note_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE requisition_note SET is_approved = 0, approved_by = 0 WHERE note_id = '$note_id'";
            $result = $conn->query($sql);
            return $result;
        }


    }