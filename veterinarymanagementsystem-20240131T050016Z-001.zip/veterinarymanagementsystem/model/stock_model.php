<?php

include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();

class Stock{
        public function addStock($product_id, $quantity, $stock_date){

             $conn=$GLOBALS["conn"];
             $sql="INSERT INTO stock(product_id,quantity,stock_date) VALUES('$product_id','$quantity', '$stock_date')";
             $result=$conn->query($sql);
             return $result;
        }

        public function getProductStock($product_id){

             $conn=$GLOBALS["conn"];
             $sql="SELECT SUM(quantity) as tot_qty FROM stock WHERE product_id='$product_id'  GROUP BY product_id";
             $result=$conn->query($sql);

             $stockrow = $result->fetch_assoc();

             $qty = $stockrow["tot_qty"];

             return $qty;
        }

        public function getAllStock(){

             $conn=$GLOBALS["conn"];
             $sql="SELECT * FROM stock s, product p, unit u, brand b WHERE p.product_id=s.product_id AND u.unit_id=p.unit_id AND b.brand_id = p.brand_id";
             $result=$conn->query($sql);
             return $result;
        }

        public function getSpecificStock($stock_id){

             $conn=$GLOBALS["conn"];
             $sql="SELECT * FROM product p, stock s, unit u, brand b  WHERE p.product_id=s.product_id"
                     ." AND p.unit_id=u.unit_id AND b.brand_id=p.brand_id AND s.stock_id='$stock_id'";
             $result=$conn->query($sql) or die($conn->error);
             return $result;
        }
        
        public function updateStock($stock_id,$stock_date,$quantity){

             $conn=$GLOBALS["conn"];
             $sql="UPDATE stock SET stock_date = '$stock_date',quantity='$quantity' WHERE stock_id='$stock_id'";
             $result=$conn->query($sql) or die($conn->error);
             return $result;
        }
        
        public function addReturnedStock($stock_id,$stock_return_date,$quantity){

            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO stock_return (return_quantity,return_date,stock_id)"
                    . "VALUES('$quantity','$stock_return_date','$stock_id')";
            $result=$conn->query($sql) or die($conn->error);
            $return_stock_id=$conn->insert_id;
            return $return_stock_id;
        }
        
        public function deductStock($stock_id,$quantity){
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE stock SET quantity = quantity - '$quantity' WHERE stock_id='$stock_id'";
            $result =$conn->query($sql) or die($conn->error);
            return $result;
        }
        
        public function getAllReturnedStock(){
            $conn = $GLOBALS["conn"];
            $sql = "SELECT * FROM stock_return sr, stock s, product p, brand b, unit u WHERE sr.stock_id = s.stock_id "
                    . "AND s.product_id =p.product_id AND p.brand_id = b.brand_id AND u.unit_id = p.unit_id";
            $result = $conn->query($sql) or die($sql->error);
            return $result;
        }
        
        public function getLastAddedStock(){
            $conn = $GLOBALS["conn"];
            $sql = "SELECT * FROM stock s, product p, unit u WHERE s.product_id=p.product_id "
                    . "AND p.unit_id = u.unit_id ORDER BY stock_id DESC LIMIT 1";
            $result = $conn->query($sql) or die($sql->error);
            return $result;
        }
        
        public function getLastReturnedStock(){
            $conn = $GLOBALS["conn"];
            $sql = "SELECT * FROM stock_return st, stock s, product p, unit u WHERE s.product_id=p.product_id AND"
                    . " p.unit_id = u.unit_id AND st.stock_id=s.stock_id ORDER BY stock_return_id DESC LIMIT 1";
            $result = $conn->query($sql) or die($sql->error);
            return $result;
        }
}

