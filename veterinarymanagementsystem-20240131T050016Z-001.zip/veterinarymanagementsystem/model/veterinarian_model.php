<?php
include_once'../commons/dbconnection.php';
$dbconnection= new dbconnection();
class Veterinarian{
        
        public function getAllSpecialties(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM specialty ORDER BY specialty";
            $result=$conn->query($sql);
            return $result;

        }
        
        public function addVet($fname,$lname,$nic,$email){
            
            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO veterinarian(vet_fname,vet_lname,vet_nic,vet_email)"
                    . "VALUES('$fname','$lname','$nic','$email')";
            $result=$conn->query($sql) or die($conn->error);
            $vet_id=$conn->insert_id;
            return $vet_id;

        }
        
        public function addVetSpecialty($vet_id,$specialty_id) {
            $conn= $GLOBALS["conn"];
            $sql="INSERT INTO vet_specialty(vet_id,specialty_id)values('$vet_id','$specialty_id')";
            $result=$conn->query($sql);
            return $result;

        }
        
        public function addVetContact($vet_id,$contact,$contact_type){
            $conn=$GLOBALS["conn"];
            $sql="INSERT INTO vet_contact(vet_id,contact_no,contact_type)VALUES('$vet_id','$contact','$contact_type')";
            $result=$conn->query($sql);
            return $result;
     
        }
        
        public function getAllVets(){
            
            $conn = $GLOBALS["conn"];
            $sql = "SELECT * FROM veterinarian v, vet_contact vc WHERE v.vet_id=vc.vet_id AND vc.contact_type=2";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function deactivateVet($vet_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE veterinarian SET status=0 WHERE vet_id='$vet_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function activateVet($vet_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "UPDATE veterinarian SET status=1 WHERE vet_id='$vet_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function getSpecificVet($vet_id){
            
            $conn = $GLOBALS["conn"];
            $sql = "SELECT * FROM veterinarian v, vet_contact vc WHERE v.vet_id=vc.vet_id AND v.vet_id='$vet_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function getVetBySearch($vet_id){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM veterinarian WHERE vet_fname LIKE '$vet_id%'";
            $result=$conn->query($sql);
            return $result;

        }
        
        public function getVetSpecialty($vet_id){
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM specialty s,vet_specialty vs WHERE s.specialty_id=vs.specialty_id AND vet_id='$vet_id'";
            $result=$conn->query($sql);
            return $result;
        }
        
        public function getSpcificVetContact($vet_id){
            $conn=$GLOBALS["conn"];
            $sql="SELECT * FROM vet_contact WHERE vet_id='$vet_id'";
            $result=$conn->query($sql);
            return $result;

        }
        
        public function updateVet($vet_fname,$vet_lname,$nic,$email,$vet_id){
            
            $conn= $GLOBALS["conn"];  
            $sql="UPDATE veterinarian SET "
                . "vet_fname='$vet_fname',"
                . "vet_lname='$vet_lname',"                
                . "vet_nic='$nic',"
                . "vet_email='$email'"
                . "WHERE vet_id='$vet_id' ";
            
            $result=$conn->query($sql) or die($conn->error);
                                            
        }
        
        
        public function updateVetContact($vet_id,$contact_no,$contact_type){
            
            $conn= $GLOBALS["conn"];  
            $sql="UPDATE vet_contact SET contact_no='$contact_no' WHERE vet_id='$vet_id' AND contact_type='$contact_type'";
            $result=$conn->query($sql) or die($conn->error);
                                            
            
        }
        
        public function removeVetSpecialties($vet_id){
            
        $conn= $GLOBALS["conn"];
        $sql="DELETE FROM vet_specialty WHERE vet_id='$vet_id'";
        $result=$conn->query($sql) or die($conn->error);
            
        }
        
        public function getAllVetCount(){
            
            $conn=$GLOBALS["conn"];
            $sql="SELECT COUNT(vet_id) as vet_count FROM veterinarian";
            $result=$conn->query($sql);

            $vetrow = $result->fetch_assoc();

            $count = $vetrow["vet_count"];

            return $count;
        }
        
        public function getActiveVetCount(){
            $conn= $GLOBALS["conn"];
            $sql="SELECT COUNT(vet_id) as activeVetCount FROM veterinarian WHERE status='1'";
            $result=$conn->query($sql) or die($conn->error);
        
            return $result;
        }
        
        public function getDeactiveVetCount(){
            $conn= $GLOBALS["conn"];
            $sql="SELECT COUNT(vet_id) as deactiveVetCount FROM veterinarian WHERE status='0'";
            $result=$conn->query($sql) or die($conn->error);
        
            return $result;
        }
                
                
}       

  